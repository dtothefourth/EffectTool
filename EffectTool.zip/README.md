# EffectTool
Visual Studio files for Effect Tool - SMWC
