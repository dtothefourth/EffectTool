﻿namespace HDMA_Generator_Tool
{
    partial class HDMA_Gradiant_GUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.tbcMainControl = new System.Windows.Forms.TabControl();
			this.tabSingle = new System.Windows.Forms.TabPage();
			this.groupBox31 = new System.Windows.Forms.GroupBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.rdbSngSub = new System.Windows.Forms.RadioButton();
			this.rdbSngAdd = new System.Windows.Forms.RadioButton();
			this.chbSngHlf = new System.Windows.Forms.CheckBox();
			this.groupBox19 = new System.Windows.Forms.GroupBox();
			this.grpSngChnAdv = new System.Windows.Forms.GroupBox();
			this.cmbSngChn = new System.Windows.Forms.ComboBox();
			this.groupBox18 = new System.Windows.Forms.GroupBox();
			this.cmbSngScnSel = new System.Windows.Forms.ComboBox();
			this.btnSngCode = new System.Windows.Forms.Button();
			this.chbSngCen = new System.Windows.Forms.CheckBox();
			this.groupBox20 = new System.Windows.Forms.GroupBox();
			this.label16 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.pcbSngBtm = new System.Windows.Forms.PictureBox();
			this.pcbSngTop = new System.Windows.Forms.PictureBox();
			this.trbSngTop = new System.Windows.Forms.TrackBar();
			this.trbSngBtm = new System.Windows.Forms.TrackBar();
			this.grpSngChnStd = new System.Windows.Forms.GroupBox();
			this.rdbSngCh3 = new System.Windows.Forms.RadioButton();
			this.rdbSngCh5 = new System.Windows.Forms.RadioButton();
			this.rdbSngCh4 = new System.Windows.Forms.RadioButton();
			this.groupBox22 = new System.Windows.Forms.GroupBox();
			this.chbSngBlu = new System.Windows.Forms.CheckBox();
			this.chbSngRed = new System.Windows.Forms.CheckBox();
			this.chbSngGrn = new System.Windows.Forms.CheckBox();
			this.pcbSngMainPic = new System.Windows.Forms.PictureBox();
			this.tabMulti = new System.Windows.Forms.TabPage();
			this.groupBox30 = new System.Windows.Forms.GroupBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.rdbMulSub = new System.Windows.Forms.RadioButton();
			this.rdbMulAdd = new System.Windows.Forms.RadioButton();
			this.chbMulHlf = new System.Windows.Forms.CheckBox();
			this.groupBox21 = new System.Windows.Forms.GroupBox();
			this.pcbMulRed = new System.Windows.Forms.PictureBox();
			this.label19 = new System.Windows.Forms.Label();
			this.chbMulRedCen = new System.Windows.Forms.CheckBox();
			this.trbMulRedBot = new System.Windows.Forms.TrackBar();
			this.trbMulRedTop = new System.Windows.Forms.TrackBar();
			this.pcbMulRedBot = new System.Windows.Forms.PictureBox();
			this.pcbMulRedTop = new System.Windows.Forms.PictureBox();
			this.groupBox23 = new System.Windows.Forms.GroupBox();
			this.pcbMulGrn = new System.Windows.Forms.PictureBox();
			this.label20 = new System.Windows.Forms.Label();
			this.chbMulGrnCen = new System.Windows.Forms.CheckBox();
			this.trbMulGrnBot = new System.Windows.Forms.TrackBar();
			this.trbMulGrnTop = new System.Windows.Forms.TrackBar();
			this.pcbMulGrnBot = new System.Windows.Forms.PictureBox();
			this.pcbMulGrnTop = new System.Windows.Forms.PictureBox();
			this.groupBox24 = new System.Windows.Forms.GroupBox();
			this.pcbMulBlu = new System.Windows.Forms.PictureBox();
			this.label21 = new System.Windows.Forms.Label();
			this.chbMulBluCen = new System.Windows.Forms.CheckBox();
			this.trbMulBluBot = new System.Windows.Forms.TrackBar();
			this.trbMulBluTop = new System.Windows.Forms.TrackBar();
			this.pcbMulBluBot = new System.Windows.Forms.PictureBox();
			this.pcbMulBluTop = new System.Windows.Forms.PictureBox();
			this.btnMulCod = new System.Windows.Forms.Button();
			this.cmbMulScnSel = new System.Windows.Forms.ComboBox();
			this.pcbMulMainPic = new System.Windows.Forms.PictureBox();
			this.tabPosition = new System.Windows.Forms.TabPage();
			this.groupBox28 = new System.Windows.Forms.GroupBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.rdbPosSub = new System.Windows.Forms.RadioButton();
			this.rdbPosAdd = new System.Windows.Forms.RadioButton();
			this.chbPosHlf = new System.Windows.Forms.CheckBox();
			this.btnPosCod = new System.Windows.Forms.Button();
			this.groupBox13 = new System.Windows.Forms.GroupBox();
			this.cmbPosScnSel = new System.Windows.Forms.ComboBox();
			this.groupBox17 = new System.Windows.Forms.GroupBox();
			this.btnPosCpy = new System.Windows.Forms.Button();
			this.btnPosClr = new System.Windows.Forms.Button();
			this.btnPosDel = new System.Windows.Forms.Button();
			this.btnPosNew = new System.Windows.Forms.Button();
			this.groupBox16 = new System.Windows.Forms.GroupBox();
			this.txtPosColBtm = new System.Windows.Forms.TextBox();
			this.pcbPosColBtm = new System.Windows.Forms.PictureBox();
			this.groupBox15 = new System.Windows.Forms.GroupBox();
			this.txtPosColTop = new System.Windows.Forms.TextBox();
			this.pcbPosColTop = new System.Windows.Forms.PictureBox();
			this.groupBox14 = new System.Windows.Forms.GroupBox();
			this.dgvPosColors = new System.Windows.Forms.DataGridView();
			this.colColor = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colColorString = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.colPosition = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.grpPosCurVal = new System.Windows.Forms.GroupBox();
			this.txtPosCurCol = new System.Windows.Forms.TextBox();
			this.nudPosCurPos = new System.Windows.Forms.NumericUpDown();
			this.pcbPosCurCol = new System.Windows.Forms.PictureBox();
			this.pcbPosMainPic = new System.Windows.Forms.PictureBox();
			this.tabDialog2 = new System.Windows.Forms.TabPage();
			this.groupBox12 = new System.Windows.Forms.GroupBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.rdbDiaSub = new System.Windows.Forms.RadioButton();
			this.rdbDiaAdd = new System.Windows.Forms.RadioButton();
			this.chbDiaHlf = new System.Windows.Forms.CheckBox();
			this.groupBox27 = new System.Windows.Forms.GroupBox();
			this.label25 = new System.Windows.Forms.Label();
			this.label24 = new System.Windows.Forms.Label();
			this.nudDiaScn = new System.Windows.Forms.NumericUpDown();
			this.txtDiaCol = new System.Windows.Forms.TextBox();
			this.pcbDiaCol = new System.Windows.Forms.PictureBox();
			this.groupBox26 = new System.Windows.Forms.GroupBox();
			this.label18 = new System.Windows.Forms.Label();
			this.label22 = new System.Windows.Forms.Label();
			this.label23 = new System.Windows.Forms.Label();
			this.lsbDiaBlu = new System.Windows.Forms.ListBox();
			this.lsbDiaGrn = new System.Windows.Forms.ListBox();
			this.lsbDiaRed = new System.Windows.Forms.ListBox();
			this.groupBox25 = new System.Windows.Forms.GroupBox();
			this.chbDiaEnd = new System.Windows.Forms.CheckBox();
			this.lblDiaWarn = new System.Windows.Forms.Label();
			this.btnDiaClr = new System.Windows.Forms.Button();
			this.btnDiaMovUp = new System.Windows.Forms.Button();
			this.btnDiaMovDwn = new System.Windows.Forms.Button();
			this.btnDiaRmv = new System.Windows.Forms.Button();
			this.btnDiaAdd = new System.Windows.Forms.Button();
			this.btnDiaCod = new System.Windows.Forms.Button();
			this.cmbDiaScnSel = new System.Windows.Forms.ComboBox();
			this.pcbDiaMainPic = new System.Windows.Forms.PictureBox();
			this.tabImage2 = new System.Windows.Forms.TabPage();
			this.groupBox11 = new System.Windows.Forms.GroupBox();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.rdbImgSub = new System.Windows.Forms.RadioButton();
			this.rdbImgAdd = new System.Windows.Forms.RadioButton();
			this.chbImgHlf = new System.Windows.Forms.CheckBox();
			this.grpImgCor = new System.Windows.Forms.GroupBox();
			this.txtImgColCor = new System.Windows.Forms.TextBox();
			this.pcbImgRipColCor = new System.Windows.Forms.PictureBox();
			this.label26 = new System.Windows.Forms.Label();
			this.label27 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.label29 = new System.Windows.Forms.Label();
			this.pcbImgColCor = new System.Windows.Forms.PictureBox();
			this.txtImgCorBlu = new System.Windows.Forms.TextBox();
			this.txtImgCorGrn = new System.Windows.Forms.TextBox();
			this.txtImgCorRed = new System.Windows.Forms.TextBox();
			this.trbImgCorBlu = new System.Windows.Forms.TrackBar();
			this.trbImgCorGrn = new System.Windows.Forms.TrackBar();
			this.trbImgCorRed = new System.Windows.Forms.TrackBar();
			this.groupBox29 = new System.Windows.Forms.GroupBox();
			this.pcbImgRipCol = new System.Windows.Forms.PictureBox();
			this.lblImgColRip = new System.Windows.Forms.Label();
			this.trbImgColRip = new System.Windows.Forms.TrackBar();
			this.label31 = new System.Windows.Forms.Label();
			this.chbImgColCor = new System.Windows.Forms.CheckBox();
			this.btnImgLoad = new System.Windows.Forms.Button();
			this.pcbImgImgRip = new System.Windows.Forms.PictureBox();
			this.btnImgCod = new System.Windows.Forms.Button();
			this.cmbImgScnSel = new System.Windows.Forms.ComboBox();
			this.pcbImgMainPic = new System.Windows.Forms.PictureBox();
			this.tabTable = new System.Windows.Forms.TabPage();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.rdbTblSub = new System.Windows.Forms.RadioButton();
			this.rdbTblAdd = new System.Windows.Forms.RadioButton();
			this.chbTblHlf = new System.Windows.Forms.CheckBox();
			this.chbTblFivBit = new System.Windows.Forms.CheckBox();
			this.btnTblCod = new System.Windows.Forms.Button();
			this.cmbTblScnSel = new System.Windows.Forms.ComboBox();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.pcbTblBlu = new System.Windows.Forms.PictureBox();
			this.splitContainer3 = new System.Windows.Forms.SplitContainer();
			this.rtbTblBlu = new System.Windows.Forms.RichTextBox();
			this.lsbTblBlu = new System.Windows.Forms.ListBox();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.pcbTblGrn = new System.Windows.Forms.PictureBox();
			this.splitContainer2 = new System.Windows.Forms.SplitContainer();
			this.rtbTblGrn = new System.Windows.Forms.RichTextBox();
			this.lsbTblGrn = new System.Windows.Forms.ListBox();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.pcbTblRed = new System.Windows.Forms.PictureBox();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.rtbTblRed = new System.Windows.Forms.RichTextBox();
			this.lsbTblRed = new System.Windows.Forms.ListBox();
			this.pcbTblMainPic = new System.Windows.Forms.PictureBox();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.tbcMainControl.SuspendLayout();
			this.tabSingle.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.grpSngChnAdv.SuspendLayout();
			this.groupBox20.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbSngBtm)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbSngTop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSngTop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSngBtm)).BeginInit();
			this.grpSngChnStd.SuspendLayout();
			this.groupBox22.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbSngMainPic)).BeginInit();
			this.tabMulti.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox21.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulRed)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulRedBot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulRedTop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulRedBot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulRedTop)).BeginInit();
			this.groupBox23.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulGrn)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulGrnBot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulGrnTop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulGrnBot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulGrnTop)).BeginInit();
			this.groupBox24.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulBlu)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulBluBot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulBluTop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulBluBot)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulBluTop)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulMainPic)).BeginInit();
			this.tabPosition.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox17.SuspendLayout();
			this.groupBox16.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosColBtm)).BeginInit();
			this.groupBox15.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosColTop)).BeginInit();
			this.groupBox14.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dgvPosColors)).BeginInit();
			this.grpPosCurVal.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudPosCurPos)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosCurCol)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosMainPic)).BeginInit();
			this.tabDialog2.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox27.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudDiaScn)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbDiaCol)).BeginInit();
			this.groupBox26.SuspendLayout();
			this.groupBox25.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbDiaMainPic)).BeginInit();
			this.tabImage2.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.grpImgCor.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgRipColCor)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgColCor)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgCorBlu)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgCorGrn)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgCorRed)).BeginInit();
			this.groupBox29.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgRipCol)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgColRip)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgImgRip)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgMainPic)).BeginInit();
			this.tabTable.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.groupBox9.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbTblBlu)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
			this.splitContainer3.Panel1.SuspendLayout();
			this.splitContainer3.Panel2.SuspendLayout();
			this.splitContainer3.SuspendLayout();
			this.groupBox8.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbTblGrn)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
			this.splitContainer2.Panel1.SuspendLayout();
			this.splitContainer2.Panel2.SuspendLayout();
			this.splitContainer2.SuspendLayout();
			this.groupBox7.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbTblRed)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbTblMainPic)).BeginInit();
			this.SuspendLayout();
			// 
			// tbcMainControl
			// 
			this.tbcMainControl.Controls.Add(this.tabSingle);
			this.tbcMainControl.Controls.Add(this.tabMulti);
			this.tbcMainControl.Controls.Add(this.tabPosition);
			this.tbcMainControl.Controls.Add(this.tabDialog2);
			this.tbcMainControl.Controls.Add(this.tabImage2);
			this.tbcMainControl.Controls.Add(this.tabTable);
			this.tbcMainControl.Location = new System.Drawing.Point(0, 30);
			this.tbcMainControl.Multiline = true;
			this.tbcMainControl.Name = "tbcMainControl";
			this.tbcMainControl.SelectedIndex = 0;
			this.tbcMainControl.Size = new System.Drawing.Size(675, 291);
			this.tbcMainControl.TabIndex = 14;
			// 
			// tabSingle
			// 
			this.tabSingle.BackColor = System.Drawing.SystemColors.Control;
			this.tabSingle.Controls.Add(this.grpSngChnAdv);
			this.tabSingle.Controls.Add(this.groupBox31);
			this.tabSingle.Controls.Add(this.groupBox1);
			this.tabSingle.Controls.Add(this.groupBox19);
			this.tabSingle.Controls.Add(this.groupBox18);
			this.tabSingle.Controls.Add(this.cmbSngScnSel);
			this.tabSingle.Controls.Add(this.btnSngCode);
			this.tabSingle.Controls.Add(this.chbSngCen);
			this.tabSingle.Controls.Add(this.groupBox20);
			this.tabSingle.Controls.Add(this.grpSngChnStd);
			this.tabSingle.Controls.Add(this.groupBox22);
			this.tabSingle.Controls.Add(this.pcbSngMainPic);
			this.tabSingle.Location = new System.Drawing.Point(4, 22);
			this.tabSingle.Name = "tabSingle";
			this.tabSingle.Size = new System.Drawing.Size(667, 265);
			this.tabSingle.TabIndex = 6;
			this.tabSingle.Text = "Single";
			// 
			// groupBox31
			// 
			this.groupBox31.Location = new System.Drawing.Point(585, 6);
			this.groupBox31.Name = "groupBox31";
			this.groupBox31.Size = new System.Drawing.Size(79, 253);
			this.groupBox31.TabIndex = 38;
			this.groupBox31.TabStop = false;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.rdbSngSub);
			this.groupBox1.Controls.Add(this.rdbSngAdd);
			this.groupBox1.Controls.Add(this.chbSngHlf);
			this.groupBox1.Location = new System.Drawing.Point(458, 6);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(121, 93);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Color Math";
			// 
			// rdbSngSub
			// 
			this.rdbSngSub.AutoSize = true;
			this.rdbSngSub.Location = new System.Drawing.Point(6, 41);
			this.rdbSngSub.Name = "rdbSngSub";
			this.rdbSngSub.Size = new System.Drawing.Size(70, 17);
			this.rdbSngSub.TabIndex = 2;
			this.rdbSngSub.Text = "Substract";
			this.rdbSngSub.UseVisualStyleBackColor = true;
			// 
			// rdbSngAdd
			// 
			this.rdbSngAdd.AutoSize = true;
			this.rdbSngAdd.Checked = true;
			this.rdbSngAdd.Location = new System.Drawing.Point(6, 19);
			this.rdbSngAdd.Name = "rdbSngAdd";
			this.rdbSngAdd.Size = new System.Drawing.Size(63, 17);
			this.rdbSngAdd.TabIndex = 1;
			this.rdbSngAdd.TabStop = true;
			this.rdbSngAdd.Text = "Addition";
			this.rdbSngAdd.UseVisualStyleBackColor = true;
			this.rdbSngAdd.CheckedChanged += new System.EventHandler(this.sngMath_Changed);
			// 
			// chbSngHlf
			// 
			this.chbSngHlf.AutoSize = true;
			this.chbSngHlf.Location = new System.Drawing.Point(6, 64);
			this.chbSngHlf.Name = "chbSngHlf";
			this.chbSngHlf.Size = new System.Drawing.Size(45, 17);
			this.chbSngHlf.TabIndex = 0;
			this.chbSngHlf.Text = "Half";
			this.chbSngHlf.UseVisualStyleBackColor = true;
			this.chbSngHlf.CheckedChanged += new System.EventHandler(this.sngMath_Changed);
			// 
			// groupBox19
			// 
			this.groupBox19.Location = new System.Drawing.Point(458, 105);
			this.groupBox19.Name = "groupBox19";
			this.groupBox19.Size = new System.Drawing.Size(121, 154);
			this.groupBox19.TabIndex = 31;
			this.groupBox19.TabStop = false;
			// 
			// grpSngChnAdv
			// 
			this.grpSngChnAdv.Controls.Add(this.cmbSngChn);
			this.grpSngChnAdv.Location = new System.Drawing.Point(383, 137);
			this.grpSngChnAdv.Name = "grpSngChnAdv";
			this.grpSngChnAdv.Size = new System.Drawing.Size(69, 91);
			this.grpSngChnAdv.TabIndex = 30;
			this.grpSngChnAdv.TabStop = false;
			this.grpSngChnAdv.Text = "Channel";
			this.grpSngChnAdv.Visible = false;
			// 
			// cmbSngChn
			// 
			this.cmbSngChn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSngChn.FormattingEnabled = true;
			this.cmbSngChn.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
			this.cmbSngChn.Location = new System.Drawing.Point(6, 19);
			this.cmbSngChn.Name = "cmbSngChn";
			this.cmbSngChn.Size = new System.Drawing.Size(57, 21);
			this.cmbSngChn.TabIndex = 0;
			this.cmbSngChn.SelectedIndexChanged += new System.EventHandler(this.cmbSngChn_SelectedIndexChanged);
			// 
			// groupBox18
			// 
			this.groupBox18.Location = new System.Drawing.Point(383, 233);
			this.groupBox18.Name = "groupBox18";
			this.groupBox18.Size = new System.Drawing.Size(69, 26);
			this.groupBox18.TabIndex = 29;
			this.groupBox18.TabStop = false;
			// 
			// cmbSngScnSel
			// 
			this.cmbSngScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSngScnSel.FormattingEnabled = true;
			this.cmbSngScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbSngScnSel.Name = "cmbSngScnSel";
			this.cmbSngScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbSngScnSel.TabIndex = 28;
			this.cmbSngScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbSngScnSel_SelectedIndexChanged);
			// 
			// btnSngCode
			// 
			this.btnSngCode.Location = new System.Drawing.Point(132, 236);
			this.btnSngCode.Name = "btnSngCode";
			this.btnSngCode.Size = new System.Drawing.Size(57, 21);
			this.btnSngCode.TabIndex = 23;
			this.btnSngCode.Text = "Code";
			this.btnSngCode.UseVisualStyleBackColor = true;
			this.btnSngCode.Click += new System.EventHandler(this.btnSngCode_Click);
			// 
			// chbSngCen
			// 
			this.chbSngCen.AutoSize = true;
			this.chbSngCen.Location = new System.Drawing.Point(383, 17);
			this.chbSngCen.Name = "chbSngCen";
			this.chbSngCen.Size = new System.Drawing.Size(69, 17);
			this.chbSngCen.TabIndex = 22;
			this.chbSngCen.Text = "Centered";
			this.chbSngCen.UseVisualStyleBackColor = true;
			this.chbSngCen.Click += new System.EventHandler(this.cntSng_Update);
			// 
			// groupBox20
			// 
			this.groupBox20.Controls.Add(this.label16);
			this.groupBox20.Controls.Add(this.label17);
			this.groupBox20.Controls.Add(this.pcbSngBtm);
			this.groupBox20.Controls.Add(this.pcbSngTop);
			this.groupBox20.Controls.Add(this.trbSngTop);
			this.groupBox20.Controls.Add(this.trbSngBtm);
			this.groupBox20.Location = new System.Drawing.Point(268, 6);
			this.groupBox20.Name = "groupBox20";
			this.groupBox20.Size = new System.Drawing.Size(109, 253);
			this.groupBox20.TabIndex = 21;
			this.groupBox20.TabStop = false;
			this.groupBox20.Text = "Values";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(55, 18);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(43, 13);
			this.label16.TabIndex = 6;
			this.label16.Text = "Bottom:";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(11, 18);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(29, 13);
			this.label17.TabIndex = 5;
			this.label17.Text = "Top:";
			// 
			// pcbSngBtm
			// 
			this.pcbSngBtm.BackColor = System.Drawing.Color.Black;
			this.pcbSngBtm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbSngBtm.Location = new System.Drawing.Point(58, 227);
			this.pcbSngBtm.Name = "pcbSngBtm";
			this.pcbSngBtm.Size = new System.Drawing.Size(20, 20);
			this.pcbSngBtm.TabIndex = 4;
			this.pcbSngBtm.TabStop = false;
			this.pcbSngBtm.Click += new System.EventHandler(this.cntSng_Update);
			// 
			// pcbSngTop
			// 
			this.pcbSngTop.BackColor = System.Drawing.Color.Black;
			this.pcbSngTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbSngTop.Location = new System.Drawing.Point(14, 227);
			this.pcbSngTop.Name = "pcbSngTop";
			this.pcbSngTop.Size = new System.Drawing.Size(20, 20);
			this.pcbSngTop.TabIndex = 3;
			this.pcbSngTop.TabStop = false;
			this.pcbSngTop.Click += new System.EventHandler(this.cntSng_Update);
			// 
			// trbSngTop
			// 
			this.trbSngTop.Location = new System.Drawing.Point(14, 34);
			this.trbSngTop.Maximum = 31;
			this.trbSngTop.Name = "trbSngTop";
			this.trbSngTop.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbSngTop.Size = new System.Drawing.Size(45, 185);
			this.trbSngTop.TabIndex = 1;
			this.trbSngTop.Scroll += new System.EventHandler(this.cntSng_Update);
			// 
			// trbSngBtm
			// 
			this.trbSngBtm.Location = new System.Drawing.Point(58, 34);
			this.trbSngBtm.Maximum = 31;
			this.trbSngBtm.Name = "trbSngBtm";
			this.trbSngBtm.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbSngBtm.Size = new System.Drawing.Size(45, 185);
			this.trbSngBtm.TabIndex = 2;
			this.trbSngBtm.Scroll += new System.EventHandler(this.cntSng_Update);
			// 
			// grpSngChnStd
			// 
			this.grpSngChnStd.Controls.Add(this.rdbSngCh3);
			this.grpSngChnStd.Controls.Add(this.rdbSngCh5);
			this.grpSngChnStd.Controls.Add(this.rdbSngCh4);
			this.grpSngChnStd.Location = new System.Drawing.Point(383, 137);
			this.grpSngChnStd.Name = "grpSngChnStd";
			this.grpSngChnStd.Size = new System.Drawing.Size(69, 91);
			this.grpSngChnStd.TabIndex = 19;
			this.grpSngChnStd.TabStop = false;
			this.grpSngChnStd.Text = "Channel";
			// 
			// rdbSngCh3
			// 
			this.rdbSngCh3.AutoSize = true;
			this.rdbSngCh3.Checked = true;
			this.rdbSngCh3.Location = new System.Drawing.Point(6, 19);
			this.rdbSngCh3.Name = "rdbSngCh3";
			this.rdbSngCh3.Size = new System.Drawing.Size(49, 17);
			this.rdbSngCh3.TabIndex = 8;
			this.rdbSngCh3.TabStop = true;
			this.rdbSngCh3.Text = "CH 3";
			this.rdbSngCh3.UseVisualStyleBackColor = true;
			this.rdbSngCh3.CheckedChanged += new System.EventHandler(this.rdbSngChn_CheckedChanged);
			// 
			// rdbSngCh5
			// 
			this.rdbSngCh5.AutoSize = true;
			this.rdbSngCh5.Location = new System.Drawing.Point(6, 65);
			this.rdbSngCh5.Name = "rdbSngCh5";
			this.rdbSngCh5.Size = new System.Drawing.Size(49, 17);
			this.rdbSngCh5.TabIndex = 10;
			this.rdbSngCh5.Text = "CH 5";
			this.rdbSngCh5.UseVisualStyleBackColor = true;
			this.rdbSngCh5.CheckedChanged += new System.EventHandler(this.rdbSngChn_CheckedChanged);
			// 
			// rdbSngCh4
			// 
			this.rdbSngCh4.AutoSize = true;
			this.rdbSngCh4.Location = new System.Drawing.Point(6, 42);
			this.rdbSngCh4.Name = "rdbSngCh4";
			this.rdbSngCh4.Size = new System.Drawing.Size(49, 17);
			this.rdbSngCh4.TabIndex = 9;
			this.rdbSngCh4.Text = "CH 4";
			this.rdbSngCh4.UseVisualStyleBackColor = true;
			this.rdbSngCh4.CheckedChanged += new System.EventHandler(this.rdbSngChn_CheckedChanged);
			// 
			// groupBox22
			// 
			this.groupBox22.Controls.Add(this.chbSngBlu);
			this.groupBox22.Controls.Add(this.chbSngRed);
			this.groupBox22.Controls.Add(this.chbSngGrn);
			this.groupBox22.Location = new System.Drawing.Point(383, 40);
			this.groupBox22.Name = "groupBox22";
			this.groupBox22.Size = new System.Drawing.Size(69, 91);
			this.groupBox22.TabIndex = 20;
			this.groupBox22.TabStop = false;
			this.groupBox22.Text = "Colors";
			// 
			// chbSngBlu
			// 
			this.chbSngBlu.AutoSize = true;
			this.chbSngBlu.Checked = true;
			this.chbSngBlu.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbSngBlu.Location = new System.Drawing.Point(6, 19);
			this.chbSngBlu.Name = "chbSngBlu";
			this.chbSngBlu.Size = new System.Drawing.Size(47, 17);
			this.chbSngBlu.TabIndex = 5;
			this.chbSngBlu.Text = "Blue";
			this.chbSngBlu.UseVisualStyleBackColor = true;
			this.chbSngBlu.Click += new System.EventHandler(this.cntSng_Update);
			// 
			// chbSngRed
			// 
			this.chbSngRed.AutoSize = true;
			this.chbSngRed.Location = new System.Drawing.Point(6, 42);
			this.chbSngRed.Name = "chbSngRed";
			this.chbSngRed.Size = new System.Drawing.Size(46, 17);
			this.chbSngRed.TabIndex = 6;
			this.chbSngRed.Text = "Red";
			this.chbSngRed.UseVisualStyleBackColor = true;
			this.chbSngRed.Click += new System.EventHandler(this.cntSng_Update);
			// 
			// chbSngGrn
			// 
			this.chbSngGrn.AutoSize = true;
			this.chbSngGrn.Location = new System.Drawing.Point(6, 65);
			this.chbSngGrn.Name = "chbSngGrn";
			this.chbSngGrn.Size = new System.Drawing.Size(55, 17);
			this.chbSngGrn.TabIndex = 7;
			this.chbSngGrn.Text = "Green";
			this.chbSngGrn.UseVisualStyleBackColor = true;
			this.chbSngGrn.Click += new System.EventHandler(this.cntSng_Update);
			// 
			// pcbSngMainPic
			// 
			this.pcbSngMainPic.BackColor = System.Drawing.Color.Black;
			this.pcbSngMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbSngMainPic.Name = "pcbSngMainPic";
			this.pcbSngMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbSngMainPic.TabIndex = 27;
			this.pcbSngMainPic.TabStop = false;
			// 
			// tabMulti
			// 
			this.tabMulti.BackColor = System.Drawing.SystemColors.Control;
			this.tabMulti.Controls.Add(this.groupBox30);
			this.tabMulti.Controls.Add(this.groupBox2);
			this.tabMulti.Controls.Add(this.groupBox21);
			this.tabMulti.Controls.Add(this.groupBox23);
			this.tabMulti.Controls.Add(this.groupBox24);
			this.tabMulti.Controls.Add(this.btnMulCod);
			this.tabMulti.Controls.Add(this.cmbMulScnSel);
			this.tabMulti.Controls.Add(this.pcbMulMainPic);
			this.tabMulti.Location = new System.Drawing.Point(4, 22);
			this.tabMulti.Name = "tabMulti";
			this.tabMulti.Size = new System.Drawing.Size(667, 265);
			this.tabMulti.TabIndex = 7;
			this.tabMulti.Text = "Multi";
			// 
			// groupBox30
			// 
			this.groupBox30.Location = new System.Drawing.Point(585, 106);
			this.groupBox30.Name = "groupBox30";
			this.groupBox30.Size = new System.Drawing.Size(79, 155);
			this.groupBox30.TabIndex = 37;
			this.groupBox30.TabStop = false;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.rdbMulSub);
			this.groupBox2.Controls.Add(this.rdbMulAdd);
			this.groupBox2.Controls.Add(this.chbMulHlf);
			this.groupBox2.Location = new System.Drawing.Point(585, 6);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(79, 93);
			this.groupBox2.TabIndex = 31;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Color Math";
			// 
			// rdbMulSub
			// 
			this.rdbMulSub.AutoSize = true;
			this.rdbMulSub.Location = new System.Drawing.Point(6, 41);
			this.rdbMulSub.Name = "rdbMulSub";
			this.rdbMulSub.Size = new System.Drawing.Size(70, 17);
			this.rdbMulSub.TabIndex = 2;
			this.rdbMulSub.Text = "Substract";
			this.rdbMulSub.UseVisualStyleBackColor = true;
			// 
			// rdbMulAdd
			// 
			this.rdbMulAdd.AutoSize = true;
			this.rdbMulAdd.Checked = true;
			this.rdbMulAdd.Location = new System.Drawing.Point(6, 19);
			this.rdbMulAdd.Name = "rdbMulAdd";
			this.rdbMulAdd.Size = new System.Drawing.Size(63, 17);
			this.rdbMulAdd.TabIndex = 1;
			this.rdbMulAdd.TabStop = true;
			this.rdbMulAdd.Text = "Addition";
			this.rdbMulAdd.UseVisualStyleBackColor = true;
			this.rdbMulAdd.CheckedChanged += new System.EventHandler(this.mulMath_Changed);
			// 
			// chbMulHlf
			// 
			this.chbMulHlf.AutoSize = true;
			this.chbMulHlf.Location = new System.Drawing.Point(6, 64);
			this.chbMulHlf.Name = "chbMulHlf";
			this.chbMulHlf.Size = new System.Drawing.Size(45, 17);
			this.chbMulHlf.TabIndex = 0;
			this.chbMulHlf.Text = "Half";
			this.chbMulHlf.UseVisualStyleBackColor = true;
			this.chbMulHlf.CheckedChanged += new System.EventHandler(this.mulMath_Changed);
			// 
			// groupBox21
			// 
			this.groupBox21.Controls.Add(this.pcbMulRed);
			this.groupBox21.Controls.Add(this.label19);
			this.groupBox21.Controls.Add(this.chbMulRedCen);
			this.groupBox21.Controls.Add(this.trbMulRedBot);
			this.groupBox21.Controls.Add(this.trbMulRedTop);
			this.groupBox21.Controls.Add(this.pcbMulRedBot);
			this.groupBox21.Controls.Add(this.pcbMulRedTop);
			this.groupBox21.Location = new System.Drawing.Point(268, 6);
			this.groupBox21.Name = "groupBox21";
			this.groupBox21.Size = new System.Drawing.Size(98, 255);
			this.groupBox21.TabIndex = 29;
			this.groupBox21.TabStop = false;
			this.groupBox21.Text = "Red";
			// 
			// pcbMulRed
			// 
			this.pcbMulRed.BackColor = System.Drawing.Color.Black;
			this.pcbMulRed.Location = new System.Drawing.Point(6, 18);
			this.pcbMulRed.Name = "pcbMulRed";
			this.pcbMulRed.Size = new System.Drawing.Size(12, 224);
			this.pcbMulRed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbMulRed.TabIndex = 16;
			this.pcbMulRed.TabStop = false;
			// 
			// label19
			// 
			this.label19.AutoSize = true;
			this.label19.Location = new System.Drawing.Point(21, 43);
			this.label19.Name = "label19";
			this.label19.Size = new System.Drawing.Size(74, 13);
			this.label19.TabIndex = 7;
			this.label19.Text = "Top:   Bottom:";
			// 
			// chbMulRedCen
			// 
			this.chbMulRedCen.AutoSize = true;
			this.chbMulRedCen.Location = new System.Drawing.Point(29, 18);
			this.chbMulRedCen.Name = "chbMulRedCen";
			this.chbMulRedCen.Size = new System.Drawing.Size(57, 17);
			this.chbMulRedCen.TabIndex = 6;
			this.chbMulRedCen.Text = "Center";
			this.chbMulRedCen.UseVisualStyleBackColor = true;
			this.chbMulRedCen.CheckedChanged += new System.EventHandler(this.UpdateMultiRed);
			// 
			// trbMulRedBot
			// 
			this.trbMulRedBot.Location = new System.Drawing.Point(52, 59);
			this.trbMulRedBot.Maximum = 31;
			this.trbMulRedBot.Name = "trbMulRedBot";
			this.trbMulRedBot.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbMulRedBot.Size = new System.Drawing.Size(45, 157);
			this.trbMulRedBot.TabIndex = 3;
			this.trbMulRedBot.Scroll += new System.EventHandler(this.UpdateMultiRed);
			// 
			// trbMulRedTop
			// 
			this.trbMulRedTop.Location = new System.Drawing.Point(24, 59);
			this.trbMulRedTop.Maximum = 31;
			this.trbMulRedTop.Name = "trbMulRedTop";
			this.trbMulRedTop.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbMulRedTop.Size = new System.Drawing.Size(45, 157);
			this.trbMulRedTop.TabIndex = 2;
			this.trbMulRedTop.Scroll += new System.EventHandler(this.UpdateMultiRed);
			// 
			// pcbMulRedBot
			// 
			this.pcbMulRedBot.BackColor = System.Drawing.Color.Black;
			this.pcbMulRedBot.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbMulRedBot.Location = new System.Drawing.Point(55, 222);
			this.pcbMulRedBot.Name = "pcbMulRedBot";
			this.pcbMulRedBot.Size = new System.Drawing.Size(20, 20);
			this.pcbMulRedBot.TabIndex = 5;
			this.pcbMulRedBot.TabStop = false;
			// 
			// pcbMulRedTop
			// 
			this.pcbMulRedTop.BackColor = System.Drawing.Color.Black;
			this.pcbMulRedTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbMulRedTop.Location = new System.Drawing.Point(29, 222);
			this.pcbMulRedTop.Name = "pcbMulRedTop";
			this.pcbMulRedTop.Size = new System.Drawing.Size(20, 20);
			this.pcbMulRedTop.TabIndex = 4;
			this.pcbMulRedTop.TabStop = false;
			// 
			// groupBox23
			// 
			this.groupBox23.Controls.Add(this.pcbMulGrn);
			this.groupBox23.Controls.Add(this.label20);
			this.groupBox23.Controls.Add(this.chbMulGrnCen);
			this.groupBox23.Controls.Add(this.trbMulGrnBot);
			this.groupBox23.Controls.Add(this.trbMulGrnTop);
			this.groupBox23.Controls.Add(this.pcbMulGrnBot);
			this.groupBox23.Controls.Add(this.pcbMulGrnTop);
			this.groupBox23.Location = new System.Drawing.Point(372, 6);
			this.groupBox23.Name = "groupBox23";
			this.groupBox23.Size = new System.Drawing.Size(98, 255);
			this.groupBox23.TabIndex = 30;
			this.groupBox23.TabStop = false;
			this.groupBox23.Text = "Green";
			// 
			// pcbMulGrn
			// 
			this.pcbMulGrn.BackColor = System.Drawing.Color.Black;
			this.pcbMulGrn.Location = new System.Drawing.Point(6, 18);
			this.pcbMulGrn.Name = "pcbMulGrn";
			this.pcbMulGrn.Size = new System.Drawing.Size(12, 224);
			this.pcbMulGrn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbMulGrn.TabIndex = 17;
			this.pcbMulGrn.TabStop = false;
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(21, 43);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(74, 13);
			this.label20.TabIndex = 8;
			this.label20.Text = "Top:   Bottom:";
			// 
			// chbMulGrnCen
			// 
			this.chbMulGrnCen.AutoSize = true;
			this.chbMulGrnCen.Location = new System.Drawing.Point(29, 17);
			this.chbMulGrnCen.Name = "chbMulGrnCen";
			this.chbMulGrnCen.Size = new System.Drawing.Size(57, 17);
			this.chbMulGrnCen.TabIndex = 6;
			this.chbMulGrnCen.Text = "Center";
			this.chbMulGrnCen.UseVisualStyleBackColor = true;
			this.chbMulGrnCen.CheckedChanged += new System.EventHandler(this.UpdateMultiGreen);
			// 
			// trbMulGrnBot
			// 
			this.trbMulGrnBot.Location = new System.Drawing.Point(52, 58);
			this.trbMulGrnBot.Maximum = 31;
			this.trbMulGrnBot.Name = "trbMulGrnBot";
			this.trbMulGrnBot.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbMulGrnBot.Size = new System.Drawing.Size(45, 157);
			this.trbMulGrnBot.TabIndex = 3;
			this.trbMulGrnBot.Scroll += new System.EventHandler(this.UpdateMultiGreen);
			// 
			// trbMulGrnTop
			// 
			this.trbMulGrnTop.Location = new System.Drawing.Point(24, 58);
			this.trbMulGrnTop.Maximum = 31;
			this.trbMulGrnTop.Name = "trbMulGrnTop";
			this.trbMulGrnTop.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbMulGrnTop.Size = new System.Drawing.Size(45, 157);
			this.trbMulGrnTop.TabIndex = 2;
			this.trbMulGrnTop.Scroll += new System.EventHandler(this.UpdateMultiGreen);
			// 
			// pcbMulGrnBot
			// 
			this.pcbMulGrnBot.BackColor = System.Drawing.Color.Black;
			this.pcbMulGrnBot.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbMulGrnBot.Location = new System.Drawing.Point(55, 221);
			this.pcbMulGrnBot.Name = "pcbMulGrnBot";
			this.pcbMulGrnBot.Size = new System.Drawing.Size(20, 20);
			this.pcbMulGrnBot.TabIndex = 5;
			this.pcbMulGrnBot.TabStop = false;
			// 
			// pcbMulGrnTop
			// 
			this.pcbMulGrnTop.BackColor = System.Drawing.Color.Black;
			this.pcbMulGrnTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbMulGrnTop.Location = new System.Drawing.Point(29, 221);
			this.pcbMulGrnTop.Name = "pcbMulGrnTop";
			this.pcbMulGrnTop.Size = new System.Drawing.Size(20, 20);
			this.pcbMulGrnTop.TabIndex = 4;
			this.pcbMulGrnTop.TabStop = false;
			// 
			// groupBox24
			// 
			this.groupBox24.Controls.Add(this.pcbMulBlu);
			this.groupBox24.Controls.Add(this.label21);
			this.groupBox24.Controls.Add(this.chbMulBluCen);
			this.groupBox24.Controls.Add(this.trbMulBluBot);
			this.groupBox24.Controls.Add(this.trbMulBluTop);
			this.groupBox24.Controls.Add(this.pcbMulBluBot);
			this.groupBox24.Controls.Add(this.pcbMulBluTop);
			this.groupBox24.Location = new System.Drawing.Point(475, 6);
			this.groupBox24.Name = "groupBox24";
			this.groupBox24.Size = new System.Drawing.Size(104, 255);
			this.groupBox24.TabIndex = 28;
			this.groupBox24.TabStop = false;
			this.groupBox24.Text = "Blue";
			// 
			// pcbMulBlu
			// 
			this.pcbMulBlu.BackColor = System.Drawing.Color.Black;
			this.pcbMulBlu.Location = new System.Drawing.Point(6, 18);
			this.pcbMulBlu.Name = "pcbMulBlu";
			this.pcbMulBlu.Size = new System.Drawing.Size(12, 224);
			this.pcbMulBlu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbMulBlu.TabIndex = 18;
			this.pcbMulBlu.TabStop = false;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(21, 43);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(74, 13);
			this.label21.TabIndex = 8;
			this.label21.Text = "Top:   Bottom:";
			// 
			// chbMulBluCen
			// 
			this.chbMulBluCen.AutoSize = true;
			this.chbMulBluCen.Location = new System.Drawing.Point(29, 18);
			this.chbMulBluCen.Name = "chbMulBluCen";
			this.chbMulBluCen.Size = new System.Drawing.Size(57, 17);
			this.chbMulBluCen.TabIndex = 6;
			this.chbMulBluCen.Text = "Center";
			this.chbMulBluCen.UseVisualStyleBackColor = true;
			this.chbMulBluCen.CheckedChanged += new System.EventHandler(this.UpdateMultiBlue);
			// 
			// trbMulBluBot
			// 
			this.trbMulBluBot.Location = new System.Drawing.Point(52, 58);
			this.trbMulBluBot.Maximum = 31;
			this.trbMulBluBot.Name = "trbMulBluBot";
			this.trbMulBluBot.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbMulBluBot.Size = new System.Drawing.Size(45, 157);
			this.trbMulBluBot.TabIndex = 3;
			this.trbMulBluBot.Scroll += new System.EventHandler(this.UpdateMultiBlue);
			// 
			// trbMulBluTop
			// 
			this.trbMulBluTop.Location = new System.Drawing.Point(24, 59);
			this.trbMulBluTop.Maximum = 31;
			this.trbMulBluTop.Name = "trbMulBluTop";
			this.trbMulBluTop.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbMulBluTop.Size = new System.Drawing.Size(45, 157);
			this.trbMulBluTop.TabIndex = 2;
			this.trbMulBluTop.Scroll += new System.EventHandler(this.UpdateMultiBlue);
			// 
			// pcbMulBluBot
			// 
			this.pcbMulBluBot.BackColor = System.Drawing.Color.Black;
			this.pcbMulBluBot.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbMulBluBot.Location = new System.Drawing.Point(55, 221);
			this.pcbMulBluBot.Name = "pcbMulBluBot";
			this.pcbMulBluBot.Size = new System.Drawing.Size(20, 20);
			this.pcbMulBluBot.TabIndex = 5;
			this.pcbMulBluBot.TabStop = false;
			// 
			// pcbMulBluTop
			// 
			this.pcbMulBluTop.BackColor = System.Drawing.Color.Black;
			this.pcbMulBluTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbMulBluTop.Location = new System.Drawing.Point(29, 221);
			this.pcbMulBluTop.Name = "pcbMulBluTop";
			this.pcbMulBluTop.Size = new System.Drawing.Size(20, 20);
			this.pcbMulBluTop.TabIndex = 4;
			this.pcbMulBluTop.TabStop = false;
			// 
			// btnMulCod
			// 
			this.btnMulCod.Location = new System.Drawing.Point(132, 236);
			this.btnMulCod.Name = "btnMulCod";
			this.btnMulCod.Size = new System.Drawing.Size(57, 21);
			this.btnMulCod.TabIndex = 27;
			this.btnMulCod.Text = "Code";
			this.btnMulCod.UseVisualStyleBackColor = true;
			this.btnMulCod.Click += new System.EventHandler(this.btnMulCod_Click);
			// 
			// cmbMulScnSel
			// 
			this.cmbMulScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbMulScnSel.FormattingEnabled = true;
			this.cmbMulScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbMulScnSel.Name = "cmbMulScnSel";
			this.cmbMulScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbMulScnSel.TabIndex = 26;
			this.cmbMulScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbMulScnSel_SelectedIndexChanged);
			// 
			// pcbMulMainPic
			// 
			this.pcbMulMainPic.BackColor = System.Drawing.Color.Black;
			this.pcbMulMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbMulMainPic.Name = "pcbMulMainPic";
			this.pcbMulMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbMulMainPic.TabIndex = 25;
			this.pcbMulMainPic.TabStop = false;
			// 
			// tabPosition
			// 
			this.tabPosition.BackColor = System.Drawing.SystemColors.Control;
			this.tabPosition.Controls.Add(this.groupBox28);
			this.tabPosition.Controls.Add(this.groupBox3);
			this.tabPosition.Controls.Add(this.btnPosCod);
			this.tabPosition.Controls.Add(this.groupBox13);
			this.tabPosition.Controls.Add(this.cmbPosScnSel);
			this.tabPosition.Controls.Add(this.groupBox17);
			this.tabPosition.Controls.Add(this.groupBox16);
			this.tabPosition.Controls.Add(this.groupBox15);
			this.tabPosition.Controls.Add(this.groupBox14);
			this.tabPosition.Controls.Add(this.grpPosCurVal);
			this.tabPosition.Controls.Add(this.pcbPosMainPic);
			this.tabPosition.Location = new System.Drawing.Point(4, 22);
			this.tabPosition.Name = "tabPosition";
			this.tabPosition.Size = new System.Drawing.Size(667, 265);
			this.tabPosition.TabIndex = 5;
			this.tabPosition.Text = "Positions";
			// 
			// groupBox28
			// 
			this.groupBox28.Location = new System.Drawing.Point(585, 105);
			this.groupBox28.Name = "groupBox28";
			this.groupBox28.Size = new System.Drawing.Size(79, 155);
			this.groupBox28.TabIndex = 37;
			this.groupBox28.TabStop = false;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.rdbPosSub);
			this.groupBox3.Controls.Add(this.rdbPosAdd);
			this.groupBox3.Controls.Add(this.chbPosHlf);
			this.groupBox3.Location = new System.Drawing.Point(585, 6);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(79, 93);
			this.groupBox3.TabIndex = 32;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Color Math";
			// 
			// rdbPosSub
			// 
			this.rdbPosSub.AutoSize = true;
			this.rdbPosSub.Location = new System.Drawing.Point(6, 41);
			this.rdbPosSub.Name = "rdbPosSub";
			this.rdbPosSub.Size = new System.Drawing.Size(70, 17);
			this.rdbPosSub.TabIndex = 2;
			this.rdbPosSub.Text = "Substract";
			this.rdbPosSub.UseVisualStyleBackColor = true;
			// 
			// rdbPosAdd
			// 
			this.rdbPosAdd.AutoSize = true;
			this.rdbPosAdd.Checked = true;
			this.rdbPosAdd.Location = new System.Drawing.Point(6, 19);
			this.rdbPosAdd.Name = "rdbPosAdd";
			this.rdbPosAdd.Size = new System.Drawing.Size(63, 17);
			this.rdbPosAdd.TabIndex = 1;
			this.rdbPosAdd.TabStop = true;
			this.rdbPosAdd.Text = "Addition";
			this.rdbPosAdd.UseVisualStyleBackColor = true;
			this.rdbPosAdd.CheckedChanged += new System.EventHandler(this.posMath_Changed);
			// 
			// chbPosHlf
			// 
			this.chbPosHlf.AutoSize = true;
			this.chbPosHlf.Location = new System.Drawing.Point(6, 64);
			this.chbPosHlf.Name = "chbPosHlf";
			this.chbPosHlf.Size = new System.Drawing.Size(45, 17);
			this.chbPosHlf.TabIndex = 0;
			this.chbPosHlf.Text = "Half";
			this.chbPosHlf.UseVisualStyleBackColor = true;
			this.chbPosHlf.CheckedChanged += new System.EventHandler(this.posMath_Changed);
			// 
			// btnPosCod
			// 
			this.btnPosCod.Location = new System.Drawing.Point(132, 236);
			this.btnPosCod.Name = "btnPosCod";
			this.btnPosCod.Size = new System.Drawing.Size(57, 21);
			this.btnPosCod.TabIndex = 24;
			this.btnPosCod.Text = "Code";
			this.btnPosCod.UseVisualStyleBackColor = true;
			this.btnPosCod.Click += new System.EventHandler(this.btnPosCod_Click);
			// 
			// groupBox13
			// 
			this.groupBox13.Location = new System.Drawing.Point(529, 6);
			this.groupBox13.Name = "groupBox13";
			this.groupBox13.Size = new System.Drawing.Size(50, 46);
			this.groupBox13.TabIndex = 11;
			this.groupBox13.TabStop = false;
			// 
			// cmbPosScnSel
			// 
			this.cmbPosScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbPosScnSel.FormattingEnabled = true;
			this.cmbPosScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbPosScnSel.Name = "cmbPosScnSel";
			this.cmbPosScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbPosScnSel.TabIndex = 10;
			this.cmbPosScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbPosScnSel_SelectedIndexChanged);
			// 
			// groupBox17
			// 
			this.groupBox17.Controls.Add(this.btnPosCpy);
			this.groupBox17.Controls.Add(this.btnPosClr);
			this.groupBox17.Controls.Add(this.btnPosDel);
			this.groupBox17.Controls.Add(this.btnPosNew);
			this.groupBox17.Location = new System.Drawing.Point(268, 58);
			this.groupBox17.Name = "groupBox17";
			this.groupBox17.Size = new System.Drawing.Size(96, 143);
			this.groupBox17.TabIndex = 9;
			this.groupBox17.TabStop = false;
			// 
			// btnPosCpy
			// 
			this.btnPosCpy.Enabled = false;
			this.btnPosCpy.Location = new System.Drawing.Point(6, 48);
			this.btnPosCpy.Name = "btnPosCpy";
			this.btnPosCpy.Size = new System.Drawing.Size(84, 23);
			this.btnPosCpy.TabIndex = 7;
			this.btnPosCpy.Text = "Copy";
			this.btnPosCpy.UseVisualStyleBackColor = true;
			this.btnPosCpy.Click += new System.EventHandler(this.btnPosCpy_Click);
			// 
			// btnPosClr
			// 
			this.btnPosClr.Enabled = false;
			this.btnPosClr.Location = new System.Drawing.Point(6, 106);
			this.btnPosClr.Name = "btnPosClr";
			this.btnPosClr.Size = new System.Drawing.Size(84, 23);
			this.btnPosClr.TabIndex = 6;
			this.btnPosClr.Text = "Clear";
			this.btnPosClr.UseVisualStyleBackColor = true;
			this.btnPosClr.Click += new System.EventHandler(this.btnPosClr_Click);
			// 
			// btnPosDel
			// 
			this.btnPosDel.Enabled = false;
			this.btnPosDel.Location = new System.Drawing.Point(6, 77);
			this.btnPosDel.Name = "btnPosDel";
			this.btnPosDel.Size = new System.Drawing.Size(84, 23);
			this.btnPosDel.TabIndex = 5;
			this.btnPosDel.Text = "Delete";
			this.btnPosDel.UseVisualStyleBackColor = true;
			this.btnPosDel.Click += new System.EventHandler(this.btnPosDel_Click);
			// 
			// btnPosNew
			// 
			this.btnPosNew.Location = new System.Drawing.Point(6, 19);
			this.btnPosNew.Name = "btnPosNew";
			this.btnPosNew.Size = new System.Drawing.Size(84, 23);
			this.btnPosNew.TabIndex = 4;
			this.btnPosNew.Text = "New";
			this.btnPosNew.UseVisualStyleBackColor = true;
			this.btnPosNew.Click += new System.EventHandler(this.btnPosNew_Click);
			// 
			// groupBox16
			// 
			this.groupBox16.Controls.Add(this.txtPosColBtm);
			this.groupBox16.Controls.Add(this.pcbPosColBtm);
			this.groupBox16.Location = new System.Drawing.Point(268, 207);
			this.groupBox16.Name = "groupBox16";
			this.groupBox16.Size = new System.Drawing.Size(96, 47);
			this.groupBox16.TabIndex = 8;
			this.groupBox16.TabStop = false;
			this.groupBox16.Text = "Bottom";
			// 
			// txtPosColBtm
			// 
			this.txtPosColBtm.Location = new System.Drawing.Point(6, 19);
			this.txtPosColBtm.MaxLength = 7;
			this.txtPosColBtm.Name = "txtPosColBtm";
			this.txtPosColBtm.Size = new System.Drawing.Size(56, 20);
			this.txtPosColBtm.TabIndex = 5;
			this.txtPosColBtm.Text = "#00FF00";
			// 
			// pcbPosColBtm
			// 
			this.pcbPosColBtm.BackColor = System.Drawing.Color.Lime;
			this.pcbPosColBtm.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbPosColBtm.Location = new System.Drawing.Point(68, 19);
			this.pcbPosColBtm.Name = "pcbPosColBtm";
			this.pcbPosColBtm.Size = new System.Drawing.Size(20, 20);
			this.pcbPosColBtm.TabIndex = 3;
			this.pcbPosColBtm.TabStop = false;
			// 
			// groupBox15
			// 
			this.groupBox15.Controls.Add(this.txtPosColTop);
			this.groupBox15.Controls.Add(this.pcbPosColTop);
			this.groupBox15.Location = new System.Drawing.Point(268, 6);
			this.groupBox15.Name = "groupBox15";
			this.groupBox15.Size = new System.Drawing.Size(96, 46);
			this.groupBox15.TabIndex = 7;
			this.groupBox15.TabStop = false;
			this.groupBox15.Text = "Top";
			// 
			// txtPosColTop
			// 
			this.txtPosColTop.Location = new System.Drawing.Point(6, 17);
			this.txtPosColTop.MaxLength = 7;
			this.txtPosColTop.Name = "txtPosColTop";
			this.txtPosColTop.Size = new System.Drawing.Size(56, 20);
			this.txtPosColTop.TabIndex = 4;
			this.txtPosColTop.Text = "#0000FF";
			// 
			// pcbPosColTop
			// 
			this.pcbPosColTop.BackColor = System.Drawing.Color.Blue;
			this.pcbPosColTop.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbPosColTop.Location = new System.Drawing.Point(68, 17);
			this.pcbPosColTop.Name = "pcbPosColTop";
			this.pcbPosColTop.Size = new System.Drawing.Size(20, 20);
			this.pcbPosColTop.TabIndex = 2;
			this.pcbPosColTop.TabStop = false;
			// 
			// groupBox14
			// 
			this.groupBox14.Controls.Add(this.dgvPosColors);
			this.groupBox14.Location = new System.Drawing.Point(371, 58);
			this.groupBox14.Name = "groupBox14";
			this.groupBox14.Padding = new System.Windows.Forms.Padding(6);
			this.groupBox14.Size = new System.Drawing.Size(208, 202);
			this.groupBox14.TabIndex = 6;
			this.groupBox14.TabStop = false;
			this.groupBox14.Text = "Gradient Colors";
			// 
			// dgvPosColors
			// 
			this.dgvPosColors.AllowUserToAddRows = false;
			this.dgvPosColors.AllowUserToResizeRows = false;
			this.dgvPosColors.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dgvPosColors.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dgvPosColors.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colColor,
            this.colColorString,
            this.colPosition});
			this.dgvPosColors.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dgvPosColors.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
			this.dgvPosColors.Location = new System.Drawing.Point(6, 19);
			this.dgvPosColors.MultiSelect = false;
			this.dgvPosColors.Name = "dgvPosColors";
			this.dgvPosColors.RowHeadersVisible = false;
			this.dgvPosColors.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dgvPosColors.Size = new System.Drawing.Size(196, 177);
			this.dgvPosColors.TabIndex = 5;
			this.dgvPosColors.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.dgvPosColors_RowsAdded);
			this.dgvPosColors.RowsRemoved += new System.Windows.Forms.DataGridViewRowsRemovedEventHandler(this.dgvPosColors_RowsRemoved);
			this.dgvPosColors.SelectionChanged += new System.EventHandler(this.dgvPosColors_SelectionChanged);
			// 
			// colColor
			// 
			this.colColor.HeaderText = "Color";
			this.colColor.Name = "colColor";
			// 
			// colColorString
			// 
			this.colColorString.HeaderText = "Color String";
			this.colColorString.Name = "colColorString";
			// 
			// colPosition
			// 
			this.colPosition.HeaderText = "Position";
			this.colPosition.Name = "colPosition";
			// 
			// grpPosCurVal
			// 
			this.grpPosCurVal.Controls.Add(this.txtPosCurCol);
			this.grpPosCurVal.Controls.Add(this.nudPosCurPos);
			this.grpPosCurVal.Controls.Add(this.pcbPosCurCol);
			this.grpPosCurVal.Enabled = false;
			this.grpPosCurVal.Location = new System.Drawing.Point(370, 6);
			this.grpPosCurVal.Name = "grpPosCurVal";
			this.grpPosCurVal.Size = new System.Drawing.Size(153, 46);
			this.grpPosCurVal.TabIndex = 4;
			this.grpPosCurVal.TabStop = false;
			this.grpPosCurVal.Text = "Current Value";
			// 
			// txtPosCurCol
			// 
			this.txtPosCurCol.Location = new System.Drawing.Point(7, 18);
			this.txtPosCurCol.MaxLength = 7;
			this.txtPosCurCol.Name = "txtPosCurCol";
			this.txtPosCurCol.Size = new System.Drawing.Size(54, 20);
			this.txtPosCurCol.TabIndex = 3;
			this.txtPosCurCol.Text = "#333333";
			// 
			// nudPosCurPos
			// 
			this.nudPosCurPos.Location = new System.Drawing.Point(93, 17);
			this.nudPosCurPos.Maximum = new decimal(new int[] {
            223,
            0,
            0,
            0});
			this.nudPosCurPos.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.nudPosCurPos.Name = "nudPosCurPos";
			this.nudPosCurPos.Size = new System.Drawing.Size(49, 20);
			this.nudPosCurPos.TabIndex = 2;
			this.nudPosCurPos.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.nudPosCurPos.ValueChanged += new System.EventHandler(this.nudPosCurPos_ValueChanged);
			// 
			// pcbPosCurCol
			// 
			this.pcbPosCurCol.BackColor = System.Drawing.Color.Silver;
			this.pcbPosCurCol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbPosCurCol.Location = new System.Drawing.Point(67, 17);
			this.pcbPosCurCol.Name = "pcbPosCurCol";
			this.pcbPosCurCol.Size = new System.Drawing.Size(20, 20);
			this.pcbPosCurCol.TabIndex = 1;
			this.pcbPosCurCol.TabStop = false;
			// 
			// pcbPosMainPic
			// 
			this.pcbPosMainPic.BackColor = System.Drawing.Color.Black;
			this.pcbPosMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbPosMainPic.Name = "pcbPosMainPic";
			this.pcbPosMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbPosMainPic.TabIndex = 0;
			this.pcbPosMainPic.TabStop = false;
			// 
			// tabDialog2
			// 
			this.tabDialog2.BackColor = System.Drawing.SystemColors.Control;
			this.tabDialog2.Controls.Add(this.groupBox12);
			this.tabDialog2.Controls.Add(this.groupBox4);
			this.tabDialog2.Controls.Add(this.groupBox27);
			this.tabDialog2.Controls.Add(this.groupBox26);
			this.tabDialog2.Controls.Add(this.groupBox25);
			this.tabDialog2.Controls.Add(this.btnDiaCod);
			this.tabDialog2.Controls.Add(this.cmbDiaScnSel);
			this.tabDialog2.Controls.Add(this.pcbDiaMainPic);
			this.tabDialog2.Location = new System.Drawing.Point(4, 22);
			this.tabDialog2.Name = "tabDialog2";
			this.tabDialog2.Size = new System.Drawing.Size(667, 265);
			this.tabDialog2.TabIndex = 8;
			this.tabDialog2.Text = "Dialog";
			// 
			// groupBox12
			// 
			this.groupBox12.Location = new System.Drawing.Point(585, 105);
			this.groupBox12.Name = "groupBox12";
			this.groupBox12.Size = new System.Drawing.Size(79, 155);
			this.groupBox12.TabIndex = 37;
			this.groupBox12.TabStop = false;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.rdbDiaSub);
			this.groupBox4.Controls.Add(this.rdbDiaAdd);
			this.groupBox4.Controls.Add(this.chbDiaHlf);
			this.groupBox4.Location = new System.Drawing.Point(585, 6);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(79, 93);
			this.groupBox4.TabIndex = 32;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Color Math";
			// 
			// rdbDiaSub
			// 
			this.rdbDiaSub.AutoSize = true;
			this.rdbDiaSub.Location = new System.Drawing.Point(6, 41);
			this.rdbDiaSub.Name = "rdbDiaSub";
			this.rdbDiaSub.Size = new System.Drawing.Size(70, 17);
			this.rdbDiaSub.TabIndex = 2;
			this.rdbDiaSub.Text = "Substract";
			this.rdbDiaSub.UseVisualStyleBackColor = true;
			// 
			// rdbDiaAdd
			// 
			this.rdbDiaAdd.AutoSize = true;
			this.rdbDiaAdd.Checked = true;
			this.rdbDiaAdd.Location = new System.Drawing.Point(6, 19);
			this.rdbDiaAdd.Name = "rdbDiaAdd";
			this.rdbDiaAdd.Size = new System.Drawing.Size(63, 17);
			this.rdbDiaAdd.TabIndex = 1;
			this.rdbDiaAdd.TabStop = true;
			this.rdbDiaAdd.Text = "Addition";
			this.rdbDiaAdd.UseVisualStyleBackColor = true;
			this.rdbDiaAdd.CheckedChanged += new System.EventHandler(this.diaMath_Changed);
			// 
			// chbDiaHlf
			// 
			this.chbDiaHlf.AutoSize = true;
			this.chbDiaHlf.Location = new System.Drawing.Point(6, 64);
			this.chbDiaHlf.Name = "chbDiaHlf";
			this.chbDiaHlf.Size = new System.Drawing.Size(45, 17);
			this.chbDiaHlf.TabIndex = 0;
			this.chbDiaHlf.Text = "Half";
			this.chbDiaHlf.UseVisualStyleBackColor = true;
			this.chbDiaHlf.CheckedChanged += new System.EventHandler(this.diaMath_Changed);
			// 
			// groupBox27
			// 
			this.groupBox27.Controls.Add(this.label25);
			this.groupBox27.Controls.Add(this.label24);
			this.groupBox27.Controls.Add(this.nudDiaScn);
			this.groupBox27.Controls.Add(this.txtDiaCol);
			this.groupBox27.Controls.Add(this.pcbDiaCol);
			this.groupBox27.Location = new System.Drawing.Point(364, 6);
			this.groupBox27.Name = "groupBox27";
			this.groupBox27.Size = new System.Drawing.Size(215, 61);
			this.groupBox27.TabIndex = 31;
			this.groupBox27.TabStop = false;
			this.groupBox27.Text = "Value To Add";
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(6, 19);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(56, 13);
			this.label25.TabIndex = 15;
			this.label25.Text = "Scanlines:";
			// 
			// label24
			// 
			this.label24.AutoSize = true;
			this.label24.Location = new System.Drawing.Point(95, 19);
			this.label24.Name = "label24";
			this.label24.Size = new System.Drawing.Size(34, 13);
			this.label24.TabIndex = 16;
			this.label24.Text = "Color:";
			// 
			// nudDiaScn
			// 
			this.nudDiaScn.Location = new System.Drawing.Point(6, 35);
			this.nudDiaScn.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
			this.nudDiaScn.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.nudDiaScn.Name = "nudDiaScn";
			this.nudDiaScn.Size = new System.Drawing.Size(68, 20);
			this.nudDiaScn.TabIndex = 14;
			this.nudDiaScn.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// txtDiaCol
			// 
			this.txtDiaCol.Location = new System.Drawing.Point(124, 35);
			this.txtDiaCol.MaxLength = 7;
			this.txtDiaCol.Name = "txtDiaCol";
			this.txtDiaCol.Size = new System.Drawing.Size(68, 20);
			this.txtDiaCol.TabIndex = 0;
			this.txtDiaCol.Text = "#000000";
			// 
			// pcbDiaCol
			// 
			this.pcbDiaCol.BackColor = System.Drawing.Color.Black;
			this.pcbDiaCol.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbDiaCol.Location = new System.Drawing.Point(98, 35);
			this.pcbDiaCol.Name = "pcbDiaCol";
			this.pcbDiaCol.Size = new System.Drawing.Size(20, 20);
			this.pcbDiaCol.TabIndex = 13;
			this.pcbDiaCol.TabStop = false;
			// 
			// groupBox26
			// 
			this.groupBox26.Controls.Add(this.label18);
			this.groupBox26.Controls.Add(this.label22);
			this.groupBox26.Controls.Add(this.label23);
			this.groupBox26.Controls.Add(this.lsbDiaBlu);
			this.groupBox26.Controls.Add(this.lsbDiaGrn);
			this.groupBox26.Controls.Add(this.lsbDiaRed);
			this.groupBox26.Location = new System.Drawing.Point(364, 73);
			this.groupBox26.Name = "groupBox26";
			this.groupBox26.Size = new System.Drawing.Size(215, 187);
			this.groupBox26.TabIndex = 30;
			this.groupBox26.TabStop = false;
			this.groupBox26.Text = "Values";
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(146, 18);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(31, 13);
			this.label18.TabIndex = 24;
			this.label18.Text = "Blue:";
			// 
			// label22
			// 
			this.label22.AutoSize = true;
			this.label22.Location = new System.Drawing.Point(73, 18);
			this.label22.Name = "label22";
			this.label22.Size = new System.Drawing.Size(39, 13);
			this.label22.TabIndex = 23;
			this.label22.Text = "Green:";
			// 
			// label23
			// 
			this.label23.AutoSize = true;
			this.label23.Location = new System.Drawing.Point(3, 18);
			this.label23.Name = "label23";
			this.label23.Size = new System.Drawing.Size(30, 13);
			this.label23.TabIndex = 22;
			this.label23.Text = "Red:";
			// 
			// lsbDiaBlu
			// 
			this.lsbDiaBlu.FormattingEnabled = true;
			this.lsbDiaBlu.Location = new System.Drawing.Point(145, 34);
			this.lsbDiaBlu.Name = "lsbDiaBlu";
			this.lsbDiaBlu.Size = new System.Drawing.Size(64, 147);
			this.lsbDiaBlu.TabIndex = 20;
			this.lsbDiaBlu.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lsbDia_MouseDown);
			// 
			// lsbDiaGrn
			// 
			this.lsbDiaGrn.FormattingEnabled = true;
			this.lsbDiaGrn.Location = new System.Drawing.Point(76, 34);
			this.lsbDiaGrn.Name = "lsbDiaGrn";
			this.lsbDiaGrn.Size = new System.Drawing.Size(64, 147);
			this.lsbDiaGrn.TabIndex = 19;
			this.lsbDiaGrn.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lsbDia_MouseDown);
			// 
			// lsbDiaRed
			// 
			this.lsbDiaRed.FormattingEnabled = true;
			this.lsbDiaRed.Location = new System.Drawing.Point(6, 34);
			this.lsbDiaRed.Name = "lsbDiaRed";
			this.lsbDiaRed.Size = new System.Drawing.Size(64, 147);
			this.lsbDiaRed.TabIndex = 17;
			this.lsbDiaRed.MouseDown += new System.Windows.Forms.MouseEventHandler(this.lsbDia_MouseDown);
			// 
			// groupBox25
			// 
			this.groupBox25.Controls.Add(this.chbDiaEnd);
			this.groupBox25.Controls.Add(this.lblDiaWarn);
			this.groupBox25.Controls.Add(this.btnDiaClr);
			this.groupBox25.Controls.Add(this.btnDiaMovUp);
			this.groupBox25.Controls.Add(this.btnDiaMovDwn);
			this.groupBox25.Controls.Add(this.btnDiaRmv);
			this.groupBox25.Controls.Add(this.btnDiaAdd);
			this.groupBox25.Location = new System.Drawing.Point(268, 6);
			this.groupBox25.Name = "groupBox25";
			this.groupBox25.Size = new System.Drawing.Size(93, 254);
			this.groupBox25.TabIndex = 29;
			this.groupBox25.TabStop = false;
			this.groupBox25.Text = "Controls";
			// 
			// chbDiaEnd
			// 
			this.chbDiaEnd.AutoSize = true;
			this.chbDiaEnd.Checked = true;
			this.chbDiaEnd.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbDiaEnd.Location = new System.Drawing.Point(7, 169);
			this.chbDiaEnd.Name = "chbDiaEnd";
			this.chbDiaEnd.Size = new System.Drawing.Size(80, 17);
			this.chbDiaEnd.TabIndex = 30;
			this.chbDiaEnd.Text = "End HDMA";
			this.chbDiaEnd.UseVisualStyleBackColor = true;
			// 
			// lblDiaWarn
			// 
			this.lblDiaWarn.ForeColor = System.Drawing.Color.Red;
			this.lblDiaWarn.Location = new System.Drawing.Point(6, 205);
			this.lblDiaWarn.Name = "lblDiaWarn";
			this.lblDiaWarn.Size = new System.Drawing.Size(81, 46);
			this.lblDiaWarn.TabIndex = 29;
			this.lblDiaWarn.Text = "You\'ve passed\r\nthe scanline \r\nlimit.";
			this.lblDiaWarn.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			this.lblDiaWarn.Visible = false;
			// 
			// btnDiaClr
			// 
			this.btnDiaClr.Enabled = false;
			this.btnDiaClr.Location = new System.Drawing.Point(6, 139);
			this.btnDiaClr.Name = "btnDiaClr";
			this.btnDiaClr.Size = new System.Drawing.Size(81, 24);
			this.btnDiaClr.TabIndex = 28;
			this.btnDiaClr.Text = "Clear";
			this.btnDiaClr.UseVisualStyleBackColor = true;
			this.btnDiaClr.Click += new System.EventHandler(this.btnDiaClr_Click);
			// 
			// btnDiaMovUp
			// 
			this.btnDiaMovUp.Enabled = false;
			this.btnDiaMovUp.Location = new System.Drawing.Point(6, 79);
			this.btnDiaMovUp.Name = "btnDiaMovUp";
			this.btnDiaMovUp.Size = new System.Drawing.Size(81, 24);
			this.btnDiaMovUp.TabIndex = 25;
			this.btnDiaMovUp.Text = "Move Up";
			this.btnDiaMovUp.UseVisualStyleBackColor = true;
			this.btnDiaMovUp.Click += new System.EventHandler(this.btnDiaMovUp_Click);
			// 
			// btnDiaMovDwn
			// 
			this.btnDiaMovDwn.Enabled = false;
			this.btnDiaMovDwn.Location = new System.Drawing.Point(6, 109);
			this.btnDiaMovDwn.Name = "btnDiaMovDwn";
			this.btnDiaMovDwn.Size = new System.Drawing.Size(81, 24);
			this.btnDiaMovDwn.TabIndex = 21;
			this.btnDiaMovDwn.Text = "Move Down";
			this.btnDiaMovDwn.UseVisualStyleBackColor = true;
			this.btnDiaMovDwn.Click += new System.EventHandler(this.btnDiaMovDwn_Click);
			// 
			// btnDiaRmv
			// 
			this.btnDiaRmv.Enabled = false;
			this.btnDiaRmv.Location = new System.Drawing.Point(6, 49);
			this.btnDiaRmv.Name = "btnDiaRmv";
			this.btnDiaRmv.Size = new System.Drawing.Size(81, 24);
			this.btnDiaRmv.TabIndex = 18;
			this.btnDiaRmv.Text = "Remove";
			this.btnDiaRmv.UseVisualStyleBackColor = true;
			this.btnDiaRmv.Click += new System.EventHandler(this.btnDiaRmv_Click);
			// 
			// btnDiaAdd
			// 
			this.btnDiaAdd.Location = new System.Drawing.Point(6, 19);
			this.btnDiaAdd.Name = "btnDiaAdd";
			this.btnDiaAdd.Size = new System.Drawing.Size(81, 24);
			this.btnDiaAdd.TabIndex = 1;
			this.btnDiaAdd.Text = "Add";
			this.btnDiaAdd.UseVisualStyleBackColor = true;
			this.btnDiaAdd.Click += new System.EventHandler(this.btnDiaAdd_Click);
			// 
			// btnDiaCod
			// 
			this.btnDiaCod.Location = new System.Drawing.Point(132, 236);
			this.btnDiaCod.Name = "btnDiaCod";
			this.btnDiaCod.Size = new System.Drawing.Size(57, 21);
			this.btnDiaCod.TabIndex = 27;
			this.btnDiaCod.Text = "Code";
			this.btnDiaCod.UseVisualStyleBackColor = true;
			this.btnDiaCod.Click += new System.EventHandler(this.btnDiaCod_Click);
			// 
			// cmbDiaScnSel
			// 
			this.cmbDiaScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbDiaScnSel.FormattingEnabled = true;
			this.cmbDiaScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbDiaScnSel.Name = "cmbDiaScnSel";
			this.cmbDiaScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbDiaScnSel.TabIndex = 26;
			this.cmbDiaScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbDiaScnSel_SelectedIndexChanged);
			// 
			// pcbDiaMainPic
			// 
			this.pcbDiaMainPic.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.pcbDiaMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbDiaMainPic.Name = "pcbDiaMainPic";
			this.pcbDiaMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbDiaMainPic.TabIndex = 25;
			this.pcbDiaMainPic.TabStop = false;
			// 
			// tabImage2
			// 
			this.tabImage2.BackColor = System.Drawing.SystemColors.Control;
			this.tabImage2.Controls.Add(this.groupBox11);
			this.tabImage2.Controls.Add(this.groupBox5);
			this.tabImage2.Controls.Add(this.grpImgCor);
			this.tabImage2.Controls.Add(this.groupBox29);
			this.tabImage2.Controls.Add(this.btnImgCod);
			this.tabImage2.Controls.Add(this.cmbImgScnSel);
			this.tabImage2.Controls.Add(this.pcbImgMainPic);
			this.tabImage2.Location = new System.Drawing.Point(4, 22);
			this.tabImage2.Name = "tabImage2";
			this.tabImage2.Size = new System.Drawing.Size(667, 265);
			this.tabImage2.TabIndex = 9;
			this.tabImage2.Text = "Image";
			// 
			// groupBox11
			// 
			this.groupBox11.Location = new System.Drawing.Point(585, 103);
			this.groupBox11.Name = "groupBox11";
			this.groupBox11.Size = new System.Drawing.Size(79, 155);
			this.groupBox11.TabIndex = 37;
			this.groupBox11.TabStop = false;
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.rdbImgSub);
			this.groupBox5.Controls.Add(this.rdbImgAdd);
			this.groupBox5.Controls.Add(this.chbImgHlf);
			this.groupBox5.Location = new System.Drawing.Point(585, 4);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(79, 93);
			this.groupBox5.TabIndex = 33;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Color Math";
			// 
			// rdbImgSub
			// 
			this.rdbImgSub.AutoSize = true;
			this.rdbImgSub.Location = new System.Drawing.Point(6, 41);
			this.rdbImgSub.Name = "rdbImgSub";
			this.rdbImgSub.Size = new System.Drawing.Size(70, 17);
			this.rdbImgSub.TabIndex = 2;
			this.rdbImgSub.Text = "Substract";
			this.rdbImgSub.UseVisualStyleBackColor = true;
			// 
			// rdbImgAdd
			// 
			this.rdbImgAdd.AutoSize = true;
			this.rdbImgAdd.Checked = true;
			this.rdbImgAdd.Location = new System.Drawing.Point(6, 19);
			this.rdbImgAdd.Name = "rdbImgAdd";
			this.rdbImgAdd.Size = new System.Drawing.Size(63, 17);
			this.rdbImgAdd.TabIndex = 1;
			this.rdbImgAdd.TabStop = true;
			this.rdbImgAdd.Text = "Addition";
			this.rdbImgAdd.UseVisualStyleBackColor = true;
			this.rdbImgAdd.CheckedChanged += new System.EventHandler(this.imgMath_Changed);
			// 
			// chbImgHlf
			// 
			this.chbImgHlf.AutoSize = true;
			this.chbImgHlf.Location = new System.Drawing.Point(6, 64);
			this.chbImgHlf.Name = "chbImgHlf";
			this.chbImgHlf.Size = new System.Drawing.Size(45, 17);
			this.chbImgHlf.TabIndex = 0;
			this.chbImgHlf.Text = "Half";
			this.chbImgHlf.UseVisualStyleBackColor = true;
			this.chbImgHlf.CheckedChanged += new System.EventHandler(this.imgMath_Changed);
			// 
			// grpImgCor
			// 
			this.grpImgCor.Controls.Add(this.txtImgColCor);
			this.grpImgCor.Controls.Add(this.pcbImgRipColCor);
			this.grpImgCor.Controls.Add(this.label26);
			this.grpImgCor.Controls.Add(this.label27);
			this.grpImgCor.Controls.Add(this.label28);
			this.grpImgCor.Controls.Add(this.label29);
			this.grpImgCor.Controls.Add(this.pcbImgColCor);
			this.grpImgCor.Controls.Add(this.txtImgCorBlu);
			this.grpImgCor.Controls.Add(this.txtImgCorGrn);
			this.grpImgCor.Controls.Add(this.txtImgCorRed);
			this.grpImgCor.Controls.Add(this.trbImgCorBlu);
			this.grpImgCor.Controls.Add(this.trbImgCorGrn);
			this.grpImgCor.Controls.Add(this.trbImgCorRed);
			this.grpImgCor.Enabled = false;
			this.grpImgCor.Location = new System.Drawing.Point(453, 4);
			this.grpImgCor.Name = "grpImgCor";
			this.grpImgCor.Size = new System.Drawing.Size(126, 253);
			this.grpImgCor.TabIndex = 32;
			this.grpImgCor.TabStop = false;
			this.grpImgCor.Text = "Color-Correction";
			// 
			// txtImgColCor
			// 
			this.txtImgColCor.Location = new System.Drawing.Point(32, 45);
			this.txtImgColCor.Name = "txtImgColCor";
			this.txtImgColCor.Size = new System.Drawing.Size(68, 20);
			this.txtImgColCor.TabIndex = 36;
			this.txtImgColCor.Text = "#000000";
			// 
			// pcbImgRipColCor
			// 
			this.pcbImgRipColCor.BackColor = System.Drawing.Color.Black;
			this.pcbImgRipColCor.Location = new System.Drawing.Point(106, 19);
			this.pcbImgRipColCor.Name = "pcbImgRipColCor";
			this.pcbImgRipColCor.Size = new System.Drawing.Size(12, 224);
			this.pcbImgRipColCor.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbImgRipColCor.TabIndex = 35;
			this.pcbImgRipColCor.TabStop = false;
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(70, 72);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(17, 13);
			this.label26.TabIndex = 34;
			this.label26.Text = "B:";
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(37, 72);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(18, 13);
			this.label27.TabIndex = 33;
			this.label27.Text = "G:";
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(6, 72);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(18, 13);
			this.label28.TabIndex = 32;
			this.label28.Text = "R:";
			// 
			// label29
			// 
			this.label29.AutoSize = true;
			this.label29.Location = new System.Drawing.Point(6, 24);
			this.label29.Name = "label29";
			this.label29.Size = new System.Drawing.Size(34, 13);
			this.label29.TabIndex = 31;
			this.label29.Text = "Color:";
			// 
			// pcbImgColCor
			// 
			this.pcbImgColCor.BackColor = System.Drawing.Color.Black;
			this.pcbImgColCor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbImgColCor.Location = new System.Drawing.Point(6, 45);
			this.pcbImgColCor.Name = "pcbImgColCor";
			this.pcbImgColCor.Size = new System.Drawing.Size(20, 20);
			this.pcbImgColCor.TabIndex = 30;
			this.pcbImgColCor.TabStop = false;
			// 
			// txtImgCorBlu
			// 
			this.txtImgCorBlu.Location = new System.Drawing.Point(73, 223);
			this.txtImgCorBlu.MaxLength = 3;
			this.txtImgCorBlu.Name = "txtImgCorBlu";
			this.txtImgCorBlu.Size = new System.Drawing.Size(27, 20);
			this.txtImgCorBlu.TabIndex = 29;
			this.txtImgCorBlu.Text = "0";
			// 
			// txtImgCorGrn
			// 
			this.txtImgCorGrn.Location = new System.Drawing.Point(40, 223);
			this.txtImgCorGrn.MaxLength = 3;
			this.txtImgCorGrn.Name = "txtImgCorGrn";
			this.txtImgCorGrn.Size = new System.Drawing.Size(27, 20);
			this.txtImgCorGrn.TabIndex = 28;
			this.txtImgCorGrn.Text = "0";
			// 
			// txtImgCorRed
			// 
			this.txtImgCorRed.Location = new System.Drawing.Point(7, 223);
			this.txtImgCorRed.MaxLength = 3;
			this.txtImgCorRed.Name = "txtImgCorRed";
			this.txtImgCorRed.Size = new System.Drawing.Size(27, 20);
			this.txtImgCorRed.TabIndex = 27;
			this.txtImgCorRed.Text = "0";
			// 
			// trbImgCorBlu
			// 
			this.trbImgCorBlu.Location = new System.Drawing.Point(73, 88);
			this.trbImgCorBlu.Maximum = 255;
			this.trbImgCorBlu.Name = "trbImgCorBlu";
			this.trbImgCorBlu.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbImgCorBlu.Size = new System.Drawing.Size(45, 136);
			this.trbImgCorBlu.TabIndex = 2;
			this.trbImgCorBlu.TickStyle = System.Windows.Forms.TickStyle.None;
			this.trbImgCorBlu.Scroll += new System.EventHandler(this.trbImgCor_Scroll);
			// 
			// trbImgCorGrn
			// 
			this.trbImgCorGrn.Location = new System.Drawing.Point(40, 88);
			this.trbImgCorGrn.Maximum = 255;
			this.trbImgCorGrn.Name = "trbImgCorGrn";
			this.trbImgCorGrn.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbImgCorGrn.Size = new System.Drawing.Size(45, 136);
			this.trbImgCorGrn.TabIndex = 1;
			this.trbImgCorGrn.TickStyle = System.Windows.Forms.TickStyle.None;
			this.trbImgCorGrn.Scroll += new System.EventHandler(this.trbImgCor_Scroll);
			// 
			// trbImgCorRed
			// 
			this.trbImgCorRed.Location = new System.Drawing.Point(7, 88);
			this.trbImgCorRed.Maximum = 255;
			this.trbImgCorRed.Name = "trbImgCorRed";
			this.trbImgCorRed.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbImgCorRed.Size = new System.Drawing.Size(45, 136);
			this.trbImgCorRed.TabIndex = 0;
			this.trbImgCorRed.TickStyle = System.Windows.Forms.TickStyle.None;
			this.trbImgCorRed.Scroll += new System.EventHandler(this.trbImgCor_Scroll);
			// 
			// groupBox29
			// 
			this.groupBox29.Controls.Add(this.pcbImgRipCol);
			this.groupBox29.Controls.Add(this.lblImgColRip);
			this.groupBox29.Controls.Add(this.trbImgColRip);
			this.groupBox29.Controls.Add(this.label31);
			this.groupBox29.Controls.Add(this.chbImgColCor);
			this.groupBox29.Controls.Add(this.btnImgLoad);
			this.groupBox29.Controls.Add(this.pcbImgImgRip);
			this.groupBox29.Location = new System.Drawing.Point(268, 4);
			this.groupBox29.Name = "groupBox29";
			this.groupBox29.Size = new System.Drawing.Size(179, 253);
			this.groupBox29.TabIndex = 31;
			this.groupBox29.TabStop = false;
			this.groupBox29.Text = "Image";
			// 
			// pcbImgRipCol
			// 
			this.pcbImgRipCol.BackColor = System.Drawing.Color.Black;
			this.pcbImgRipCol.Location = new System.Drawing.Point(161, 19);
			this.pcbImgRipCol.Name = "pcbImgRipCol";
			this.pcbImgRipCol.Size = new System.Drawing.Size(12, 224);
			this.pcbImgRipCol.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbImgRipCol.TabIndex = 30;
			this.pcbImgRipCol.TabStop = false;
			// 
			// lblImgColRip
			// 
			this.lblImgColRip.AutoSize = true;
			this.lblImgColRip.Location = new System.Drawing.Point(128, 211);
			this.lblImgColRip.Name = "lblImgColRip";
			this.lblImgColRip.Size = new System.Drawing.Size(25, 13);
			this.lblImgColRip.TabIndex = 29;
			this.lblImgColRip.Text = "000";
			// 
			// trbImgColRip
			// 
			this.trbImgColRip.Location = new System.Drawing.Point(6, 204);
			this.trbImgColRip.Maximum = 255;
			this.trbImgColRip.Name = "trbImgColRip";
			this.trbImgColRip.Size = new System.Drawing.Size(116, 45);
			this.trbImgColRip.TabIndex = 28;
			this.trbImgColRip.TickStyle = System.Windows.Forms.TickStyle.None;
			this.trbImgColRip.Scroll += new System.EventHandler(this.trbImgColRip_Scroll);
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(6, 188);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(76, 13);
			this.label31.TabIndex = 27;
			this.label31.Text = "Column to Rip:";
			// 
			// chbImgColCor
			// 
			this.chbImgColCor.AutoSize = true;
			this.chbImgColCor.Location = new System.Drawing.Point(9, 166);
			this.chbImgColCor.Name = "chbImgColCor";
			this.chbImgColCor.Size = new System.Drawing.Size(101, 17);
			this.chbImgColCor.TabIndex = 26;
			this.chbImgColCor.Text = "Color-Correction";
			this.chbImgColCor.UseVisualStyleBackColor = true;
			this.chbImgColCor.CheckedChanged += new System.EventHandler(this.chbImgColCor_CheckedChanged);
			// 
			// btnImgLoad
			// 
			this.btnImgLoad.Location = new System.Drawing.Point(6, 137);
			this.btnImgLoad.Name = "btnImgLoad";
			this.btnImgLoad.Size = new System.Drawing.Size(147, 23);
			this.btnImgLoad.TabIndex = 24;
			this.btnImgLoad.Text = "Load Image";
			this.btnImgLoad.UseVisualStyleBackColor = true;
			this.btnImgLoad.Click += new System.EventHandler(this.btnImgLoad_Click);
			// 
			// pcbImgImgRip
			// 
			this.pcbImgImgRip.BackColor = System.Drawing.SystemColors.ButtonShadow;
			this.pcbImgImgRip.Location = new System.Drawing.Point(9, 19);
			this.pcbImgImgRip.Name = "pcbImgImgRip";
			this.pcbImgImgRip.Size = new System.Drawing.Size(130, 112);
			this.pcbImgImgRip.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbImgImgRip.TabIndex = 23;
			this.pcbImgImgRip.TabStop = false;
			this.pcbImgImgRip.Click += new System.EventHandler(this.btnImgLoad_Click);
			// 
			// btnImgCod
			// 
			this.btnImgCod.Location = new System.Drawing.Point(132, 236);
			this.btnImgCod.Name = "btnImgCod";
			this.btnImgCod.Size = new System.Drawing.Size(57, 21);
			this.btnImgCod.TabIndex = 30;
			this.btnImgCod.Text = "Code";
			this.btnImgCod.UseVisualStyleBackColor = true;
			this.btnImgCod.Click += new System.EventHandler(this.btnImgCod_Click);
			// 
			// cmbImgScnSel
			// 
			this.cmbImgScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbImgScnSel.FormattingEnabled = true;
			this.cmbImgScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbImgScnSel.Name = "cmbImgScnSel";
			this.cmbImgScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbImgScnSel.TabIndex = 29;
			this.cmbImgScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbImgSrnSel_SelectedIndexChanged);
			// 
			// pcbImgMainPic
			// 
			this.pcbImgMainPic.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.pcbImgMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbImgMainPic.Name = "pcbImgMainPic";
			this.pcbImgMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbImgMainPic.TabIndex = 28;
			this.pcbImgMainPic.TabStop = false;
			// 
			// tabTable
			// 
			this.tabTable.BackColor = System.Drawing.SystemColors.Control;
			this.tabTable.Controls.Add(this.groupBox10);
			this.tabTable.Controls.Add(this.groupBox6);
			this.tabTable.Controls.Add(this.chbTblFivBit);
			this.tabTable.Controls.Add(this.btnTblCod);
			this.tabTable.Controls.Add(this.cmbTblScnSel);
			this.tabTable.Controls.Add(this.groupBox9);
			this.tabTable.Controls.Add(this.groupBox8);
			this.tabTable.Controls.Add(this.groupBox7);
			this.tabTable.Controls.Add(this.pcbTblMainPic);
			this.tabTable.Location = new System.Drawing.Point(4, 22);
			this.tabTable.Name = "tabTable";
			this.tabTable.Size = new System.Drawing.Size(667, 265);
			this.tabTable.TabIndex = 2;
			this.tabTable.Text = "Table";
			// 
			// groupBox10
			// 
			this.groupBox10.Location = new System.Drawing.Point(585, 102);
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.Size = new System.Drawing.Size(79, 158);
			this.groupBox10.TabIndex = 36;
			this.groupBox10.TabStop = false;
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.rdbTblSub);
			this.groupBox6.Controls.Add(this.rdbTblAdd);
			this.groupBox6.Controls.Add(this.chbTblHlf);
			this.groupBox6.Location = new System.Drawing.Point(585, 3);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(79, 93);
			this.groupBox6.TabIndex = 35;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "Color Math";
			// 
			// rdbTblSub
			// 
			this.rdbTblSub.AutoSize = true;
			this.rdbTblSub.Location = new System.Drawing.Point(6, 41);
			this.rdbTblSub.Name = "rdbTblSub";
			this.rdbTblSub.Size = new System.Drawing.Size(70, 17);
			this.rdbTblSub.TabIndex = 2;
			this.rdbTblSub.Text = "Substract";
			this.rdbTblSub.UseVisualStyleBackColor = true;
			// 
			// rdbTblAdd
			// 
			this.rdbTblAdd.AutoSize = true;
			this.rdbTblAdd.Checked = true;
			this.rdbTblAdd.Location = new System.Drawing.Point(6, 19);
			this.rdbTblAdd.Name = "rdbTblAdd";
			this.rdbTblAdd.Size = new System.Drawing.Size(63, 17);
			this.rdbTblAdd.TabIndex = 1;
			this.rdbTblAdd.TabStop = true;
			this.rdbTblAdd.Text = "Addition";
			this.rdbTblAdd.UseVisualStyleBackColor = true;
			this.rdbTblAdd.CheckedChanged += new System.EventHandler(this.tblMath_Changed);
			// 
			// chbTblHlf
			// 
			this.chbTblHlf.AutoSize = true;
			this.chbTblHlf.Location = new System.Drawing.Point(6, 64);
			this.chbTblHlf.Name = "chbTblHlf";
			this.chbTblHlf.Size = new System.Drawing.Size(45, 17);
			this.chbTblHlf.TabIndex = 0;
			this.chbTblHlf.Text = "Half";
			this.chbTblHlf.UseVisualStyleBackColor = true;
			this.chbTblHlf.CheckedChanged += new System.EventHandler(this.tblMath_Changed);
			// 
			// chbTblFivBit
			// 
			this.chbTblFivBit.AutoSize = true;
			this.chbTblFivBit.Location = new System.Drawing.Point(215, 238);
			this.chbTblFivBit.Name = "chbTblFivBit";
			this.chbTblFivBit.Size = new System.Drawing.Size(47, 17);
			this.chbTblFivBit.TabIndex = 34;
			this.chbTblFivBit.Text = "5 Bit";
			this.chbTblFivBit.UseVisualStyleBackColor = true;
			// 
			// btnTblCod
			// 
			this.btnTblCod.Location = new System.Drawing.Point(132, 236);
			this.btnTblCod.Name = "btnTblCod";
			this.btnTblCod.Size = new System.Drawing.Size(57, 21);
			this.btnTblCod.TabIndex = 33;
			this.btnTblCod.Text = "Code";
			this.btnTblCod.UseVisualStyleBackColor = true;
			this.btnTblCod.Click += new System.EventHandler(this.btnTblCod_Click);
			// 
			// cmbTblScnSel
			// 
			this.cmbTblScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTblScnSel.FormattingEnabled = true;
			this.cmbTblScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbTblScnSel.Name = "cmbTblScnSel";
			this.cmbTblScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbTblScnSel.TabIndex = 32;
			this.cmbTblScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbTblScnSel_SelectedIndexChanged);
			// 
			// groupBox9
			// 
			this.groupBox9.Controls.Add(this.pcbTblBlu);
			this.groupBox9.Controls.Add(this.splitContainer3);
			this.groupBox9.Location = new System.Drawing.Point(477, 3);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new System.Drawing.Size(102, 257);
			this.groupBox9.TabIndex = 19;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "Blue";
			// 
			// pcbTblBlu
			// 
			this.pcbTblBlu.BackColor = System.Drawing.Color.Black;
			this.pcbTblBlu.Location = new System.Drawing.Point(6, 16);
			this.pcbTblBlu.Name = "pcbTblBlu";
			this.pcbTblBlu.Size = new System.Drawing.Size(13, 224);
			this.pcbTblBlu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbTblBlu.TabIndex = 2;
			this.pcbTblBlu.TabStop = false;
			// 
			// splitContainer3
			// 
			this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Right;
			this.splitContainer3.Location = new System.Drawing.Point(27, 16);
			this.splitContainer3.Name = "splitContainer3";
			this.splitContainer3.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer3.Panel1
			// 
			this.splitContainer3.Panel1.Controls.Add(this.rtbTblBlu);
			// 
			// splitContainer3.Panel2
			// 
			this.splitContainer3.Panel2.Controls.Add(this.lsbTblBlu);
			this.splitContainer3.Size = new System.Drawing.Size(72, 238);
			this.splitContainer3.SplitterDistance = 175;
			this.splitContainer3.TabIndex = 0;
			// 
			// rtbTblBlu
			// 
			this.rtbTblBlu.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtbTblBlu.Location = new System.Drawing.Point(0, 0);
			this.rtbTblBlu.Name = "rtbTblBlu";
			this.rtbTblBlu.Size = new System.Drawing.Size(72, 175);
			this.rtbTblBlu.TabIndex = 0;
			this.rtbTblBlu.Text = "";
			this.rtbTblBlu.TextChanged += new System.EventHandler(this.rtbTblBlu_TextChanged);
			// 
			// lsbTblBlu
			// 
			this.lsbTblBlu.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lsbTblBlu.FormattingEnabled = true;
			this.lsbTblBlu.Location = new System.Drawing.Point(0, 0);
			this.lsbTblBlu.Name = "lsbTblBlu";
			this.lsbTblBlu.Size = new System.Drawing.Size(72, 59);
			this.lsbTblBlu.TabIndex = 0;
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.pcbTblGrn);
			this.groupBox8.Controls.Add(this.splitContainer2);
			this.groupBox8.Location = new System.Drawing.Point(374, 3);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(100, 257);
			this.groupBox8.TabIndex = 18;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Green";
			// 
			// pcbTblGrn
			// 
			this.pcbTblGrn.BackColor = System.Drawing.Color.Black;
			this.pcbTblGrn.Location = new System.Drawing.Point(6, 16);
			this.pcbTblGrn.Name = "pcbTblGrn";
			this.pcbTblGrn.Size = new System.Drawing.Size(13, 224);
			this.pcbTblGrn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbTblGrn.TabIndex = 2;
			this.pcbTblGrn.TabStop = false;
			// 
			// splitContainer2
			// 
			this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Right;
			this.splitContainer2.Location = new System.Drawing.Point(25, 16);
			this.splitContainer2.Name = "splitContainer2";
			this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer2.Panel1
			// 
			this.splitContainer2.Panel1.Controls.Add(this.rtbTblGrn);
			// 
			// splitContainer2.Panel2
			// 
			this.splitContainer2.Panel2.Controls.Add(this.lsbTblGrn);
			this.splitContainer2.Size = new System.Drawing.Size(72, 238);
			this.splitContainer2.SplitterDistance = 175;
			this.splitContainer2.TabIndex = 0;
			// 
			// rtbTblGrn
			// 
			this.rtbTblGrn.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtbTblGrn.Location = new System.Drawing.Point(0, 0);
			this.rtbTblGrn.Name = "rtbTblGrn";
			this.rtbTblGrn.Size = new System.Drawing.Size(72, 175);
			this.rtbTblGrn.TabIndex = 0;
			this.rtbTblGrn.Text = "";
			this.rtbTblGrn.TextChanged += new System.EventHandler(this.rtbTblGrn_TextChanged);
			// 
			// lsbTblGrn
			// 
			this.lsbTblGrn.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lsbTblGrn.FormattingEnabled = true;
			this.lsbTblGrn.Location = new System.Drawing.Point(0, 0);
			this.lsbTblGrn.Name = "lsbTblGrn";
			this.lsbTblGrn.Size = new System.Drawing.Size(72, 59);
			this.lsbTblGrn.TabIndex = 0;
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.pcbTblRed);
			this.groupBox7.Controls.Add(this.splitContainer1);
			this.groupBox7.Location = new System.Drawing.Point(268, 3);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(100, 257);
			this.groupBox7.TabIndex = 9;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Red";
			// 
			// pcbTblRed
			// 
			this.pcbTblRed.BackColor = System.Drawing.Color.Black;
			this.pcbTblRed.Location = new System.Drawing.Point(6, 16);
			this.pcbTblRed.Name = "pcbTblRed";
			this.pcbTblRed.Size = new System.Drawing.Size(13, 224);
			this.pcbTblRed.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbTblRed.TabIndex = 1;
			this.pcbTblRed.TabStop = false;
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Right;
			this.splitContainer1.Location = new System.Drawing.Point(25, 16);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.rtbTblRed);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.lsbTblRed);
			this.splitContainer1.Size = new System.Drawing.Size(72, 238);
			this.splitContainer1.SplitterDistance = 175;
			this.splitContainer1.TabIndex = 0;
			// 
			// rtbTblRed
			// 
			this.rtbTblRed.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtbTblRed.Location = new System.Drawing.Point(0, 0);
			this.rtbTblRed.Name = "rtbTblRed";
			this.rtbTblRed.Size = new System.Drawing.Size(72, 175);
			this.rtbTblRed.TabIndex = 0;
			this.rtbTblRed.Text = "";
			this.rtbTblRed.TextChanged += new System.EventHandler(this.rtbTblRed_TextChanged);
			// 
			// lsbTblRed
			// 
			this.lsbTblRed.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lsbTblRed.FormattingEnabled = true;
			this.lsbTblRed.Location = new System.Drawing.Point(0, 0);
			this.lsbTblRed.Name = "lsbTblRed";
			this.lsbTblRed.Size = new System.Drawing.Size(72, 59);
			this.lsbTblRed.TabIndex = 0;
			// 
			// pcbTblMainPic
			// 
			this.pcbTblMainPic.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.pcbTblMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbTblMainPic.Name = "pcbTblMainPic";
			this.pcbTblMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbTblMainPic.TabIndex = 31;
			this.pcbTblMainPic.TabStop = false;
			// 
			// HDMA_Gradiant_GUI
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(727, 324);
			this.Controls.Add(this.tbcMainControl);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.MaximizeBox = false;
			this.Name = "HDMA_Gradiant_GUI";
			this.ShowIcon = false;
			this.Text = " HDMA";
			this.tbcMainControl.ResumeLayout(false);
			this.tabSingle.ResumeLayout(false);
			this.tabSingle.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.grpSngChnAdv.ResumeLayout(false);
			this.groupBox20.ResumeLayout(false);
			this.groupBox20.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbSngBtm)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbSngTop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSngTop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSngBtm)).EndInit();
			this.grpSngChnStd.ResumeLayout(false);
			this.grpSngChnStd.PerformLayout();
			this.groupBox22.ResumeLayout(false);
			this.groupBox22.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbSngMainPic)).EndInit();
			this.tabMulti.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox21.ResumeLayout(false);
			this.groupBox21.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulRed)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulRedBot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulRedTop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulRedBot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulRedTop)).EndInit();
			this.groupBox23.ResumeLayout(false);
			this.groupBox23.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulGrn)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulGrnBot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulGrnTop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulGrnBot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulGrnTop)).EndInit();
			this.groupBox24.ResumeLayout(false);
			this.groupBox24.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulBlu)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulBluBot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbMulBluTop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulBluBot)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulBluTop)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbMulMainPic)).EndInit();
			this.tabPosition.ResumeLayout(false);
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox17.ResumeLayout(false);
			this.groupBox16.ResumeLayout(false);
			this.groupBox16.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosColBtm)).EndInit();
			this.groupBox15.ResumeLayout(false);
			this.groupBox15.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosColTop)).EndInit();
			this.groupBox14.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dgvPosColors)).EndInit();
			this.grpPosCurVal.ResumeLayout(false);
			this.grpPosCurVal.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudPosCurPos)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosCurCol)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbPosMainPic)).EndInit();
			this.tabDialog2.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox27.ResumeLayout(false);
			this.groupBox27.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudDiaScn)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbDiaCol)).EndInit();
			this.groupBox26.ResumeLayout(false);
			this.groupBox26.PerformLayout();
			this.groupBox25.ResumeLayout(false);
			this.groupBox25.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbDiaMainPic)).EndInit();
			this.tabImage2.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.grpImgCor.ResumeLayout(false);
			this.grpImgCor.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgRipColCor)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgColCor)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgCorBlu)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgCorGrn)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgCorRed)).EndInit();
			this.groupBox29.ResumeLayout(false);
			this.groupBox29.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgRipCol)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbImgColRip)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgImgRip)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbImgMainPic)).EndInit();
			this.tabTable.ResumeLayout(false);
			this.tabTable.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.groupBox6.PerformLayout();
			this.groupBox9.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pcbTblBlu)).EndInit();
			this.splitContainer3.Panel1.ResumeLayout(false);
			this.splitContainer3.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
			this.splitContainer3.ResumeLayout(false);
			this.groupBox8.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pcbTblGrn)).EndInit();
			this.splitContainer2.Panel1.ResumeLayout(false);
			this.splitContainer2.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
			this.splitContainer2.ResumeLayout(false);
			this.groupBox7.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pcbTblRed)).EndInit();
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
			this.splitContainer1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.pcbTblMainPic)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

		public System.Windows.Forms.TabControl tbcMainControl;
        private System.Windows.Forms.TabPage tabTable;
        private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.RichTextBox rtbTblRed;
        private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.ListBox lsbTblRed;
		private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.RichTextBox rtbTblGrn;
        private System.Windows.Forms.ListBox lsbTblGrn;
		private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.RichTextBox rtbTblBlu;
		private System.Windows.Forms.ListBox lsbTblBlu;
		private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.TabPage tabPosition;
        private System.Windows.Forms.PictureBox pcbPosColBtm;
        private System.Windows.Forms.PictureBox pcbPosColTop;
        private System.Windows.Forms.PictureBox pcbPosCurCol;
        private System.Windows.Forms.PictureBox pcbPosMainPic;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox txtPosColBtm;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.TextBox txtPosColTop;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.DataGridView dgvPosColors;
        private System.Windows.Forms.GroupBox grpPosCurVal;
        private System.Windows.Forms.Button btnPosNew;
        private System.Windows.Forms.TextBox txtPosCurCol;
        private System.Windows.Forms.NumericUpDown nudPosCurPos;
        private System.Windows.Forms.ComboBox cmbPosScnSel;
        private System.Windows.Forms.Button btnPosDel;
        private System.Windows.Forms.Button btnPosClr;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Button btnPosCpy;
        private System.Windows.Forms.DataGridViewTextBoxColumn colColor;
        private System.Windows.Forms.DataGridViewTextBoxColumn colColorString;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPosition;
        private System.Windows.Forms.TabPage tabSingle;
        private System.Windows.Forms.ComboBox cmbSngScnSel;
        private System.Windows.Forms.PictureBox pcbSngMainPic;
        private System.Windows.Forms.Button btnSngCode;
        private System.Windows.Forms.CheckBox chbSngCen;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.PictureBox pcbSngBtm;
        private System.Windows.Forms.PictureBox pcbSngTop;
        private System.Windows.Forms.TrackBar trbSngTop;
        private System.Windows.Forms.TrackBar trbSngBtm;
        private System.Windows.Forms.GroupBox grpSngChnStd;
        private System.Windows.Forms.RadioButton rdbSngCh3;
        private System.Windows.Forms.RadioButton rdbSngCh5;
        private System.Windows.Forms.RadioButton rdbSngCh4;
        private System.Windows.Forms.GroupBox groupBox22;
        private System.Windows.Forms.CheckBox chbSngBlu;
        private System.Windows.Forms.CheckBox chbSngRed;
        private System.Windows.Forms.CheckBox chbSngGrn;
        private System.Windows.Forms.GroupBox grpSngChnAdv;
        private System.Windows.Forms.ComboBox cmbSngChn;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.GroupBox groupBox19;
		private System.Windows.Forms.Button btnPosCod;
                                private System.Windows.Forms.TabPage tabMulti;
                                private System.Windows.Forms.Button btnMulCod;
                                private System.Windows.Forms.ComboBox cmbMulScnSel;
                                private System.Windows.Forms.PictureBox pcbMulMainPic;
                                private System.Windows.Forms.GroupBox groupBox21;
                                private System.Windows.Forms.Label label19;
                                private System.Windows.Forms.CheckBox chbMulRedCen;
                                private System.Windows.Forms.TrackBar trbMulRedBot;
                                private System.Windows.Forms.TrackBar trbMulRedTop;
                                private System.Windows.Forms.PictureBox pcbMulRedBot;
                                private System.Windows.Forms.PictureBox pcbMulRedTop;
                                private System.Windows.Forms.GroupBox groupBox23;
                                private System.Windows.Forms.Label label20;
                                private System.Windows.Forms.CheckBox chbMulGrnCen;
                                private System.Windows.Forms.TrackBar trbMulGrnBot;
                                private System.Windows.Forms.TrackBar trbMulGrnTop;
                                private System.Windows.Forms.PictureBox pcbMulGrnBot;
                                private System.Windows.Forms.PictureBox pcbMulGrnTop;
                                private System.Windows.Forms.GroupBox groupBox24;
                                private System.Windows.Forms.Label label21;
                                private System.Windows.Forms.CheckBox chbMulBluCen;
                                private System.Windows.Forms.TrackBar trbMulBluBot;
                                private System.Windows.Forms.TrackBar trbMulBluTop;
                                private System.Windows.Forms.PictureBox pcbMulBluBot;
                                private System.Windows.Forms.PictureBox pcbMulBluTop;
                                private System.Windows.Forms.PictureBox pcbMulRed;
                                private System.Windows.Forms.PictureBox pcbMulGrn;
                                private System.Windows.Forms.PictureBox pcbMulBlu;
                                private System.Windows.Forms.TabPage tabDialog2;
                                private System.Windows.Forms.GroupBox groupBox27;
                                private System.Windows.Forms.Label label25;
                                private System.Windows.Forms.Label label24;
                                private System.Windows.Forms.NumericUpDown nudDiaScn;
                                private System.Windows.Forms.TextBox txtDiaCol;
                                private System.Windows.Forms.PictureBox pcbDiaCol;
                                private System.Windows.Forms.GroupBox groupBox26;
                                private System.Windows.Forms.Label label18;
                                private System.Windows.Forms.Label label22;
                                private System.Windows.Forms.Label label23;
                                private System.Windows.Forms.ListBox lsbDiaBlu;
                                private System.Windows.Forms.ListBox lsbDiaGrn;
                                private System.Windows.Forms.ListBox lsbDiaRed;
                                private System.Windows.Forms.GroupBox groupBox25;
                                private System.Windows.Forms.Button btnDiaClr;
                                private System.Windows.Forms.Button btnDiaMovUp;
                                private System.Windows.Forms.Button btnDiaMovDwn;
                                private System.Windows.Forms.Button btnDiaRmv;
                                private System.Windows.Forms.Button btnDiaAdd;
                                private System.Windows.Forms.Button btnDiaCod;
                                private System.Windows.Forms.ComboBox cmbDiaScnSel;
                                private System.Windows.Forms.PictureBox pcbDiaMainPic;
                                private System.Windows.Forms.Label lblDiaWarn;
                                private System.Windows.Forms.CheckBox chbDiaEnd;
								private System.Windows.Forms.TabPage tabImage2;
								private System.Windows.Forms.GroupBox grpImgCor;
								private System.Windows.Forms.Label label26;
								private System.Windows.Forms.Label label27;
								private System.Windows.Forms.Label label28;
								private System.Windows.Forms.Label label29;
								private System.Windows.Forms.PictureBox pcbImgColCor;
								private System.Windows.Forms.TextBox txtImgCorBlu;
								private System.Windows.Forms.TextBox txtImgCorGrn;
								private System.Windows.Forms.TextBox txtImgCorRed;
								private System.Windows.Forms.TrackBar trbImgCorBlu;
								private System.Windows.Forms.TrackBar trbImgCorGrn;
								private System.Windows.Forms.TrackBar trbImgCorRed;
								private System.Windows.Forms.GroupBox groupBox29;
								private System.Windows.Forms.Label lblImgColRip;
								private System.Windows.Forms.TrackBar trbImgColRip;
								private System.Windows.Forms.Label label31;
                                private System.Windows.Forms.CheckBox chbImgColCor;
								private System.Windows.Forms.Button btnImgLoad;
								private System.Windows.Forms.PictureBox pcbImgImgRip;
								private System.Windows.Forms.Button btnImgCod;
								private System.Windows.Forms.ComboBox cmbImgScnSel;
								private System.Windows.Forms.PictureBox pcbImgMainPic;
                                private System.Windows.Forms.PictureBox pcbImgRipCol;
								private System.Windows.Forms.PictureBox pcbImgRipColCor;
                                private System.Windows.Forms.TextBox txtImgColCor;
                                private System.Windows.Forms.Button btnTblCod;
                                private System.Windows.Forms.ComboBox cmbTblScnSel;
                                private System.Windows.Forms.PictureBox pcbTblMainPic;
                                private System.Windows.Forms.CheckBox chbTblFivBit;
								private System.Windows.Forms.PictureBox pcbTblBlu;
								private System.Windows.Forms.PictureBox pcbTblGrn;
								private System.Windows.Forms.PictureBox pcbTblRed;
                                private System.Windows.Forms.GroupBox groupBox1;
                                private System.Windows.Forms.RadioButton rdbSngSub;
                                private System.Windows.Forms.RadioButton rdbSngAdd;
                                private System.Windows.Forms.CheckBox chbSngHlf;
                                private System.Windows.Forms.GroupBox groupBox30;
                                private System.Windows.Forms.GroupBox groupBox2;
                                private System.Windows.Forms.RadioButton rdbMulSub;
                                private System.Windows.Forms.RadioButton rdbMulAdd;
                                private System.Windows.Forms.CheckBox chbMulHlf;
                                private System.Windows.Forms.GroupBox groupBox28;
                                private System.Windows.Forms.GroupBox groupBox3;
                                private System.Windows.Forms.RadioButton rdbPosSub;
                                private System.Windows.Forms.RadioButton rdbPosAdd;
                                private System.Windows.Forms.CheckBox chbPosHlf;
                                private System.Windows.Forms.GroupBox groupBox12;
                                private System.Windows.Forms.GroupBox groupBox4;
                                private System.Windows.Forms.RadioButton rdbDiaSub;
                                private System.Windows.Forms.RadioButton rdbDiaAdd;
                                private System.Windows.Forms.CheckBox chbDiaHlf;
                                private System.Windows.Forms.GroupBox groupBox11;
                                private System.Windows.Forms.GroupBox groupBox5;
                                private System.Windows.Forms.RadioButton rdbImgSub;
                                private System.Windows.Forms.RadioButton rdbImgAdd;
                                private System.Windows.Forms.CheckBox chbImgHlf;
                                private System.Windows.Forms.GroupBox groupBox10;
                                private System.Windows.Forms.GroupBox groupBox6;
                                private System.Windows.Forms.RadioButton rdbTblSub;
                                private System.Windows.Forms.RadioButton rdbTblAdd;
                                private System.Windows.Forms.CheckBox chbTblHlf;
                                private System.Windows.Forms.GroupBox groupBox31;
    }
}