﻿namespace HDMA_Generator_Tool
{
    partial class HDMA_Brightness_GUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			this.tbc = new System.Windows.Forms.TabControl();
			this.tbgSimple = new System.Windows.Forms.TabPage();
			this.grpSngChnAdv = new System.Windows.Forms.GroupBox();
			this.cmbSmpChn = new System.Windows.Forms.ComboBox();
			this.groupBox11 = new System.Windows.Forms.GroupBox();
			this.grpSngChnStd = new System.Windows.Forms.GroupBox();
			this.rdbSmpCh5 = new System.Windows.Forms.RadioButton();
			this.rdbSmpCh4 = new System.Windows.Forms.RadioButton();
			this.rdbSmpCh3 = new System.Windows.Forms.RadioButton();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.nudSmpBtmRea = new System.Windows.Forms.NumericUpDown();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.txtSmpBtmStr = new System.Windows.Forms.TextBox();
			this.trbSmpBtmRea = new System.Windows.Forms.TrackBar();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.nudSmpTopRea = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.txtSmpTopStr = new System.Windows.Forms.TextBox();
			this.trbSmpTopRea = new System.Windows.Forms.TrackBar();
			this.pcbSmpMainPic = new System.Windows.Forms.PictureBox();
			this.cmbSmpScnSel = new System.Windows.Forms.ComboBox();
			this.btnSmpCod = new System.Windows.Forms.Button();
			this.tbgIndividual = new System.Windows.Forms.TabPage();
			this.grpIndChnAdv = new System.Windows.Forms.GroupBox();
			this.cmbIndChn = new System.Windows.Forms.ComboBox();
			this.chbIndEnd = new System.Windows.Forms.CheckBox();
			this.grpIndChnStd = new System.Windows.Forms.GroupBox();
			this.rdbIndCh5 = new System.Windows.Forms.RadioButton();
			this.rdbIndCh4 = new System.Windows.Forms.RadioButton();
			this.rdbIndCh3 = new System.Windows.Forms.RadioButton();
			this.groupBox12 = new System.Windows.Forms.GroupBox();
			this.lsbIndEnt = new System.Windows.Forms.ListBox();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.btnIndDwn = new System.Windows.Forms.Button();
			this.btnIndUp = new System.Windows.Forms.Button();
			this.btnIndClr = new System.Windows.Forms.Button();
			this.btnIndRmv = new System.Windows.Forms.Button();
			this.btnIndAdd = new System.Windows.Forms.Button();
			this.label11 = new System.Windows.Forms.Label();
			this.label12 = new System.Windows.Forms.Label();
			this.nudIndLin = new System.Windows.Forms.NumericUpDown();
			this.txtIndBri = new System.Windows.Forms.TextBox();
			this.pcbIndMainPic = new System.Windows.Forms.PictureBox();
			this.cmbIndScnSel = new System.Windows.Forms.ComboBox();
			this.btnIndCod = new System.Windows.Forms.Button();
			this.tbgTable = new System.Windows.Forms.TabPage();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox15 = new System.Windows.Forms.GroupBox();
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.rtbTblEnt = new System.Windows.Forms.RichTextBox();
			this.lsbTblWrn = new System.Windows.Forms.ListBox();
			this.grpTblChnAdv = new System.Windows.Forms.GroupBox();
			this.cmbTblChn = new System.Windows.Forms.ComboBox();
			this.grpTblChnSmp = new System.Windows.Forms.GroupBox();
			this.rdbTblCh5 = new System.Windows.Forms.RadioButton();
			this.rdbTblCh4 = new System.Windows.Forms.RadioButton();
			this.rdbTblCh3 = new System.Windows.Forms.RadioButton();
			this.pcbTblMainPic = new System.Windows.Forms.PictureBox();
			this.cmbTblScnSel = new System.Windows.Forms.ComboBox();
			this.btnTblCod = new System.Windows.Forms.Button();
			this.toolTip = new System.Windows.Forms.ToolTip(this.components);
			this.tbc.SuspendLayout();
			this.tbgSimple.SuspendLayout();
			this.grpSngChnAdv.SuspendLayout();
			this.grpSngChnStd.SuspendLayout();
			this.groupBox9.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudSmpBtmRea)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSmpBtmRea)).BeginInit();
			this.groupBox8.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudSmpTopRea)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSmpTopRea)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbSmpMainPic)).BeginInit();
			this.tbgIndividual.SuspendLayout();
			this.grpIndChnAdv.SuspendLayout();
			this.grpIndChnStd.SuspendLayout();
			this.groupBox12.SuspendLayout();
			this.groupBox10.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudIndLin)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbIndMainPic)).BeginInit();
			this.tbgTable.SuspendLayout();
			this.groupBox15.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			this.grpTblChnAdv.SuspendLayout();
			this.grpTblChnSmp.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbTblMainPic)).BeginInit();
			this.SuspendLayout();
			// 
			// tbc
			// 
			this.tbc.Controls.Add(this.tbgSimple);
			this.tbc.Controls.Add(this.tbgIndividual);
			this.tbc.Controls.Add(this.tbgTable);
			this.tbc.Location = new System.Drawing.Point(0, 30);
			this.tbc.Name = "tbc";
			this.tbc.SelectedIndex = 0;
			this.tbc.Size = new System.Drawing.Size(486, 291);
			this.tbc.TabIndex = 1;
			// 
			// tbgSimple
			// 
			this.tbgSimple.BackColor = System.Drawing.SystemColors.Control;
			this.tbgSimple.Controls.Add(this.grpSngChnAdv);
			this.tbgSimple.Controls.Add(this.groupBox11);
			this.tbgSimple.Controls.Add(this.grpSngChnStd);
			this.tbgSimple.Controls.Add(this.groupBox9);
			this.tbgSimple.Controls.Add(this.groupBox8);
			this.tbgSimple.Controls.Add(this.pcbSmpMainPic);
			this.tbgSimple.Controls.Add(this.cmbSmpScnSel);
			this.tbgSimple.Controls.Add(this.btnSmpCod);
			this.tbgSimple.Location = new System.Drawing.Point(4, 22);
			this.tbgSimple.Name = "tbgSimple";
			this.tbgSimple.Size = new System.Drawing.Size(478, 265);
			this.tbgSimple.TabIndex = 2;
			this.tbgSimple.Text = "Simple";
			// 
			// grpSngChnAdv
			// 
			this.grpSngChnAdv.Controls.Add(this.cmbSmpChn);
			this.grpSngChnAdv.Location = new System.Drawing.Point(396, 6);
			this.grpSngChnAdv.Name = "grpSngChnAdv";
			this.grpSngChnAdv.Size = new System.Drawing.Size(60, 96);
			this.grpSngChnAdv.TabIndex = 39;
			this.grpSngChnAdv.TabStop = false;
			this.grpSngChnAdv.Text = "Channel";
			this.grpSngChnAdv.Visible = false;
			// 
			// cmbSmpChn
			// 
			this.cmbSmpChn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSmpChn.FormattingEnabled = true;
			this.cmbSmpChn.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
			this.cmbSmpChn.Location = new System.Drawing.Point(6, 19);
			this.cmbSmpChn.Name = "cmbSmpChn";
			this.cmbSmpChn.Size = new System.Drawing.Size(48, 21);
			this.cmbSmpChn.TabIndex = 0;
			this.cmbSmpChn.SelectedIndexChanged += new System.EventHandler(this.cmbSmpChn_SelectedIndexChanged);
			// 
			// groupBox11
			// 
			this.groupBox11.Location = new System.Drawing.Point(396, 108);
			this.groupBox11.Name = "groupBox11";
			this.groupBox11.Size = new System.Drawing.Size(60, 151);
			this.groupBox11.TabIndex = 38;
			this.groupBox11.TabStop = false;
			// 
			// grpSngChnStd
			// 
			this.grpSngChnStd.Controls.Add(this.rdbSmpCh5);
			this.grpSngChnStd.Controls.Add(this.rdbSmpCh4);
			this.grpSngChnStd.Controls.Add(this.rdbSmpCh3);
			this.grpSngChnStd.Location = new System.Drawing.Point(396, 6);
			this.grpSngChnStd.Name = "grpSngChnStd";
			this.grpSngChnStd.Size = new System.Drawing.Size(60, 96);
			this.grpSngChnStd.TabIndex = 37;
			this.grpSngChnStd.TabStop = false;
			this.grpSngChnStd.Text = "Channel";
			// 
			// rdbSmpCh5
			// 
			this.rdbSmpCh5.AutoSize = true;
			this.rdbSmpCh5.Location = new System.Drawing.Point(6, 65);
			this.rdbSmpCh5.Name = "rdbSmpCh5";
			this.rdbSmpCh5.Size = new System.Drawing.Size(49, 17);
			this.rdbSmpCh5.TabIndex = 2;
			this.rdbSmpCh5.Text = "CH 5";
			this.rdbSmpCh5.UseVisualStyleBackColor = true;
			this.rdbSmpCh5.CheckedChanged += new System.EventHandler(this.rdbSmpCh_CheckedChanged);
			// 
			// rdbSmpCh4
			// 
			this.rdbSmpCh4.AutoSize = true;
			this.rdbSmpCh4.Location = new System.Drawing.Point(6, 42);
			this.rdbSmpCh4.Name = "rdbSmpCh4";
			this.rdbSmpCh4.Size = new System.Drawing.Size(49, 17);
			this.rdbSmpCh4.TabIndex = 1;
			this.rdbSmpCh4.Text = "CH 4";
			this.rdbSmpCh4.UseVisualStyleBackColor = true;
			this.rdbSmpCh4.CheckedChanged += new System.EventHandler(this.rdbSmpCh_CheckedChanged);
			// 
			// rdbSmpCh3
			// 
			this.rdbSmpCh3.AutoSize = true;
			this.rdbSmpCh3.Checked = true;
			this.rdbSmpCh3.Location = new System.Drawing.Point(6, 19);
			this.rdbSmpCh3.Name = "rdbSmpCh3";
			this.rdbSmpCh3.Size = new System.Drawing.Size(49, 17);
			this.rdbSmpCh3.TabIndex = 0;
			this.rdbSmpCh3.TabStop = true;
			this.rdbSmpCh3.Text = "CH 3";
			this.rdbSmpCh3.UseVisualStyleBackColor = true;
			this.rdbSmpCh3.CheckedChanged += new System.EventHandler(this.rdbSmpCh_CheckedChanged);
			// 
			// groupBox9
			// 
			this.groupBox9.Controls.Add(this.nudSmpBtmRea);
			this.groupBox9.Controls.Add(this.label9);
			this.groupBox9.Controls.Add(this.label10);
			this.groupBox9.Controls.Add(this.txtSmpBtmStr);
			this.groupBox9.Controls.Add(this.trbSmpBtmRea);
			this.groupBox9.Location = new System.Drawing.Point(332, 6);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new System.Drawing.Size(58, 253);
			this.groupBox9.TabIndex = 36;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "Bottom";
			// 
			// nudSmpBtmRea
			// 
			this.nudSmpBtmRea.Location = new System.Drawing.Point(6, 227);
			this.nudSmpBtmRea.Maximum = new decimal(new int[] {
            224,
            0,
            0,
            0});
			this.nudSmpBtmRea.Name = "nudSmpBtmRea";
			this.nudSmpBtmRea.Size = new System.Drawing.Size(42, 20);
			this.nudSmpBtmRea.TabIndex = 7;
			this.nudSmpBtmRea.ValueChanged += new System.EventHandler(this.nudSmpBtmRea_ValueChanged);
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(6, 39);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(42, 13);
			this.label9.TabIndex = 6;
			this.label9.Text = "Reach:";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(6, 16);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(32, 13);
			this.label10.TabIndex = 4;
			this.label10.Text = "Start:";
			// 
			// txtSmpBtmStr
			// 
			this.txtSmpBtmStr.Location = new System.Drawing.Point(39, 16);
			this.txtSmpBtmStr.MaxLength = 1;
			this.txtSmpBtmStr.Name = "txtSmpBtmStr";
			this.txtSmpBtmStr.Size = new System.Drawing.Size(15, 20);
			this.txtSmpBtmStr.TabIndex = 3;
			this.txtSmpBtmStr.Text = "0";
			this.txtSmpBtmStr.TextChanged += new System.EventHandler(this.txtSmp_TextChanged);
			this.txtSmpBtmStr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSmp_KeyPress);
			// 
			// trbSmpBtmRea
			// 
			this.trbSmpBtmRea.LargeChange = 10;
			this.trbSmpBtmRea.Location = new System.Drawing.Point(9, 55);
			this.trbSmpBtmRea.Maximum = 224;
			this.trbSmpBtmRea.Name = "trbSmpBtmRea";
			this.trbSmpBtmRea.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbSmpBtmRea.Size = new System.Drawing.Size(45, 169);
			this.trbSmpBtmRea.TabIndex = 1;
			this.trbSmpBtmRea.Scroll += new System.EventHandler(this.trbSmpBtmRea_Scroll);
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.nudSmpTopRea);
			this.groupBox8.Controls.Add(this.label7);
			this.groupBox8.Controls.Add(this.label8);
			this.groupBox8.Controls.Add(this.txtSmpTopStr);
			this.groupBox8.Controls.Add(this.trbSmpTopRea);
			this.groupBox8.Location = new System.Drawing.Point(268, 6);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(58, 253);
			this.groupBox8.TabIndex = 35;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Top";
			// 
			// nudSmpTopRea
			// 
			this.nudSmpTopRea.Location = new System.Drawing.Point(6, 227);
			this.nudSmpTopRea.Maximum = new decimal(new int[] {
            224,
            0,
            0,
            0});
			this.nudSmpTopRea.Name = "nudSmpTopRea";
			this.nudSmpTopRea.Size = new System.Drawing.Size(42, 20);
			this.nudSmpTopRea.TabIndex = 7;
			this.nudSmpTopRea.ValueChanged += new System.EventHandler(this.nudSmpTopRea_ValueChanged);
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(6, 39);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(42, 13);
			this.label7.TabIndex = 6;
			this.label7.Text = "Reach:";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(6, 16);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(32, 13);
			this.label8.TabIndex = 4;
			this.label8.Text = "Start:";
			// 
			// txtSmpTopStr
			// 
			this.txtSmpTopStr.Location = new System.Drawing.Point(39, 16);
			this.txtSmpTopStr.MaxLength = 1;
			this.txtSmpTopStr.Name = "txtSmpTopStr";
			this.txtSmpTopStr.Size = new System.Drawing.Size(15, 20);
			this.txtSmpTopStr.TabIndex = 3;
			this.txtSmpTopStr.Text = "0";
			this.txtSmpTopStr.TextChanged += new System.EventHandler(this.txtSmp_TextChanged);
			this.txtSmpTopStr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSmp_KeyPress);
			// 
			// trbSmpTopRea
			// 
			this.trbSmpTopRea.LargeChange = 10;
			this.trbSmpTopRea.Location = new System.Drawing.Point(9, 55);
			this.trbSmpTopRea.Maximum = 224;
			this.trbSmpTopRea.Name = "trbSmpTopRea";
			this.trbSmpTopRea.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trbSmpTopRea.Size = new System.Drawing.Size(45, 169);
			this.trbSmpTopRea.TabIndex = 1;
			this.trbSmpTopRea.Value = 224;
			this.trbSmpTopRea.Scroll += new System.EventHandler(this.trbSmpReaTop_Scroll);
			// 
			// pcbSmpMainPic
			// 
			this.pcbSmpMainPic.BackColor = System.Drawing.Color.Black;
			this.pcbSmpMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbSmpMainPic.Name = "pcbSmpMainPic";
			this.pcbSmpMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbSmpMainPic.TabIndex = 34;
			this.pcbSmpMainPic.TabStop = false;
			// 
			// cmbSmpScnSel
			// 
			this.cmbSmpScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbSmpScnSel.FormattingEnabled = true;
			this.cmbSmpScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbSmpScnSel.Name = "cmbSmpScnSel";
			this.cmbSmpScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbSmpScnSel.TabIndex = 33;
			this.cmbSmpScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbSmpScnSel_SelectedIndexChanged);
			// 
			// btnSmpCod
			// 
			this.btnSmpCod.Location = new System.Drawing.Point(132, 236);
			this.btnSmpCod.Name = "btnSmpCod";
			this.btnSmpCod.Size = new System.Drawing.Size(57, 21);
			this.btnSmpCod.TabIndex = 32;
			this.btnSmpCod.Text = "Code";
			this.btnSmpCod.UseVisualStyleBackColor = true;
			this.btnSmpCod.Click += new System.EventHandler(this.btnSmpCod_Click);
			// 
			// tbgIndividual
			// 
			this.tbgIndividual.BackColor = System.Drawing.SystemColors.Control;
			this.tbgIndividual.Controls.Add(this.grpIndChnAdv);
			this.tbgIndividual.Controls.Add(this.chbIndEnd);
			this.tbgIndividual.Controls.Add(this.grpIndChnStd);
			this.tbgIndividual.Controls.Add(this.groupBox12);
			this.tbgIndividual.Controls.Add(this.groupBox10);
			this.tbgIndividual.Controls.Add(this.pcbIndMainPic);
			this.tbgIndividual.Controls.Add(this.cmbIndScnSel);
			this.tbgIndividual.Controls.Add(this.btnIndCod);
			this.tbgIndividual.Location = new System.Drawing.Point(4, 22);
			this.tbgIndividual.Name = "tbgIndividual";
			this.tbgIndividual.Size = new System.Drawing.Size(478, 265);
			this.tbgIndividual.TabIndex = 3;
			this.tbgIndividual.Text = "Individual";
			// 
			// grpIndChnAdv
			// 
			this.grpIndChnAdv.Controls.Add(this.cmbIndChn);
			this.grpIndChnAdv.Location = new System.Drawing.Point(346, 163);
			this.grpIndChnAdv.Name = "grpIndChnAdv";
			this.grpIndChnAdv.Size = new System.Drawing.Size(60, 96);
			this.grpIndChnAdv.TabIndex = 42;
			this.grpIndChnAdv.TabStop = false;
			this.grpIndChnAdv.Text = "Channel";
			this.grpIndChnAdv.Visible = false;
			// 
			// cmbIndChn
			// 
			this.cmbIndChn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbIndChn.FormattingEnabled = true;
			this.cmbIndChn.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
			this.cmbIndChn.Location = new System.Drawing.Point(6, 19);
			this.cmbIndChn.Name = "cmbIndChn";
			this.cmbIndChn.Size = new System.Drawing.Size(48, 21);
			this.cmbIndChn.TabIndex = 0;
			this.cmbIndChn.SelectedIndexChanged += new System.EventHandler(this.cmbIndChn_SelectedIndexChanged);
			// 
			// chbIndEnd
			// 
			this.chbIndEnd.AutoSize = true;
			this.chbIndEnd.Checked = true;
			this.chbIndEnd.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbIndEnd.Location = new System.Drawing.Point(411, 167);
			this.chbIndEnd.Name = "chbIndEnd";
			this.chbIndEnd.Size = new System.Drawing.Size(58, 30);
			this.chbIndEnd.TabIndex = 41;
			this.chbIndEnd.Text = "End\r\nHDMA";
			this.chbIndEnd.UseVisualStyleBackColor = true;
			// 
			// grpIndChnStd
			// 
			this.grpIndChnStd.Controls.Add(this.rdbIndCh5);
			this.grpIndChnStd.Controls.Add(this.rdbIndCh4);
			this.grpIndChnStd.Controls.Add(this.rdbIndCh3);
			this.grpIndChnStd.Location = new System.Drawing.Point(346, 163);
			this.grpIndChnStd.Name = "grpIndChnStd";
			this.grpIndChnStd.Size = new System.Drawing.Size(60, 96);
			this.grpIndChnStd.TabIndex = 40;
			this.grpIndChnStd.TabStop = false;
			this.grpIndChnStd.Text = "Channel";
			// 
			// rdbIndCh5
			// 
			this.rdbIndCh5.AutoSize = true;
			this.rdbIndCh5.Location = new System.Drawing.Point(6, 65);
			this.rdbIndCh5.Name = "rdbIndCh5";
			this.rdbIndCh5.Size = new System.Drawing.Size(49, 17);
			this.rdbIndCh5.TabIndex = 2;
			this.rdbIndCh5.Text = "CH 5";
			this.rdbIndCh5.UseVisualStyleBackColor = true;
			this.rdbIndCh5.CheckedChanged += new System.EventHandler(this.rdbIndChn_CheckedChanged);
			// 
			// rdbIndCh4
			// 
			this.rdbIndCh4.AutoSize = true;
			this.rdbIndCh4.Location = new System.Drawing.Point(6, 42);
			this.rdbIndCh4.Name = "rdbIndCh4";
			this.rdbIndCh4.Size = new System.Drawing.Size(49, 17);
			this.rdbIndCh4.TabIndex = 1;
			this.rdbIndCh4.Text = "CH 4";
			this.rdbIndCh4.UseVisualStyleBackColor = true;
			this.rdbIndCh4.CheckedChanged += new System.EventHandler(this.rdbIndChn_CheckedChanged);
			// 
			// rdbIndCh3
			// 
			this.rdbIndCh3.AutoSize = true;
			this.rdbIndCh3.Checked = true;
			this.rdbIndCh3.Location = new System.Drawing.Point(6, 19);
			this.rdbIndCh3.Name = "rdbIndCh3";
			this.rdbIndCh3.Size = new System.Drawing.Size(49, 17);
			this.rdbIndCh3.TabIndex = 0;
			this.rdbIndCh3.TabStop = true;
			this.rdbIndCh3.Text = "CH 3";
			this.rdbIndCh3.UseVisualStyleBackColor = true;
			this.rdbIndCh3.CheckedChanged += new System.EventHandler(this.rdbIndChn_CheckedChanged);
			// 
			// groupBox12
			// 
			this.groupBox12.Controls.Add(this.lsbIndEnt);
			this.groupBox12.Location = new System.Drawing.Point(346, 6);
			this.groupBox12.Name = "groupBox12";
			this.groupBox12.Size = new System.Drawing.Size(123, 151);
			this.groupBox12.TabIndex = 39;
			this.groupBox12.TabStop = false;
			this.groupBox12.Text = "Entries";
			// 
			// lsbIndEnt
			// 
			this.lsbIndEnt.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lsbIndEnt.FormattingEnabled = true;
			this.lsbIndEnt.Location = new System.Drawing.Point(3, 16);
			this.lsbIndEnt.Name = "lsbIndEnt";
			this.lsbIndEnt.Size = new System.Drawing.Size(117, 132);
			this.lsbIndEnt.TabIndex = 25;
			// 
			// groupBox10
			// 
			this.groupBox10.Controls.Add(this.btnIndDwn);
			this.groupBox10.Controls.Add(this.btnIndUp);
			this.groupBox10.Controls.Add(this.btnIndClr);
			this.groupBox10.Controls.Add(this.btnIndRmv);
			this.groupBox10.Controls.Add(this.btnIndAdd);
			this.groupBox10.Controls.Add(this.label11);
			this.groupBox10.Controls.Add(this.label12);
			this.groupBox10.Controls.Add(this.nudIndLin);
			this.groupBox10.Controls.Add(this.txtIndBri);
			this.groupBox10.Location = new System.Drawing.Point(268, 6);
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.Size = new System.Drawing.Size(72, 251);
			this.groupBox10.TabIndex = 38;
			this.groupBox10.TabStop = false;
			this.groupBox10.Text = "Control";
			// 
			// btnIndDwn
			// 
			this.btnIndDwn.Location = new System.Drawing.Point(9, 219);
			this.btnIndDwn.Name = "btnIndDwn";
			this.btnIndDwn.Size = new System.Drawing.Size(56, 23);
			this.btnIndDwn.TabIndex = 27;
			this.btnIndDwn.Text = "Down";
			this.btnIndDwn.UseVisualStyleBackColor = true;
			this.btnIndDwn.Click += new System.EventHandler(this.btnIndDwn_Click);
			// 
			// btnIndUp
			// 
			this.btnIndUp.Location = new System.Drawing.Point(9, 190);
			this.btnIndUp.Name = "btnIndUp";
			this.btnIndUp.Size = new System.Drawing.Size(56, 23);
			this.btnIndUp.TabIndex = 26;
			this.btnIndUp.Text = "Up";
			this.btnIndUp.UseVisualStyleBackColor = true;
			this.btnIndUp.Click += new System.EventHandler(this.btnIndUp_Click);
			// 
			// btnIndClr
			// 
			this.btnIndClr.Location = new System.Drawing.Point(9, 161);
			this.btnIndClr.Name = "btnIndClr";
			this.btnIndClr.Size = new System.Drawing.Size(56, 23);
			this.btnIndClr.TabIndex = 24;
			this.btnIndClr.Text = "Clear";
			this.btnIndClr.UseVisualStyleBackColor = true;
			this.btnIndClr.Click += new System.EventHandler(this.btnIndClr_Click);
			// 
			// btnIndRmv
			// 
			this.btnIndRmv.Location = new System.Drawing.Point(9, 132);
			this.btnIndRmv.Name = "btnIndRmv";
			this.btnIndRmv.Size = new System.Drawing.Size(56, 23);
			this.btnIndRmv.TabIndex = 23;
			this.btnIndRmv.Text = "Remove";
			this.btnIndRmv.UseVisualStyleBackColor = true;
			this.btnIndRmv.Click += new System.EventHandler(this.btnIndRmv_Click);
			// 
			// btnIndAdd
			// 
			this.btnIndAdd.Location = new System.Drawing.Point(9, 103);
			this.btnIndAdd.Name = "btnIndAdd";
			this.btnIndAdd.Size = new System.Drawing.Size(56, 23);
			this.btnIndAdd.TabIndex = 22;
			this.btnIndAdd.Text = "Add";
			this.btnIndAdd.UseVisualStyleBackColor = true;
			this.btnIndAdd.Click += new System.EventHandler(this.btnIndAdd_Click);
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(6, 58);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(59, 13);
			this.label11.TabIndex = 21;
			this.label11.Text = "Brightness:";
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(6, 16);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(56, 13);
			this.label12.TabIndex = 20;
			this.label12.Text = "Scanlines:";
			// 
			// nudIndLin
			// 
			this.nudIndLin.Location = new System.Drawing.Point(9, 35);
			this.nudIndLin.Maximum = new decimal(new int[] {
            128,
            0,
            0,
            0});
			this.nudIndLin.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
			this.nudIndLin.Name = "nudIndLin";
			this.nudIndLin.Size = new System.Drawing.Size(53, 20);
			this.nudIndLin.TabIndex = 19;
			this.nudIndLin.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
			// 
			// txtIndBri
			// 
			this.txtIndBri.Location = new System.Drawing.Point(9, 77);
			this.txtIndBri.MaxLength = 4;
			this.txtIndBri.Name = "txtIndBri";
			this.txtIndBri.Size = new System.Drawing.Size(56, 20);
			this.txtIndBri.TabIndex = 17;
			this.txtIndBri.Text = "100%";
			this.txtIndBri.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIndBri_KeyPress);
			// 
			// pcbIndMainPic
			// 
			this.pcbIndMainPic.BackColor = System.Drawing.Color.Black;
			this.pcbIndMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbIndMainPic.Name = "pcbIndMainPic";
			this.pcbIndMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbIndMainPic.TabIndex = 37;
			this.pcbIndMainPic.TabStop = false;
			// 
			// cmbIndScnSel
			// 
			this.cmbIndScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbIndScnSel.FormattingEnabled = true;
			this.cmbIndScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbIndScnSel.Name = "cmbIndScnSel";
			this.cmbIndScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbIndScnSel.TabIndex = 36;
			this.cmbIndScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbIndScnSel_SelectedIndexChanged);
			// 
			// btnIndCod
			// 
			this.btnIndCod.Location = new System.Drawing.Point(132, 236);
			this.btnIndCod.Name = "btnIndCod";
			this.btnIndCod.Size = new System.Drawing.Size(57, 21);
			this.btnIndCod.TabIndex = 35;
			this.btnIndCod.Text = "Code";
			this.btnIndCod.UseVisualStyleBackColor = true;
			this.btnIndCod.Click += new System.EventHandler(this.btnIndCod_Click);
			// 
			// tbgTable
			// 
			this.tbgTable.BackColor = System.Drawing.SystemColors.Control;
			this.tbgTable.Controls.Add(this.groupBox1);
			this.tbgTable.Controls.Add(this.groupBox15);
			this.tbgTable.Controls.Add(this.grpTblChnAdv);
			this.tbgTable.Controls.Add(this.grpTblChnSmp);
			this.tbgTable.Controls.Add(this.pcbTblMainPic);
			this.tbgTable.Controls.Add(this.cmbTblScnSel);
			this.tbgTable.Controls.Add(this.btnTblCod);
			this.tbgTable.Location = new System.Drawing.Point(4, 22);
			this.tbgTable.Name = "tbgTable";
			this.tbgTable.Size = new System.Drawing.Size(478, 265);
			this.tbgTable.TabIndex = 4;
			this.tbgTable.Text = "Table";
			// 
			// groupBox1
			// 
			this.groupBox1.Location = new System.Drawing.Point(415, 108);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(60, 149);
			this.groupBox1.TabIndex = 46;
			this.groupBox1.TabStop = false;
			// 
			// groupBox15
			// 
			this.groupBox15.Controls.Add(this.splitContainer1);
			this.groupBox15.Location = new System.Drawing.Point(268, 6);
			this.groupBox15.Name = "groupBox15";
			this.groupBox15.Size = new System.Drawing.Size(141, 251);
			this.groupBox15.TabIndex = 45;
			this.groupBox15.TabStop = false;
			this.groupBox15.Text = "Table";
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new System.Drawing.Point(3, 16);
			this.splitContainer1.Name = "splitContainer1";
			this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.rtbTblEnt);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.lsbTblWrn);
			this.splitContainer1.Size = new System.Drawing.Size(135, 232);
			this.splitContainer1.SplitterDistance = 172;
			this.splitContainer1.TabIndex = 0;
			// 
			// rtbTblEnt
			// 
			this.rtbTblEnt.Dock = System.Windows.Forms.DockStyle.Fill;
			this.rtbTblEnt.Location = new System.Drawing.Point(0, 0);
			this.rtbTblEnt.Name = "rtbTblEnt";
			this.rtbTblEnt.Size = new System.Drawing.Size(135, 172);
			this.rtbTblEnt.TabIndex = 0;
			this.rtbTblEnt.Text = "";
			this.rtbTblEnt.TextChanged += new System.EventHandler(this.rtbTblEnt_TextChanged);
			// 
			// lsbTblWrn
			// 
			this.lsbTblWrn.Dock = System.Windows.Forms.DockStyle.Fill;
			this.lsbTblWrn.FormattingEnabled = true;
			this.lsbTblWrn.Location = new System.Drawing.Point(0, 0);
			this.lsbTblWrn.Name = "lsbTblWrn";
			this.lsbTblWrn.Size = new System.Drawing.Size(135, 56);
			this.lsbTblWrn.TabIndex = 0;
			// 
			// grpTblChnAdv
			// 
			this.grpTblChnAdv.Controls.Add(this.cmbTblChn);
			this.grpTblChnAdv.Location = new System.Drawing.Point(415, 6);
			this.grpTblChnAdv.Name = "grpTblChnAdv";
			this.grpTblChnAdv.Size = new System.Drawing.Size(60, 96);
			this.grpTblChnAdv.TabIndex = 44;
			this.grpTblChnAdv.TabStop = false;
			this.grpTblChnAdv.Text = "Channel";
			this.grpTblChnAdv.Visible = false;
			// 
			// cmbTblChn
			// 
			this.cmbTblChn.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTblChn.FormattingEnabled = true;
			this.cmbTblChn.Items.AddRange(new object[] {
            "0",
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7"});
			this.cmbTblChn.Location = new System.Drawing.Point(6, 19);
			this.cmbTblChn.Name = "cmbTblChn";
			this.cmbTblChn.Size = new System.Drawing.Size(48, 21);
			this.cmbTblChn.TabIndex = 0;
			this.cmbTblChn.SelectedIndexChanged += new System.EventHandler(this.cmbTblChn_SelectedIndexChanged);
			// 
			// grpTblChnSmp
			// 
			this.grpTblChnSmp.Controls.Add(this.rdbTblCh5);
			this.grpTblChnSmp.Controls.Add(this.rdbTblCh4);
			this.grpTblChnSmp.Controls.Add(this.rdbTblCh3);
			this.grpTblChnSmp.Location = new System.Drawing.Point(415, 6);
			this.grpTblChnSmp.Name = "grpTblChnSmp";
			this.grpTblChnSmp.Size = new System.Drawing.Size(60, 96);
			this.grpTblChnSmp.TabIndex = 43;
			this.grpTblChnSmp.TabStop = false;
			this.grpTblChnSmp.Text = "Channel";
			// 
			// rdbTblCh5
			// 
			this.rdbTblCh5.AutoSize = true;
			this.rdbTblCh5.Location = new System.Drawing.Point(6, 65);
			this.rdbTblCh5.Name = "rdbTblCh5";
			this.rdbTblCh5.Size = new System.Drawing.Size(49, 17);
			this.rdbTblCh5.TabIndex = 2;
			this.rdbTblCh5.Text = "CH 5";
			this.rdbTblCh5.UseVisualStyleBackColor = true;
			this.rdbTblCh5.CheckedChanged += new System.EventHandler(this.rdbTbl_CheckedChanged);
			// 
			// rdbTblCh4
			// 
			this.rdbTblCh4.AutoSize = true;
			this.rdbTblCh4.Location = new System.Drawing.Point(6, 42);
			this.rdbTblCh4.Name = "rdbTblCh4";
			this.rdbTblCh4.Size = new System.Drawing.Size(49, 17);
			this.rdbTblCh4.TabIndex = 1;
			this.rdbTblCh4.Text = "CH 4";
			this.rdbTblCh4.UseVisualStyleBackColor = true;
			this.rdbTblCh4.CheckedChanged += new System.EventHandler(this.rdbTbl_CheckedChanged);
			// 
			// rdbTblCh3
			// 
			this.rdbTblCh3.AutoSize = true;
			this.rdbTblCh3.Checked = true;
			this.rdbTblCh3.Location = new System.Drawing.Point(6, 19);
			this.rdbTblCh3.Name = "rdbTblCh3";
			this.rdbTblCh3.Size = new System.Drawing.Size(49, 17);
			this.rdbTblCh3.TabIndex = 0;
			this.rdbTblCh3.TabStop = true;
			this.rdbTblCh3.Text = "CH 3";
			this.rdbTblCh3.UseVisualStyleBackColor = true;
			this.rdbTblCh3.CheckedChanged += new System.EventHandler(this.rdbTbl_CheckedChanged);
			// 
			// pcbTblMainPic
			// 
			this.pcbTblMainPic.BackColor = System.Drawing.Color.Black;
			this.pcbTblMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbTblMainPic.Name = "pcbTblMainPic";
			this.pcbTblMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbTblMainPic.TabIndex = 40;
			this.pcbTblMainPic.TabStop = false;
			// 
			// cmbTblScnSel
			// 
			this.cmbTblScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbTblScnSel.FormattingEnabled = true;
			this.cmbTblScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbTblScnSel.Name = "cmbTblScnSel";
			this.cmbTblScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbTblScnSel.TabIndex = 39;
			this.cmbTblScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbTblScnSel_SelectedIndexChanged);
			// 
			// btnTblCod
			// 
			this.btnTblCod.Location = new System.Drawing.Point(132, 236);
			this.btnTblCod.Name = "btnTblCod";
			this.btnTblCod.Size = new System.Drawing.Size(57, 21);
			this.btnTblCod.TabIndex = 38;
			this.btnTblCod.Text = "Code";
			this.btnTblCod.UseVisualStyleBackColor = true;
			this.btnTblCod.Click += new System.EventHandler(this.btnTblCod_Click);
			// 
			// toolTip
			// 
			this.toolTip.AutoPopDelay = 5000;
			this.toolTip.InitialDelay = 1000;
			this.toolTip.ReshowDelay = 100;
			// 
			// HDMA_Brightness_GUI
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(569, 323);
			this.Controls.Add(this.tbc);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.MaximizeBox = false;
			this.Name = "HDMA_Brightness_GUI";
			this.Text = "HDMA_Brightness_GUI";
			this.tbc.ResumeLayout(false);
			this.tbgSimple.ResumeLayout(false);
			this.grpSngChnAdv.ResumeLayout(false);
			this.grpSngChnStd.ResumeLayout(false);
			this.grpSngChnStd.PerformLayout();
			this.groupBox9.ResumeLayout(false);
			this.groupBox9.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudSmpBtmRea)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSmpBtmRea)).EndInit();
			this.groupBox8.ResumeLayout(false);
			this.groupBox8.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudSmpTopRea)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.trbSmpTopRea)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbSmpMainPic)).EndInit();
			this.tbgIndividual.ResumeLayout(false);
			this.tbgIndividual.PerformLayout();
			this.grpIndChnAdv.ResumeLayout(false);
			this.grpIndChnStd.ResumeLayout(false);
			this.grpIndChnStd.PerformLayout();
			this.groupBox12.ResumeLayout(false);
			this.groupBox10.ResumeLayout(false);
			this.groupBox10.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudIndLin)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pcbIndMainPic)).EndInit();
			this.tbgTable.ResumeLayout(false);
			this.groupBox15.ResumeLayout(false);
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
			this.splitContainer1.ResumeLayout(false);
			this.grpTblChnAdv.ResumeLayout(false);
			this.grpTblChnSmp.ResumeLayout(false);
			this.grpTblChnSmp.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbTblMainPic)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

		public System.Windows.Forms.TabControl tbc;
		private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.TabPage tbgSimple;
        private System.Windows.Forms.PictureBox pcbSmpMainPic;
        private System.Windows.Forms.ComboBox cmbSmpScnSel;
        private System.Windows.Forms.Button btnSmpCod;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.NumericUpDown nudSmpTopRea;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtSmpTopStr;
        private System.Windows.Forms.TrackBar trbSmpTopRea;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.NumericUpDown nudSmpBtmRea;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtSmpBtmStr;
        private System.Windows.Forms.TrackBar trbSmpBtmRea;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.GroupBox grpSngChnStd;
        private System.Windows.Forms.RadioButton rdbSmpCh5;
        private System.Windows.Forms.RadioButton rdbSmpCh4;
        private System.Windows.Forms.RadioButton rdbSmpCh3;
        private System.Windows.Forms.GroupBox grpSngChnAdv;
        private System.Windows.Forms.ComboBox cmbSmpChn;
        private System.Windows.Forms.TabPage tbgIndividual;
        private System.Windows.Forms.CheckBox chbIndEnd;
        private System.Windows.Forms.GroupBox grpIndChnStd;
        private System.Windows.Forms.RadioButton rdbIndCh5;
        private System.Windows.Forms.RadioButton rdbIndCh4;
        private System.Windows.Forms.RadioButton rdbIndCh3;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.ListBox lsbIndEnt;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Button btnIndDwn;
        private System.Windows.Forms.Button btnIndUp;
        private System.Windows.Forms.Button btnIndClr;
        private System.Windows.Forms.Button btnIndRmv;
        private System.Windows.Forms.Button btnIndAdd;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.NumericUpDown nudIndLin;
        private System.Windows.Forms.TextBox txtIndBri;
        private System.Windows.Forms.PictureBox pcbIndMainPic;
        private System.Windows.Forms.ComboBox cmbIndScnSel;
        private System.Windows.Forms.Button btnIndCod;
        private System.Windows.Forms.GroupBox grpIndChnAdv;
        private System.Windows.Forms.ComboBox cmbIndChn;
        private System.Windows.Forms.TabPage tbgTable;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.RichTextBox rtbTblEnt;
        private System.Windows.Forms.ListBox lsbTblWrn;
        private System.Windows.Forms.GroupBox grpTblChnAdv;
        private System.Windows.Forms.ComboBox cmbTblChn;
        private System.Windows.Forms.GroupBox grpTblChnSmp;
        private System.Windows.Forms.RadioButton rdbTblCh5;
        private System.Windows.Forms.RadioButton rdbTblCh4;
        private System.Windows.Forms.RadioButton rdbTblCh3;
        private System.Windows.Forms.PictureBox pcbTblMainPic;
        private System.Windows.Forms.ComboBox cmbTblScnSel;
        private System.Windows.Forms.Button btnTblCod;
		private System.Windows.Forms.GroupBox groupBox1;
    }
}