﻿namespace HDMA_Generator_Tool
{
	partial class Color_Math_GUI
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Color_Math_GUI));
			this.tbc = new System.Windows.Forms.TabControl();
			this.tbgSimple = new System.Windows.Forms.TabPage();
			this.groupBox14 = new System.Windows.Forms.GroupBox();
			this.pcbWinBakDrp = new System.Windows.Forms.PictureBox();
			this.label9 = new System.Windows.Forms.Label();
			this.groupBox10 = new System.Windows.Forms.GroupBox();
			this.groupBox12 = new System.Windows.Forms.GroupBox();
			this.chbWinTwoInvCol = new System.Windows.Forms.CheckBox();
			this.chbWinTwoInvObj = new System.Windows.Forms.CheckBox();
			this.chbWinTwoInvBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinTwoInvBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinTwoInvBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinTwoInvBg1 = new System.Windows.Forms.CheckBox();
			this.groupBox13 = new System.Windows.Forms.GroupBox();
			this.chbWinTwoEneCol = new System.Windows.Forms.CheckBox();
			this.chbWinTwoEneObj = new System.Windows.Forms.CheckBox();
			this.chbWinTwoEneBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinTwoEneBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinTwoEneBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinTwoEneBg1 = new System.Windows.Forms.CheckBox();
			this.pcbWinWinTwo = new System.Windows.Forms.PictureBox();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.label8 = new System.Windows.Forms.Label();
			this.cmbWinMskLogCol = new System.Windows.Forms.ComboBox();
			this.label7 = new System.Windows.Forms.Label();
			this.cmbWinMskLogObj = new System.Windows.Forms.ComboBox();
			this.label6 = new System.Windows.Forms.Label();
			this.cmbWinMskLogBg4 = new System.Windows.Forms.ComboBox();
			this.label5 = new System.Windows.Forms.Label();
			this.cmbWinMskLogBg3 = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.cmbWinMskLogBg2 = new System.Windows.Forms.ComboBox();
			this.label3 = new System.Windows.Forms.Label();
			this.cmbWinMskLogBg1 = new System.Windows.Forms.ComboBox();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.chbWinSubWinObj = new System.Windows.Forms.CheckBox();
			this.chbWinSubWinBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinSubWinBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinSubWinBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinSubWinBg1 = new System.Windows.Forms.CheckBox();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.chbWinOneInvCol = new System.Windows.Forms.CheckBox();
			this.chbWinOneInvObj = new System.Windows.Forms.CheckBox();
			this.chbWinOneInvBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinOneInvBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinOneInvBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinOneInvBg1 = new System.Windows.Forms.CheckBox();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.chbWinOneEneCol = new System.Windows.Forms.CheckBox();
			this.chbWinOneEneObj = new System.Windows.Forms.CheckBox();
			this.chbWinOneEneBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinOneEneBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinOneEneBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinOneEneBg1 = new System.Windows.Forms.CheckBox();
			this.pcbWinWinOne = new System.Windows.Forms.PictureBox();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.chbWinMaiWinObj = new System.Windows.Forms.CheckBox();
			this.chbWinMaiWinBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinMaiWinBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinMaiWinBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinMaiWinBg1 = new System.Windows.Forms.CheckBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.cmbWinPrvMat = new System.Windows.Forms.ComboBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.cmbWinClpToBlk = new System.Windows.Forms.ComboBox();
			this.chbWin256Col = new System.Windows.Forms.CheckBox();
			this.chbWinAddSub = new System.Windows.Forms.CheckBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.chbWinColMatHlf = new System.Windows.Forms.CheckBox();
			this.chbWinColMatAdd = new System.Windows.Forms.CheckBox();
			this.chbWinColMatBak = new System.Windows.Forms.CheckBox();
			this.chbWinColMatObj = new System.Windows.Forms.CheckBox();
			this.chbWinColMatBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinColMatBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinColMatBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinColMatBg1 = new System.Windows.Forms.CheckBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.chbWinSubScnObj = new System.Windows.Forms.CheckBox();
			this.chbWinSubScnBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinSubScnBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinSubScnBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinSubScnBg1 = new System.Windows.Forms.CheckBox();
			this.groupBox11 = new System.Windows.Forms.GroupBox();
			this.chbWinMaiScnObj = new System.Windows.Forms.CheckBox();
			this.chbWinMaiScnBg4 = new System.Windows.Forms.CheckBox();
			this.chbWinMaiScnBg3 = new System.Windows.Forms.CheckBox();
			this.chbWinMaiScnBg2 = new System.Windows.Forms.CheckBox();
			this.chbWinMaiScnBg1 = new System.Windows.Forms.CheckBox();
			this.pcbWinMainPic = new System.Windows.Forms.PictureBox();
			this.cmbWinScnSel = new System.Windows.Forms.ComboBox();
			this.btnWinCod = new System.Windows.Forms.Button();
			this.tbc.SuspendLayout();
			this.tbgSimple.SuspendLayout();
			this.groupBox14.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinBakDrp)).BeginInit();
			this.groupBox10.SuspendLayout();
			this.groupBox12.SuspendLayout();
			this.groupBox13.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinWinTwo)).BeginInit();
			this.groupBox4.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.groupBox9.SuspendLayout();
			this.groupBox8.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinWinOne)).BeginInit();
			this.groupBox5.SuspendLayout();
			this.groupBox3.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.groupBox11.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinMainPic)).BeginInit();
			this.SuspendLayout();
			// 
			// tbc
			// 
			this.tbc.Controls.Add(this.tbgSimple);
			this.tbc.Location = new System.Drawing.Point(12, 12);
			this.tbc.Name = "tbc";
			this.tbc.SelectedIndex = 0;
			this.tbc.Size = new System.Drawing.Size(757, 420);
			this.tbc.TabIndex = 2;
			// 
			// tbgSimple
			// 
			this.tbgSimple.BackColor = System.Drawing.SystemColors.Control;
			this.tbgSimple.Controls.Add(this.groupBox14);
			this.tbgSimple.Controls.Add(this.groupBox10);
			this.tbgSimple.Controls.Add(this.groupBox4);
			this.tbgSimple.Controls.Add(this.groupBox7);
			this.tbgSimple.Controls.Add(this.groupBox6);
			this.tbgSimple.Controls.Add(this.groupBox5);
			this.tbgSimple.Controls.Add(this.groupBox3);
			this.tbgSimple.Controls.Add(this.groupBox2);
			this.tbgSimple.Controls.Add(this.groupBox1);
			this.tbgSimple.Controls.Add(this.groupBox11);
			this.tbgSimple.Controls.Add(this.pcbWinMainPic);
			this.tbgSimple.Controls.Add(this.cmbWinScnSel);
			this.tbgSimple.Controls.Add(this.btnWinCod);
			this.tbgSimple.Location = new System.Drawing.Point(4, 22);
			this.tbgSimple.Name = "tbgSimple";
			this.tbgSimple.Size = new System.Drawing.Size(749, 394);
			this.tbgSimple.TabIndex = 2;
			this.tbgSimple.Text = "With Windowing";
			// 
			// groupBox14
			// 
			this.groupBox14.Controls.Add(this.pcbWinBakDrp);
			this.groupBox14.Controls.Add(this.label9);
			this.groupBox14.Location = new System.Drawing.Point(268, 348);
			this.groupBox14.Name = "groupBox14";
			this.groupBox14.Size = new System.Drawing.Size(158, 38);
			this.groupBox14.TabIndex = 49;
			this.groupBox14.TabStop = false;
			this.groupBox14.Text = "Backdrop (CGRAM $0)";
			// 
			// pcbWinBakDrp
			// 
			this.pcbWinBakDrp.BackColor = System.Drawing.Color.Black;
			this.pcbWinBakDrp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pcbWinBakDrp.Location = new System.Drawing.Point(46, 19);
			this.pcbWinBakDrp.Name = "pcbWinBakDrp";
			this.pcbWinBakDrp.Size = new System.Drawing.Size(15, 15);
			this.pcbWinBakDrp.TabIndex = 1;
			this.pcbWinBakDrp.TabStop = false;
			this.pcbWinBakDrp.Click += new System.EventHandler(this.pcbWinBakDrp_Click);
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(6, 19);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(34, 13);
			this.label9.TabIndex = 0;
			this.label9.Text = "Color:";
			// 
			// groupBox10
			// 
			this.groupBox10.Controls.Add(this.groupBox12);
			this.groupBox10.Controls.Add(this.groupBox13);
			this.groupBox10.Controls.Add(this.pcbWinWinTwo);
			this.groupBox10.Location = new System.Drawing.Point(586, 90);
			this.groupBox10.Name = "groupBox10";
			this.groupBox10.Size = new System.Drawing.Size(148, 296);
			this.groupBox10.TabIndex = 48;
			this.groupBox10.TabStop = false;
			this.groupBox10.Text = "Window 2 ($2123-5)";
			// 
			// groupBox12
			// 
			this.groupBox12.Controls.Add(this.chbWinTwoInvCol);
			this.groupBox12.Controls.Add(this.chbWinTwoInvObj);
			this.groupBox12.Controls.Add(this.chbWinTwoInvBg4);
			this.groupBox12.Controls.Add(this.chbWinTwoInvBg3);
			this.groupBox12.Controls.Add(this.chbWinTwoInvBg2);
			this.groupBox12.Controls.Add(this.chbWinTwoInvBg1);
			this.groupBox12.Location = new System.Drawing.Point(70, 134);
			this.groupBox12.Name = "groupBox12";
			this.groupBox12.Size = new System.Drawing.Size(58, 156);
			this.groupBox12.TabIndex = 46;
			this.groupBox12.TabStop = false;
			this.groupBox12.Text = "Invert";
			// 
			// chbWinTwoInvCol
			// 
			this.chbWinTwoInvCol.AutoSize = true;
			this.chbWinTwoInvCol.Location = new System.Drawing.Point(6, 134);
			this.chbWinTwoInvCol.Name = "chbWinTwoInvCol";
			this.chbWinTwoInvCol.Size = new System.Drawing.Size(50, 17);
			this.chbWinTwoInvCol.TabIndex = 5;
			this.chbWinTwoInvCol.Text = "Color";
			this.chbWinTwoInvCol.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoInvObj
			// 
			this.chbWinTwoInvObj.AutoSize = true;
			this.chbWinTwoInvObj.Location = new System.Drawing.Point(6, 111);
			this.chbWinTwoInvObj.Name = "chbWinTwoInvObj";
			this.chbWinTwoInvObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinTwoInvObj.TabIndex = 4;
			this.chbWinTwoInvObj.Text = "OBJ";
			this.chbWinTwoInvObj.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoInvBg4
			// 
			this.chbWinTwoInvBg4.AutoSize = true;
			this.chbWinTwoInvBg4.Location = new System.Drawing.Point(6, 88);
			this.chbWinTwoInvBg4.Name = "chbWinTwoInvBg4";
			this.chbWinTwoInvBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoInvBg4.TabIndex = 3;
			this.chbWinTwoInvBg4.Text = "BG4";
			this.chbWinTwoInvBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoInvBg3
			// 
			this.chbWinTwoInvBg3.AutoSize = true;
			this.chbWinTwoInvBg3.Location = new System.Drawing.Point(6, 65);
			this.chbWinTwoInvBg3.Name = "chbWinTwoInvBg3";
			this.chbWinTwoInvBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoInvBg3.TabIndex = 2;
			this.chbWinTwoInvBg3.Text = "BG3";
			this.chbWinTwoInvBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoInvBg2
			// 
			this.chbWinTwoInvBg2.AutoSize = true;
			this.chbWinTwoInvBg2.Location = new System.Drawing.Point(6, 42);
			this.chbWinTwoInvBg2.Name = "chbWinTwoInvBg2";
			this.chbWinTwoInvBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoInvBg2.TabIndex = 1;
			this.chbWinTwoInvBg2.Text = "BG2";
			this.chbWinTwoInvBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoInvBg1
			// 
			this.chbWinTwoInvBg1.AutoSize = true;
			this.chbWinTwoInvBg1.Location = new System.Drawing.Point(6, 19);
			this.chbWinTwoInvBg1.Name = "chbWinTwoInvBg1";
			this.chbWinTwoInvBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoInvBg1.TabIndex = 0;
			this.chbWinTwoInvBg1.Text = "BG1";
			this.chbWinTwoInvBg1.UseVisualStyleBackColor = true;
			// 
			// groupBox13
			// 
			this.groupBox13.Controls.Add(this.chbWinTwoEneCol);
			this.groupBox13.Controls.Add(this.chbWinTwoEneObj);
			this.groupBox13.Controls.Add(this.chbWinTwoEneBg4);
			this.groupBox13.Controls.Add(this.chbWinTwoEneBg3);
			this.groupBox13.Controls.Add(this.chbWinTwoEneBg2);
			this.groupBox13.Controls.Add(this.chbWinTwoEneBg1);
			this.groupBox13.Location = new System.Drawing.Point(6, 134);
			this.groupBox13.Name = "groupBox13";
			this.groupBox13.Size = new System.Drawing.Size(58, 156);
			this.groupBox13.TabIndex = 45;
			this.groupBox13.TabStop = false;
			this.groupBox13.Text = "Enable";
			// 
			// chbWinTwoEneCol
			// 
			this.chbWinTwoEneCol.AutoSize = true;
			this.chbWinTwoEneCol.Location = new System.Drawing.Point(6, 134);
			this.chbWinTwoEneCol.Name = "chbWinTwoEneCol";
			this.chbWinTwoEneCol.Size = new System.Drawing.Size(50, 17);
			this.chbWinTwoEneCol.TabIndex = 5;
			this.chbWinTwoEneCol.Text = "Color";
			this.chbWinTwoEneCol.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoEneObj
			// 
			this.chbWinTwoEneObj.AutoSize = true;
			this.chbWinTwoEneObj.Location = new System.Drawing.Point(6, 111);
			this.chbWinTwoEneObj.Name = "chbWinTwoEneObj";
			this.chbWinTwoEneObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinTwoEneObj.TabIndex = 4;
			this.chbWinTwoEneObj.Text = "OBJ";
			this.chbWinTwoEneObj.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoEneBg4
			// 
			this.chbWinTwoEneBg4.AutoSize = true;
			this.chbWinTwoEneBg4.Location = new System.Drawing.Point(6, 88);
			this.chbWinTwoEneBg4.Name = "chbWinTwoEneBg4";
			this.chbWinTwoEneBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoEneBg4.TabIndex = 3;
			this.chbWinTwoEneBg4.Text = "BG4";
			this.chbWinTwoEneBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoEneBg3
			// 
			this.chbWinTwoEneBg3.AutoSize = true;
			this.chbWinTwoEneBg3.Location = new System.Drawing.Point(6, 65);
			this.chbWinTwoEneBg3.Name = "chbWinTwoEneBg3";
			this.chbWinTwoEneBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoEneBg3.TabIndex = 2;
			this.chbWinTwoEneBg3.Text = "BG3";
			this.chbWinTwoEneBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoEneBg2
			// 
			this.chbWinTwoEneBg2.AutoSize = true;
			this.chbWinTwoEneBg2.Location = new System.Drawing.Point(6, 42);
			this.chbWinTwoEneBg2.Name = "chbWinTwoEneBg2";
			this.chbWinTwoEneBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoEneBg2.TabIndex = 1;
			this.chbWinTwoEneBg2.Text = "BG2";
			this.chbWinTwoEneBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinTwoEneBg1
			// 
			this.chbWinTwoEneBg1.AutoSize = true;
			this.chbWinTwoEneBg1.Location = new System.Drawing.Point(6, 19);
			this.chbWinTwoEneBg1.Name = "chbWinTwoEneBg1";
			this.chbWinTwoEneBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinTwoEneBg1.TabIndex = 0;
			this.chbWinTwoEneBg1.Text = "BG1";
			this.chbWinTwoEneBg1.UseVisualStyleBackColor = true;
			// 
			// pcbWinWinTwo
			// 
			this.pcbWinWinTwo.BackColor = System.Drawing.Color.White;
			this.pcbWinWinTwo.Image = ((System.Drawing.Image)(resources.GetObject("pcbWinWinTwo.Image")));
			this.pcbWinWinTwo.Location = new System.Drawing.Point(6, 16);
			this.pcbWinWinTwo.Name = "pcbWinWinTwo";
			this.pcbWinWinTwo.Size = new System.Drawing.Size(128, 112);
			this.pcbWinWinTwo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbWinWinTwo.TabIndex = 44;
			this.pcbWinWinTwo.TabStop = false;
			this.pcbWinWinTwo.Click += new System.EventHandler(this.pcbWinWinTwo_Click);
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.label8);
			this.groupBox4.Controls.Add(this.cmbWinMskLogCol);
			this.groupBox4.Controls.Add(this.label7);
			this.groupBox4.Controls.Add(this.cmbWinMskLogObj);
			this.groupBox4.Controls.Add(this.label6);
			this.groupBox4.Controls.Add(this.cmbWinMskLogBg4);
			this.groupBox4.Controls.Add(this.label5);
			this.groupBox4.Controls.Add(this.cmbWinMskLogBg3);
			this.groupBox4.Controls.Add(this.label4);
			this.groupBox4.Controls.Add(this.cmbWinMskLogBg2);
			this.groupBox4.Controls.Add(this.label3);
			this.groupBox4.Controls.Add(this.cmbWinMskLogBg1);
			this.groupBox4.Location = new System.Drawing.Point(6, 266);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(241, 109);
			this.groupBox4.TabIndex = 47;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Mask Logic ($212A/B)";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(122, 77);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(34, 13);
			this.label8.TabIndex = 20;
			this.label8.Text = "Color:";
			// 
			// cmbWinMskLogCol
			// 
			this.cmbWinMskLogCol.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinMskLogCol.FormattingEnabled = true;
			this.cmbWinMskLogCol.Location = new System.Drawing.Point(162, 74);
			this.cmbWinMskLogCol.Name = "cmbWinMskLogCol";
			this.cmbWinMskLogCol.Size = new System.Drawing.Size(64, 21);
			this.cmbWinMskLogCol.TabIndex = 19;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(122, 50);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(30, 13);
			this.label7.TabIndex = 18;
			this.label7.Text = "OBJ:";
			// 
			// cmbWinMskLogObj
			// 
			this.cmbWinMskLogObj.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinMskLogObj.FormattingEnabled = true;
			this.cmbWinMskLogObj.Location = new System.Drawing.Point(162, 47);
			this.cmbWinMskLogObj.Name = "cmbWinMskLogObj";
			this.cmbWinMskLogObj.Size = new System.Drawing.Size(64, 21);
			this.cmbWinMskLogObj.TabIndex = 17;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(122, 23);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(31, 13);
			this.label6.TabIndex = 16;
			this.label6.Text = "BG4:";
			// 
			// cmbWinMskLogBg4
			// 
			this.cmbWinMskLogBg4.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinMskLogBg4.FormattingEnabled = true;
			this.cmbWinMskLogBg4.Location = new System.Drawing.Point(162, 20);
			this.cmbWinMskLogBg4.Name = "cmbWinMskLogBg4";
			this.cmbWinMskLogBg4.Size = new System.Drawing.Size(64, 21);
			this.cmbWinMskLogBg4.TabIndex = 15;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(6, 77);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(31, 13);
			this.label5.TabIndex = 14;
			this.label5.Text = "BG3:";
			// 
			// cmbWinMskLogBg3
			// 
			this.cmbWinMskLogBg3.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinMskLogBg3.FormattingEnabled = true;
			this.cmbWinMskLogBg3.Location = new System.Drawing.Point(46, 74);
			this.cmbWinMskLogBg3.Name = "cmbWinMskLogBg3";
			this.cmbWinMskLogBg3.Size = new System.Drawing.Size(64, 21);
			this.cmbWinMskLogBg3.TabIndex = 13;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(6, 50);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(31, 13);
			this.label4.TabIndex = 12;
			this.label4.Text = "BG2:";
			// 
			// cmbWinMskLogBg2
			// 
			this.cmbWinMskLogBg2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinMskLogBg2.FormattingEnabled = true;
			this.cmbWinMskLogBg2.Location = new System.Drawing.Point(46, 47);
			this.cmbWinMskLogBg2.Name = "cmbWinMskLogBg2";
			this.cmbWinMskLogBg2.Size = new System.Drawing.Size(64, 21);
			this.cmbWinMskLogBg2.TabIndex = 11;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 23);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(31, 13);
			this.label3.TabIndex = 10;
			this.label3.Text = "BG1:";
			// 
			// cmbWinMskLogBg1
			// 
			this.cmbWinMskLogBg1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinMskLogBg1.FormattingEnabled = true;
			this.cmbWinMskLogBg1.Location = new System.Drawing.Point(46, 20);
			this.cmbWinMskLogBg1.Name = "cmbWinMskLogBg1";
			this.cmbWinMskLogBg1.Size = new System.Drawing.Size(64, 21);
			this.cmbWinMskLogBg1.TabIndex = 9;
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.chbWinSubWinObj);
			this.groupBox7.Controls.Add(this.chbWinSubWinBg4);
			this.groupBox7.Controls.Add(this.chbWinSubWinBg3);
			this.groupBox7.Controls.Add(this.chbWinSubWinBg2);
			this.groupBox7.Controls.Add(this.chbWinSubWinBg1);
			this.groupBox7.Location = new System.Drawing.Point(432, 45);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Size = new System.Drawing.Size(273, 39);
			this.groupBox7.TabIndex = 46;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Mask for Sub Screen ($212F)";
			// 
			// chbWinSubWinObj
			// 
			this.chbWinSubWinObj.AutoSize = true;
			this.chbWinSubWinObj.Location = new System.Drawing.Point(218, 19);
			this.chbWinSubWinObj.Name = "chbWinSubWinObj";
			this.chbWinSubWinObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinSubWinObj.TabIndex = 4;
			this.chbWinSubWinObj.Text = "OBJ";
			this.chbWinSubWinObj.UseVisualStyleBackColor = true;
			// 
			// chbWinSubWinBg4
			// 
			this.chbWinSubWinBg4.AutoSize = true;
			this.chbWinSubWinBg4.Location = new System.Drawing.Point(165, 19);
			this.chbWinSubWinBg4.Name = "chbWinSubWinBg4";
			this.chbWinSubWinBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubWinBg4.TabIndex = 3;
			this.chbWinSubWinBg4.Text = "BG4";
			this.chbWinSubWinBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinSubWinBg3
			// 
			this.chbWinSubWinBg3.AutoSize = true;
			this.chbWinSubWinBg3.Checked = true;
			this.chbWinSubWinBg3.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinSubWinBg3.Location = new System.Drawing.Point(112, 19);
			this.chbWinSubWinBg3.Name = "chbWinSubWinBg3";
			this.chbWinSubWinBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubWinBg3.TabIndex = 2;
			this.chbWinSubWinBg3.Text = "BG3";
			this.chbWinSubWinBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinSubWinBg2
			// 
			this.chbWinSubWinBg2.AutoSize = true;
			this.chbWinSubWinBg2.Checked = true;
			this.chbWinSubWinBg2.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinSubWinBg2.Location = new System.Drawing.Point(59, 19);
			this.chbWinSubWinBg2.Name = "chbWinSubWinBg2";
			this.chbWinSubWinBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubWinBg2.TabIndex = 1;
			this.chbWinSubWinBg2.Text = "BG2";
			this.chbWinSubWinBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinSubWinBg1
			// 
			this.chbWinSubWinBg1.AutoSize = true;
			this.chbWinSubWinBg1.Location = new System.Drawing.Point(6, 19);
			this.chbWinSubWinBg1.Name = "chbWinSubWinBg1";
			this.chbWinSubWinBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubWinBg1.TabIndex = 0;
			this.chbWinSubWinBg1.Text = "BG1";
			this.chbWinSubWinBg1.UseVisualStyleBackColor = true;
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.groupBox9);
			this.groupBox6.Controls.Add(this.groupBox8);
			this.groupBox6.Controls.Add(this.pcbWinWinOne);
			this.groupBox6.Location = new System.Drawing.Point(432, 90);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Size = new System.Drawing.Size(148, 296);
			this.groupBox6.TabIndex = 45;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "Window 1 ($2123-5)";
			// 
			// groupBox9
			// 
			this.groupBox9.Controls.Add(this.chbWinOneInvCol);
			this.groupBox9.Controls.Add(this.chbWinOneInvObj);
			this.groupBox9.Controls.Add(this.chbWinOneInvBg4);
			this.groupBox9.Controls.Add(this.chbWinOneInvBg3);
			this.groupBox9.Controls.Add(this.chbWinOneInvBg2);
			this.groupBox9.Controls.Add(this.chbWinOneInvBg1);
			this.groupBox9.Location = new System.Drawing.Point(70, 134);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Size = new System.Drawing.Size(58, 156);
			this.groupBox9.TabIndex = 46;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "Invert";
			// 
			// chbWinOneInvCol
			// 
			this.chbWinOneInvCol.AutoSize = true;
			this.chbWinOneInvCol.Location = new System.Drawing.Point(6, 134);
			this.chbWinOneInvCol.Name = "chbWinOneInvCol";
			this.chbWinOneInvCol.Size = new System.Drawing.Size(50, 17);
			this.chbWinOneInvCol.TabIndex = 5;
			this.chbWinOneInvCol.Text = "Color";
			this.chbWinOneInvCol.UseVisualStyleBackColor = true;
			// 
			// chbWinOneInvObj
			// 
			this.chbWinOneInvObj.AutoSize = true;
			this.chbWinOneInvObj.Location = new System.Drawing.Point(6, 111);
			this.chbWinOneInvObj.Name = "chbWinOneInvObj";
			this.chbWinOneInvObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinOneInvObj.TabIndex = 4;
			this.chbWinOneInvObj.Text = "OBJ";
			this.chbWinOneInvObj.UseVisualStyleBackColor = true;
			// 
			// chbWinOneInvBg4
			// 
			this.chbWinOneInvBg4.AutoSize = true;
			this.chbWinOneInvBg4.Location = new System.Drawing.Point(6, 88);
			this.chbWinOneInvBg4.Name = "chbWinOneInvBg4";
			this.chbWinOneInvBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneInvBg4.TabIndex = 3;
			this.chbWinOneInvBg4.Text = "BG4";
			this.chbWinOneInvBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinOneInvBg3
			// 
			this.chbWinOneInvBg3.AutoSize = true;
			this.chbWinOneInvBg3.Location = new System.Drawing.Point(6, 65);
			this.chbWinOneInvBg3.Name = "chbWinOneInvBg3";
			this.chbWinOneInvBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneInvBg3.TabIndex = 2;
			this.chbWinOneInvBg3.Text = "BG3";
			this.chbWinOneInvBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinOneInvBg2
			// 
			this.chbWinOneInvBg2.AutoSize = true;
			this.chbWinOneInvBg2.Location = new System.Drawing.Point(6, 42);
			this.chbWinOneInvBg2.Name = "chbWinOneInvBg2";
			this.chbWinOneInvBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneInvBg2.TabIndex = 1;
			this.chbWinOneInvBg2.Text = "BG2";
			this.chbWinOneInvBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinOneInvBg1
			// 
			this.chbWinOneInvBg1.AutoSize = true;
			this.chbWinOneInvBg1.Location = new System.Drawing.Point(6, 19);
			this.chbWinOneInvBg1.Name = "chbWinOneInvBg1";
			this.chbWinOneInvBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneInvBg1.TabIndex = 0;
			this.chbWinOneInvBg1.Text = "BG1";
			this.chbWinOneInvBg1.UseVisualStyleBackColor = true;
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.chbWinOneEneCol);
			this.groupBox8.Controls.Add(this.chbWinOneEneObj);
			this.groupBox8.Controls.Add(this.chbWinOneEneBg4);
			this.groupBox8.Controls.Add(this.chbWinOneEneBg3);
			this.groupBox8.Controls.Add(this.chbWinOneEneBg2);
			this.groupBox8.Controls.Add(this.chbWinOneEneBg1);
			this.groupBox8.Location = new System.Drawing.Point(6, 134);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Size = new System.Drawing.Size(58, 156);
			this.groupBox8.TabIndex = 45;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Enable";
			// 
			// chbWinOneEneCol
			// 
			this.chbWinOneEneCol.AutoSize = true;
			this.chbWinOneEneCol.Location = new System.Drawing.Point(6, 134);
			this.chbWinOneEneCol.Name = "chbWinOneEneCol";
			this.chbWinOneEneCol.Size = new System.Drawing.Size(50, 17);
			this.chbWinOneEneCol.TabIndex = 5;
			this.chbWinOneEneCol.Text = "Color";
			this.chbWinOneEneCol.UseVisualStyleBackColor = true;
			// 
			// chbWinOneEneObj
			// 
			this.chbWinOneEneObj.AutoSize = true;
			this.chbWinOneEneObj.Location = new System.Drawing.Point(6, 111);
			this.chbWinOneEneObj.Name = "chbWinOneEneObj";
			this.chbWinOneEneObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinOneEneObj.TabIndex = 4;
			this.chbWinOneEneObj.Text = "OBJ";
			this.chbWinOneEneObj.UseVisualStyleBackColor = true;
			// 
			// chbWinOneEneBg4
			// 
			this.chbWinOneEneBg4.AutoSize = true;
			this.chbWinOneEneBg4.Location = new System.Drawing.Point(6, 88);
			this.chbWinOneEneBg4.Name = "chbWinOneEneBg4";
			this.chbWinOneEneBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneEneBg4.TabIndex = 3;
			this.chbWinOneEneBg4.Text = "BG4";
			this.chbWinOneEneBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinOneEneBg3
			// 
			this.chbWinOneEneBg3.AutoSize = true;
			this.chbWinOneEneBg3.Location = new System.Drawing.Point(6, 65);
			this.chbWinOneEneBg3.Name = "chbWinOneEneBg3";
			this.chbWinOneEneBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneEneBg3.TabIndex = 2;
			this.chbWinOneEneBg3.Text = "BG3";
			this.chbWinOneEneBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinOneEneBg2
			// 
			this.chbWinOneEneBg2.AutoSize = true;
			this.chbWinOneEneBg2.Location = new System.Drawing.Point(6, 42);
			this.chbWinOneEneBg2.Name = "chbWinOneEneBg2";
			this.chbWinOneEneBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneEneBg2.TabIndex = 1;
			this.chbWinOneEneBg2.Text = "BG2";
			this.chbWinOneEneBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinOneEneBg1
			// 
			this.chbWinOneEneBg1.AutoSize = true;
			this.chbWinOneEneBg1.Location = new System.Drawing.Point(6, 19);
			this.chbWinOneEneBg1.Name = "chbWinOneEneBg1";
			this.chbWinOneEneBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinOneEneBg1.TabIndex = 0;
			this.chbWinOneEneBg1.Text = "BG1";
			this.chbWinOneEneBg1.UseVisualStyleBackColor = true;
			// 
			// pcbWinWinOne
			// 
			this.pcbWinWinOne.BackColor = System.Drawing.Color.White;
			this.pcbWinWinOne.Image = ((System.Drawing.Image)(resources.GetObject("pcbWinWinOne.Image")));
			this.pcbWinWinOne.Location = new System.Drawing.Point(6, 16);
			this.pcbWinWinOne.Name = "pcbWinWinOne";
			this.pcbWinWinOne.Size = new System.Drawing.Size(128, 112);
			this.pcbWinWinOne.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pcbWinWinOne.TabIndex = 44;
			this.pcbWinWinOne.TabStop = false;
			this.pcbWinWinOne.Click += new System.EventHandler(this.pcbWinWinOne_Click);
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.chbWinMaiWinObj);
			this.groupBox5.Controls.Add(this.chbWinMaiWinBg4);
			this.groupBox5.Controls.Add(this.chbWinMaiWinBg3);
			this.groupBox5.Controls.Add(this.chbWinMaiWinBg2);
			this.groupBox5.Controls.Add(this.chbWinMaiWinBg1);
			this.groupBox5.Location = new System.Drawing.Point(432, 6);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(273, 39);
			this.groupBox5.TabIndex = 42;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Mask for Main Screen ($212E)";
			// 
			// chbWinMaiWinObj
			// 
			this.chbWinMaiWinObj.AutoSize = true;
			this.chbWinMaiWinObj.Checked = true;
			this.chbWinMaiWinObj.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinMaiWinObj.Location = new System.Drawing.Point(218, 19);
			this.chbWinMaiWinObj.Name = "chbWinMaiWinObj";
			this.chbWinMaiWinObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinMaiWinObj.TabIndex = 4;
			this.chbWinMaiWinObj.Text = "OBJ";
			this.chbWinMaiWinObj.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiWinBg4
			// 
			this.chbWinMaiWinBg4.AutoSize = true;
			this.chbWinMaiWinBg4.Location = new System.Drawing.Point(165, 19);
			this.chbWinMaiWinBg4.Name = "chbWinMaiWinBg4";
			this.chbWinMaiWinBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiWinBg4.TabIndex = 3;
			this.chbWinMaiWinBg4.Text = "BG4";
			this.chbWinMaiWinBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiWinBg3
			// 
			this.chbWinMaiWinBg3.AutoSize = true;
			this.chbWinMaiWinBg3.Location = new System.Drawing.Point(112, 19);
			this.chbWinMaiWinBg3.Name = "chbWinMaiWinBg3";
			this.chbWinMaiWinBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiWinBg3.TabIndex = 2;
			this.chbWinMaiWinBg3.Text = "BG3";
			this.chbWinMaiWinBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiWinBg2
			// 
			this.chbWinMaiWinBg2.AutoSize = true;
			this.chbWinMaiWinBg2.Location = new System.Drawing.Point(59, 19);
			this.chbWinMaiWinBg2.Name = "chbWinMaiWinBg2";
			this.chbWinMaiWinBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiWinBg2.TabIndex = 1;
			this.chbWinMaiWinBg2.Text = "BG2";
			this.chbWinMaiWinBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiWinBg1
			// 
			this.chbWinMaiWinBg1.AutoSize = true;
			this.chbWinMaiWinBg1.Checked = true;
			this.chbWinMaiWinBg1.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinMaiWinBg1.Location = new System.Drawing.Point(6, 19);
			this.chbWinMaiWinBg1.Name = "chbWinMaiWinBg1";
			this.chbWinMaiWinBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiWinBg1.TabIndex = 0;
			this.chbWinMaiWinBg1.Text = "BG1";
			this.chbWinMaiWinBg1.UseVisualStyleBackColor = true;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.cmbWinPrvMat);
			this.groupBox3.Controls.Add(this.label2);
			this.groupBox3.Controls.Add(this.label1);
			this.groupBox3.Controls.Add(this.cmbWinClpToBlk);
			this.groupBox3.Controls.Add(this.chbWin256Col);
			this.groupBox3.Controls.Add(this.chbWinAddSub);
			this.groupBox3.Location = new System.Drawing.Point(268, 254);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(158, 93);
			this.groupBox3.TabIndex = 41;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Additional Select ($2130)";
			// 
			// cmbWinPrvMat
			// 
			this.cmbWinPrvMat.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinPrvMat.FormattingEnabled = true;
			this.cmbWinPrvMat.Location = new System.Drawing.Point(81, 44);
			this.cmbWinPrvMat.Name = "cmbWinPrvMat";
			this.cmbWinPrvMat.Size = new System.Drawing.Size(61, 21);
			this.cmbWinPrvMat.TabIndex = 11;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(6, 47);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(74, 13);
			this.label2.TabIndex = 10;
			this.label2.Text = "Prevent Math:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 20);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(69, 13);
			this.label1.TabIndex = 9;
			this.label1.Text = "Clip to Black:";
			// 
			// cmbWinClpToBlk
			// 
			this.cmbWinClpToBlk.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinClpToBlk.FormattingEnabled = true;
			this.cmbWinClpToBlk.Location = new System.Drawing.Point(81, 17);
			this.cmbWinClpToBlk.Name = "cmbWinClpToBlk";
			this.cmbWinClpToBlk.Size = new System.Drawing.Size(61, 21);
			this.cmbWinClpToBlk.TabIndex = 8;
			// 
			// chbWin256Col
			// 
			this.chbWin256Col.AutoSize = true;
			this.chbWin256Col.Location = new System.Drawing.Point(79, 71);
			this.chbWin256Col.Name = "chbWin256Col";
			this.chbWin256Col.Size = new System.Drawing.Size(71, 17);
			this.chbWin256Col.TabIndex = 7;
			this.chbWin256Col.Text = "256 Color";
			this.chbWin256Col.UseVisualStyleBackColor = true;
			// 
			// chbWinAddSub
			// 
			this.chbWinAddSub.AutoSize = true;
			this.chbWinAddSub.Checked = true;
			this.chbWinAddSub.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinAddSub.Location = new System.Drawing.Point(6, 71);
			this.chbWinAddSub.Name = "chbWinAddSub";
			this.chbWinAddSub.Size = new System.Drawing.Size(67, 17);
			this.chbWinAddSub.TabIndex = 6;
			this.chbWinAddSub.Text = "Add Sub";
			this.chbWinAddSub.UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.chbWinColMatHlf);
			this.groupBox2.Controls.Add(this.chbWinColMatAdd);
			this.groupBox2.Controls.Add(this.chbWinColMatBak);
			this.groupBox2.Controls.Add(this.chbWinColMatObj);
			this.groupBox2.Controls.Add(this.chbWinColMatBg4);
			this.groupBox2.Controls.Add(this.chbWinColMatBg3);
			this.groupBox2.Controls.Add(this.chbWinColMatBg2);
			this.groupBox2.Controls.Add(this.chbWinColMatBg1);
			this.groupBox2.Location = new System.Drawing.Point(268, 162);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(158, 86);
			this.groupBox2.TabIndex = 40;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Color Math ($2131)";
			// 
			// chbWinColMatHlf
			// 
			this.chbWinColMatHlf.AutoSize = true;
			this.chbWinColMatHlf.Location = new System.Drawing.Point(109, 63);
			this.chbWinColMatHlf.Name = "chbWinColMatHlf";
			this.chbWinColMatHlf.Size = new System.Drawing.Size(45, 17);
			this.chbWinColMatHlf.TabIndex = 7;
			this.chbWinColMatHlf.Text = "Half";
			this.chbWinColMatHlf.UseVisualStyleBackColor = true;
			// 
			// chbWinColMatAdd
			// 
			this.chbWinColMatAdd.AutoSize = true;
			this.chbWinColMatAdd.Checked = true;
			this.chbWinColMatAdd.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinColMatAdd.Location = new System.Drawing.Point(109, 42);
			this.chbWinColMatAdd.Name = "chbWinColMatAdd";
			this.chbWinColMatAdd.Size = new System.Drawing.Size(45, 17);
			this.chbWinColMatAdd.TabIndex = 6;
			this.chbWinColMatAdd.Text = "Add";
			this.chbWinColMatAdd.UseVisualStyleBackColor = true;
			// 
			// chbWinColMatBak
			// 
			this.chbWinColMatBak.AutoSize = true;
			this.chbWinColMatBak.Checked = true;
			this.chbWinColMatBak.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinColMatBak.Location = new System.Drawing.Point(6, 63);
			this.chbWinColMatBak.Name = "chbWinColMatBak";
			this.chbWinColMatBak.Size = new System.Drawing.Size(72, 17);
			this.chbWinColMatBak.TabIndex = 5;
			this.chbWinColMatBak.Text = "Backdrop";
			this.chbWinColMatBak.UseVisualStyleBackColor = true;
			// 
			// chbWinColMatObj
			// 
			this.chbWinColMatObj.AutoSize = true;
			this.chbWinColMatObj.Location = new System.Drawing.Point(56, 42);
			this.chbWinColMatObj.Name = "chbWinColMatObj";
			this.chbWinColMatObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinColMatObj.TabIndex = 4;
			this.chbWinColMatObj.Text = "OBJ";
			this.chbWinColMatObj.UseVisualStyleBackColor = true;
			// 
			// chbWinColMatBg4
			// 
			this.chbWinColMatBg4.AutoSize = true;
			this.chbWinColMatBg4.Location = new System.Drawing.Point(6, 42);
			this.chbWinColMatBg4.Name = "chbWinColMatBg4";
			this.chbWinColMatBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinColMatBg4.TabIndex = 3;
			this.chbWinColMatBg4.Text = "BG4";
			this.chbWinColMatBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinColMatBg3
			// 
			this.chbWinColMatBg3.AutoSize = true;
			this.chbWinColMatBg3.Location = new System.Drawing.Point(109, 19);
			this.chbWinColMatBg3.Name = "chbWinColMatBg3";
			this.chbWinColMatBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinColMatBg3.TabIndex = 2;
			this.chbWinColMatBg3.Text = "BG3";
			this.chbWinColMatBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinColMatBg2
			// 
			this.chbWinColMatBg2.AutoSize = true;
			this.chbWinColMatBg2.Location = new System.Drawing.Point(56, 19);
			this.chbWinColMatBg2.Name = "chbWinColMatBg2";
			this.chbWinColMatBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinColMatBg2.TabIndex = 1;
			this.chbWinColMatBg2.Text = "BG2";
			this.chbWinColMatBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinColMatBg1
			// 
			this.chbWinColMatBg1.AutoSize = true;
			this.chbWinColMatBg1.Location = new System.Drawing.Point(6, 19);
			this.chbWinColMatBg1.Name = "chbWinColMatBg1";
			this.chbWinColMatBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinColMatBg1.TabIndex = 0;
			this.chbWinColMatBg1.Text = "BG1";
			this.chbWinColMatBg1.UseVisualStyleBackColor = true;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.chbWinSubScnObj);
			this.groupBox1.Controls.Add(this.chbWinSubScnBg4);
			this.groupBox1.Controls.Add(this.chbWinSubScnBg3);
			this.groupBox1.Controls.Add(this.chbWinSubScnBg2);
			this.groupBox1.Controls.Add(this.chbWinSubScnBg1);
			this.groupBox1.Location = new System.Drawing.Point(334, 6);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(61, 150);
			this.groupBox1.TabIndex = 39;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Sub ($212D)";
			// 
			// chbWinSubScnObj
			// 
			this.chbWinSubScnObj.AutoSize = true;
			this.chbWinSubScnObj.Location = new System.Drawing.Point(6, 123);
			this.chbWinSubScnObj.Name = "chbWinSubScnObj";
			this.chbWinSubScnObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinSubScnObj.TabIndex = 4;
			this.chbWinSubScnObj.Text = "OBJ";
			this.chbWinSubScnObj.UseVisualStyleBackColor = true;
			// 
			// chbWinSubScnBg4
			// 
			this.chbWinSubScnBg4.AutoSize = true;
			this.chbWinSubScnBg4.Location = new System.Drawing.Point(6, 100);
			this.chbWinSubScnBg4.Name = "chbWinSubScnBg4";
			this.chbWinSubScnBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubScnBg4.TabIndex = 3;
			this.chbWinSubScnBg4.Text = "BG4";
			this.chbWinSubScnBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinSubScnBg3
			// 
			this.chbWinSubScnBg3.AutoSize = true;
			this.chbWinSubScnBg3.Checked = true;
			this.chbWinSubScnBg3.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinSubScnBg3.Location = new System.Drawing.Point(6, 77);
			this.chbWinSubScnBg3.Name = "chbWinSubScnBg3";
			this.chbWinSubScnBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubScnBg3.TabIndex = 2;
			this.chbWinSubScnBg3.Text = "BG3";
			this.chbWinSubScnBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinSubScnBg2
			// 
			this.chbWinSubScnBg2.AutoSize = true;
			this.chbWinSubScnBg2.Checked = true;
			this.chbWinSubScnBg2.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinSubScnBg2.Location = new System.Drawing.Point(6, 54);
			this.chbWinSubScnBg2.Name = "chbWinSubScnBg2";
			this.chbWinSubScnBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubScnBg2.TabIndex = 1;
			this.chbWinSubScnBg2.Text = "BG2";
			this.chbWinSubScnBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinSubScnBg1
			// 
			this.chbWinSubScnBg1.AutoSize = true;
			this.chbWinSubScnBg1.Location = new System.Drawing.Point(6, 31);
			this.chbWinSubScnBg1.Name = "chbWinSubScnBg1";
			this.chbWinSubScnBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinSubScnBg1.TabIndex = 0;
			this.chbWinSubScnBg1.Text = "BG1";
			this.chbWinSubScnBg1.UseVisualStyleBackColor = true;
			// 
			// groupBox11
			// 
			this.groupBox11.Controls.Add(this.chbWinMaiScnObj);
			this.groupBox11.Controls.Add(this.chbWinMaiScnBg4);
			this.groupBox11.Controls.Add(this.chbWinMaiScnBg3);
			this.groupBox11.Controls.Add(this.chbWinMaiScnBg2);
			this.groupBox11.Controls.Add(this.chbWinMaiScnBg1);
			this.groupBox11.Location = new System.Drawing.Point(268, 6);
			this.groupBox11.Name = "groupBox11";
			this.groupBox11.Size = new System.Drawing.Size(60, 150);
			this.groupBox11.TabIndex = 38;
			this.groupBox11.TabStop = false;
			this.groupBox11.Text = "Main ($212C)";
			// 
			// chbWinMaiScnObj
			// 
			this.chbWinMaiScnObj.AutoSize = true;
			this.chbWinMaiScnObj.Checked = true;
			this.chbWinMaiScnObj.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinMaiScnObj.Location = new System.Drawing.Point(7, 123);
			this.chbWinMaiScnObj.Name = "chbWinMaiScnObj";
			this.chbWinMaiScnObj.Size = new System.Drawing.Size(46, 17);
			this.chbWinMaiScnObj.TabIndex = 4;
			this.chbWinMaiScnObj.Text = "OBJ";
			this.chbWinMaiScnObj.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiScnBg4
			// 
			this.chbWinMaiScnBg4.AutoSize = true;
			this.chbWinMaiScnBg4.Location = new System.Drawing.Point(7, 100);
			this.chbWinMaiScnBg4.Name = "chbWinMaiScnBg4";
			this.chbWinMaiScnBg4.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiScnBg4.TabIndex = 3;
			this.chbWinMaiScnBg4.Text = "BG4";
			this.chbWinMaiScnBg4.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiScnBg3
			// 
			this.chbWinMaiScnBg3.AutoSize = true;
			this.chbWinMaiScnBg3.Location = new System.Drawing.Point(7, 77);
			this.chbWinMaiScnBg3.Name = "chbWinMaiScnBg3";
			this.chbWinMaiScnBg3.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiScnBg3.TabIndex = 2;
			this.chbWinMaiScnBg3.Text = "BG3";
			this.chbWinMaiScnBg3.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiScnBg2
			// 
			this.chbWinMaiScnBg2.AutoSize = true;
			this.chbWinMaiScnBg2.Location = new System.Drawing.Point(7, 54);
			this.chbWinMaiScnBg2.Name = "chbWinMaiScnBg2";
			this.chbWinMaiScnBg2.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiScnBg2.TabIndex = 1;
			this.chbWinMaiScnBg2.Text = "BG2";
			this.chbWinMaiScnBg2.UseVisualStyleBackColor = true;
			// 
			// chbWinMaiScnBg1
			// 
			this.chbWinMaiScnBg1.AutoSize = true;
			this.chbWinMaiScnBg1.Checked = true;
			this.chbWinMaiScnBg1.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chbWinMaiScnBg1.Location = new System.Drawing.Point(7, 31);
			this.chbWinMaiScnBg1.Name = "chbWinMaiScnBg1";
			this.chbWinMaiScnBg1.Size = new System.Drawing.Size(47, 17);
			this.chbWinMaiScnBg1.TabIndex = 0;
			this.chbWinMaiScnBg1.Text = "BG1";
			this.chbWinMaiScnBg1.UseVisualStyleBackColor = true;
			// 
			// pcbWinMainPic
			// 
			this.pcbWinMainPic.BackColor = System.Drawing.Color.Black;
			this.pcbWinMainPic.Location = new System.Drawing.Point(6, 6);
			this.pcbWinMainPic.Name = "pcbWinMainPic";
			this.pcbWinMainPic.Size = new System.Drawing.Size(256, 224);
			this.pcbWinMainPic.TabIndex = 34;
			this.pcbWinMainPic.TabStop = false;
			// 
			// cmbWinScnSel
			// 
			this.cmbWinScnSel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cmbWinScnSel.FormattingEnabled = true;
			this.cmbWinScnSel.Location = new System.Drawing.Point(6, 236);
			this.cmbWinScnSel.Name = "cmbWinScnSel";
			this.cmbWinScnSel.Size = new System.Drawing.Size(120, 21);
			this.cmbWinScnSel.TabIndex = 33;
			this.cmbWinScnSel.SelectedIndexChanged += new System.EventHandler(this.cmbWinScnSel_SelectedIndexChanged);
			// 
			// btnWinCod
			// 
			this.btnWinCod.Location = new System.Drawing.Point(132, 236);
			this.btnWinCod.Name = "btnWinCod";
			this.btnWinCod.Size = new System.Drawing.Size(57, 21);
			this.btnWinCod.TabIndex = 32;
			this.btnWinCod.Text = "Code";
			this.btnWinCod.UseVisualStyleBackColor = true;
			this.btnWinCod.Click += new System.EventHandler(this.btnWinCod_Click);
			// 
			// Color_Math_GUI
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(825, 480);
			this.Controls.Add(this.tbc);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "Color_Math_GUI";
			this.Text = "Color_Math_GUI";
			this.tbc.ResumeLayout(false);
			this.tbgSimple.ResumeLayout(false);
			this.groupBox14.ResumeLayout(false);
			this.groupBox14.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinBakDrp)).EndInit();
			this.groupBox10.ResumeLayout(false);
			this.groupBox12.ResumeLayout(false);
			this.groupBox12.PerformLayout();
			this.groupBox13.ResumeLayout(false);
			this.groupBox13.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinWinTwo)).EndInit();
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox7.ResumeLayout(false);
			this.groupBox7.PerformLayout();
			this.groupBox6.ResumeLayout(false);
			this.groupBox9.ResumeLayout(false);
			this.groupBox9.PerformLayout();
			this.groupBox8.ResumeLayout(false);
			this.groupBox8.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinWinOne)).EndInit();
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox11.ResumeLayout(false);
			this.groupBox11.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pcbWinMainPic)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		public System.Windows.Forms.TabControl tbc;
		private System.Windows.Forms.TabPage tbgSimple;
		private System.Windows.Forms.GroupBox groupBox10;
		private System.Windows.Forms.GroupBox groupBox12;
		private System.Windows.Forms.CheckBox chbWinTwoInvCol;
		private System.Windows.Forms.CheckBox chbWinTwoInvObj;
		private System.Windows.Forms.CheckBox chbWinTwoInvBg4;
		private System.Windows.Forms.CheckBox chbWinTwoInvBg3;
		private System.Windows.Forms.CheckBox chbWinTwoInvBg2;
		private System.Windows.Forms.CheckBox chbWinTwoInvBg1;
		private System.Windows.Forms.GroupBox groupBox13;
		private System.Windows.Forms.CheckBox chbWinTwoEneCol;
		private System.Windows.Forms.CheckBox chbWinTwoEneObj;
		private System.Windows.Forms.CheckBox chbWinTwoEneBg4;
		private System.Windows.Forms.CheckBox chbWinTwoEneBg3;
		private System.Windows.Forms.CheckBox chbWinTwoEneBg2;
		private System.Windows.Forms.CheckBox chbWinTwoEneBg1;
		private System.Windows.Forms.PictureBox pcbWinWinTwo;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.ComboBox cmbWinMskLogCol;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.ComboBox cmbWinMskLogObj;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.ComboBox cmbWinMskLogBg4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ComboBox cmbWinMskLogBg3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.ComboBox cmbWinMskLogBg2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox cmbWinMskLogBg1;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.CheckBox chbWinSubWinObj;
		private System.Windows.Forms.CheckBox chbWinSubWinBg4;
		private System.Windows.Forms.CheckBox chbWinSubWinBg3;
		private System.Windows.Forms.CheckBox chbWinSubWinBg2;
		private System.Windows.Forms.CheckBox chbWinSubWinBg1;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.GroupBox groupBox9;
		private System.Windows.Forms.CheckBox chbWinOneInvCol;
		private System.Windows.Forms.CheckBox chbWinOneInvObj;
		private System.Windows.Forms.CheckBox chbWinOneInvBg4;
		private System.Windows.Forms.CheckBox chbWinOneInvBg3;
		private System.Windows.Forms.CheckBox chbWinOneInvBg2;
		private System.Windows.Forms.CheckBox chbWinOneInvBg1;
		private System.Windows.Forms.GroupBox groupBox8;
		private System.Windows.Forms.CheckBox chbWinOneEneCol;
		private System.Windows.Forms.CheckBox chbWinOneEneObj;
		private System.Windows.Forms.CheckBox chbWinOneEneBg4;
		private System.Windows.Forms.CheckBox chbWinOneEneBg3;
		private System.Windows.Forms.CheckBox chbWinOneEneBg2;
		private System.Windows.Forms.CheckBox chbWinOneEneBg1;
		private System.Windows.Forms.PictureBox pcbWinWinOne;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.CheckBox chbWinMaiWinObj;
		private System.Windows.Forms.CheckBox chbWinMaiWinBg4;
		private System.Windows.Forms.CheckBox chbWinMaiWinBg3;
		private System.Windows.Forms.CheckBox chbWinMaiWinBg2;
		private System.Windows.Forms.CheckBox chbWinMaiWinBg1;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.ComboBox cmbWinPrvMat;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox cmbWinClpToBlk;
		private System.Windows.Forms.CheckBox chbWin256Col;
		private System.Windows.Forms.CheckBox chbWinAddSub;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.CheckBox chbWinColMatHlf;
		private System.Windows.Forms.CheckBox chbWinColMatAdd;
		private System.Windows.Forms.CheckBox chbWinColMatBak;
		private System.Windows.Forms.CheckBox chbWinColMatObj;
		private System.Windows.Forms.CheckBox chbWinColMatBg4;
		private System.Windows.Forms.CheckBox chbWinColMatBg3;
		private System.Windows.Forms.CheckBox chbWinColMatBg2;
		private System.Windows.Forms.CheckBox chbWinColMatBg1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.CheckBox chbWinSubScnObj;
		private System.Windows.Forms.CheckBox chbWinSubScnBg4;
		private System.Windows.Forms.CheckBox chbWinSubScnBg3;
		private System.Windows.Forms.CheckBox chbWinSubScnBg2;
		private System.Windows.Forms.CheckBox chbWinSubScnBg1;
		private System.Windows.Forms.GroupBox groupBox11;
		private System.Windows.Forms.CheckBox chbWinMaiScnObj;
		private System.Windows.Forms.CheckBox chbWinMaiScnBg4;
		private System.Windows.Forms.CheckBox chbWinMaiScnBg3;
		private System.Windows.Forms.CheckBox chbWinMaiScnBg2;
		private System.Windows.Forms.CheckBox chbWinMaiScnBg1;
		private System.Windows.Forms.PictureBox pcbWinMainPic;
		private System.Windows.Forms.ComboBox cmbWinScnSel;
		private System.Windows.Forms.Button btnWinCod;
		private System.Windows.Forms.GroupBox groupBox14;
		private System.Windows.Forms.PictureBox pcbWinBakDrp;
		private System.Windows.Forms.Label label9;
	}
}